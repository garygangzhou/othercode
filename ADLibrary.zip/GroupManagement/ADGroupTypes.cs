﻿
namespace CCO.ActiveDirectoryLibrary.GroupManagement
{

   
    public enum ADGroupTypes
    {
        Distribution = 0,
        Security = -2147483648 // ActiveDs.ADS_GROUP_TYPE_ENUM.ADS_GROUP_TYPE_SECURITY_ENABLED
    }
}