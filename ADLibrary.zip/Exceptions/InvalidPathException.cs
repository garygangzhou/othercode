﻿using System;

namespace CCO.ActiveDirectoryLibrary.Exceptions
{
    public class InvalidPathException : ActiveDirectoryException
    {
        public InvalidPathException(Exception ex) : base("AD Path is invalid.", ErrorCode.InvalidPathError, ex)
        {
        }
    }
}