﻿

namespace CCO.ActiveDirectoryLibrary
{
    public enum ADObjectTypes
    {
        Unknown,
        Group,
        OU,
        User,
        Container,
        BuiltInDomain,
        RootNode
    }
}