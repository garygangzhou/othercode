﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RedApple.Common.Utility;

namespace RedApple.Utility.Tests
{
    [TestClass]
    public class UtilityDateUtilityTest
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetQuarterNumberTest_WithArgumentError()
        {
            DateUtility.GetQuarterNumber(0);
        }

        [TestMethod]
        public void GetQuarterNumberTest()
        {
            Assert.AreEqual(4, DateUtility.GetQuarterNumber(11));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetCalendarQuarterNumberTest_WithArgumentError()
        {
            DateUtility.GetCalendarQuarterNumber(DateTime.MinValue);
        }

        [TestMethod]
        public void GetCalendarQuarterNumberTest()
        {
            DateTime date = new DateTime(2015, 11, 5);
            int result = DateUtility.GetCalendarQuarterNumber(date);
            Assert.AreEqual(4, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetQuarterStartMonthTest_WithArgumentError1()
        {
            DateUtility.GetQuarterStartMonth(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetQuarterStartMonthTest_WithArgumentError2()
        {
            DateUtility.GetQuarterStartMonth(5);
        }

        [TestMethod]
        public void GetQuarterStartMonthTest()
        {            
            Assert.AreEqual(4, DateUtility.GetQuarterStartMonth(2));
            Assert.AreEqual(7, DateUtility.GetQuarterStartMonth(3));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetQuarterEndMonthTest_WithArgumentError1()
        {
            DateUtility.GetQuarterEndMonth(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetQuarterEndMonthTest_WithArgumentError2()
        {
            DateUtility.GetQuarterEndMonth(5);
        }

        [TestMethod]
        public void GetQuarterEndMonthTest()
        {
            Assert.AreEqual(3, DateUtility.GetQuarterEndMonth(1));            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetCalendarQuarterStartDateTest_WithArgumentError()
        {
            DateUtility.GetCalendarQuarterStartDate(1800, 1);
        }

        [TestMethod]
        public void GetCalendarQuarterStartDateTest()
        {
            DateTime result = DateUtility.GetCalendarQuarterStartDate(2015, 2);
            DateTime expected = new DateTime(2015, 4, 1);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetCalendarQuarterEndDateTest_WithArgumentError()
        {
            DateUtility.GetCalendarQuarterEndDate(1800, 1);
        }

        [TestMethod]
        public void GetCalendarQuarterEndDateTest()
        {
            DateTime result = DateUtility.GetCalendarQuarterEndDate(2015, 1);
            DateTime expected = new DateTime(2015, 3, 31);
            Assert.AreEqual(expected, result);

            result = DateUtility.GetCalendarQuarterEndDate(2015, 2);
            expected = new DateTime(2015, 6, 30);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetCalendarQuarterStartDateTest2_WithArgumentError()
        {
            DateUtility.GetCalendarQuarterStartDate(DateTime.MinValue);
        }

        [TestMethod]
        public void GetCalendarQuarterStartDateTest2()
        {
            DateTime result = DateUtility.GetCalendarQuarterStartDate(new DateTime(2015, 5, 15));
            DateTime expected = new DateTime(2015, 4, 1);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetCalendarQuarterEndDateTest2_WithArgumentError()
        {
            DateUtility.GetCalendarQuarterEndDate(DateTime.MinValue);
        }

        [TestMethod]
        public void GetCalendarQuarterEndDateTest2()
        {
            DateTime result = DateUtility.GetCalendarQuarterEndDate(new DateTime(2015, 2, 10));
            DateTime expected = new DateTime(2015, 3, 31);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetCalendarMonthNumberByFiscalMonthNumberTest_WithArgumentError()
        {
            DateUtility.GetCalendarMonthNumberByFiscalMonthNumber(13);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetCalendarMonthNumberByFiscalMonthNumberTest1_WithArgumentError()
        {
            DateUtility.GetCalendarMonthNumberByFiscalMonthNumber(0);
        }

        [TestMethod]
        public void GetCalendarMonthNumberByFiscalMonthNumberTest()
        {
            Assert.AreEqual(5, DateUtility.GetCalendarMonthNumberByFiscalMonthNumber(2));
            Assert.AreEqual(12, DateUtility.GetCalendarMonthNumberByFiscalMonthNumber(9));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalMonthNumberByCalendarMonthNumberTest1_WithArgumentError()
        {
            DateUtility.GetFiscalMonthNumberByCalendarMonthNumber(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalMonthNumberByCalendarMonthNumberTest2_WithArgumentError()
        {
            DateUtility.GetFiscalMonthNumberByCalendarMonthNumber(13);
        }

        [TestMethod]
        public void GetFiscalMonthNumberByCalendarMonthNumberTest()
        {
            Assert.AreEqual(1, DateUtility.GetFiscalMonthNumberByCalendarMonthNumber(4));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalQuarterNumberTest_WithArgumentError1()
        {
            DateUtility.GetFiscalQuarterNumber(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalQuarterNumberTest_WithArgumentError2()
        {
            DateUtility.GetFiscalQuarterNumber(13);
        }

        [TestMethod]
        public void GetFiscalQuarterNumberTest()
        {
            Assert.AreEqual(2, DateUtility.GetFiscalQuarterNumber(7));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalYearTest_WithArgumentError()
        {
            DateUtility.GetFiscalYear(DateTime.MinValue);
        }
        
        [TestMethod]
        public void GetFiscalYearTest()
        {
            Assert.AreEqual(2014, DateUtility.GetFiscalYear(new DateTime(2015, 3, 12)));
            Assert.AreEqual(2015, DateUtility.GetFiscalYear(new DateTime(2015, 7, 8)));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalQuarterStartDateTest_WithArgumentError()
        {
            DateUtility.GetFiscalQuarterStartDate(DateTime.MinValue);
        }

        [TestMethod]
        public void GetFiscalQuarterStartDateTest()
        {
            DateTime expected = new DateTime(2015, 4, 1);
            DateTime result = DateUtility.GetFiscalQuarterStartDate(new DateTime(2015, 5, 10));
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalQuarterEndDateTest_WithArgumentError()
        {
            DateUtility.GetFiscalQuarterEndDate(DateTime.MinValue);
        }

        [TestMethod]
        public void GetFiscalQuarterEndDateTest()
        {
            DateTime expected = new DateTime(2015, 6, 30);
            DateTime result = DateUtility.GetFiscalQuarterEndDate(new DateTime(2015, 5, 10));
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalQuarterStringTest_WithArgumentError1()
        {
            DateUtility.GetFiscalQuarterString(1800, 1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalQuarterStringTest_WithArgumentError2()
        {
            DateUtility.GetFiscalQuarterString(2015, 0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalQuarterStringTest_WithArgumentError3()
        {
            DateUtility.GetFiscalQuarterString(2015, 5);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetFiscalQuarterStringTest_WithArgumentError4()
        {
            DateUtility.GetFiscalQuarterString(DateTime.MinValue);
        }

        [TestMethod]
        public void GetFiscalQuarterStringTest1()
        {
            Assert.AreEqual("2015Q2", DateUtility.GetFiscalQuarterString(2015, 2));
        }

        [TestMethod]
        public void GetFiscalQuarterStringTest2()
        {
            Assert.AreEqual("2015Q2", DateUtility.GetFiscalQuarterString(new DateTime(2015, 7, 2)));
        }
    }
}
