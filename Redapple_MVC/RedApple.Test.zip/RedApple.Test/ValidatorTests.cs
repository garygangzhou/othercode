﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RedApple.Validation;
using System;
using System.Data;

namespace RedApple.Validators.Tests
{
    [TestClass()]
    public class ValidatorTests
    {
        #region HCNValidator
        [TestMethod()]
        public void HCNValidator_IsRowValid_10Digits()
        {
            HCNValidator validator = new Validators.HCNValidator();
            string colName = "Health Card Number";           
            string colValue = "9999999999"; //pass   
            string colValue2 = "0009999996";  //fail
            string colValue3 = "0000000";   //pass
            int rowIndex = 0;
            string msg = "10 digits HCN string";
            
            bool result1 = RunValidation(validator, colName, colValue, rowIndex);
            bool result2 = RunValidation(validator, colName, colValue2, rowIndex);
            bool result3 = RunValidation(validator, colName, colValue3, rowIndex);

            Assert.IsTrue(result1, msg + ", result 1.");
            Assert.IsFalse(result2, msg + ", result 2.");
            Assert.IsTrue(result3, msg + ", result 3.");
        }

        [TestMethod()]
        public void HCNValidator_IsRowValid_10Digits_Negative()
        {
            HCNValidator validator = new Validators.HCNValidator();
            string colName = "Health Card Number";
            string colValue = "9999999999";
            int rowIndex = 0;
            string msg = "10 digits HCN string";

            bool result = RunValidation(validator, colName, colValue, rowIndex, null, true);

            Assert.IsFalse(result, msg);
        }

        [TestMethod()]
        public void HCNValidator_IsRowValid_10Digits_0()
        {
            HCNValidator validator = new Validators.HCNValidator();
            string colName = "Health Card Number";
            string colValue = "5166980150";
            int rowIndex = 0;
            string msg = "10 digits HCN string";

            bool result = RunValidation(validator, colName, colValue, rowIndex);

            Assert.IsTrue(result, msg);
        }      

        [TestMethod()]
        public void HCNValidator_IsRowValid_8Digits()
        {
            HCNValidator validator = new Validators.HCNValidator();
            string colName = "Health Card Number";
            string colValue = "99999999";
            int rowIndex = 0;
            string msg = "8 digits HCN string";

            bool result = RunValidation(validator, colName, colValue, rowIndex);

            Assert.IsFalse(result, msg);
        }

        [TestMethod()]
        public void HCNValidator_IsRowValid_Zero()
        {
            HCNValidator validator = new Validators.HCNValidator();
            string colName = "Health Card Number";
            string colValue = "0";
            int rowIndex = 0;
            string msg = "Empty HCN string";

            bool result = RunValidation(validator, colName, colValue, rowIndex);

            Assert.IsTrue(result, msg);
        }

        [TestMethod()]
        public void HCNValidator_IsRowValid_InValidString()
        {
            HCNValidator validator = new Validators.HCNValidator();
            string colName = "Health Card Number";
            string colValue = "a";
            int rowIndex = 0;
            string msg = "Invalid HCN string";

            bool result = RunValidation(validator, colName, colValue, rowIndex);

            Assert.IsFalse(result, msg);
        }

        [TestMethod()]
        [ExpectedException(typeof(NotImplementedException))]
        public void HCNValidator_IsFileValid()
        {
            HCNValidator validator = new Validators.HCNValidator();
            validator.IsFileValid(null, null);
        }
        #endregion
        #region NullValidator
        [TestMethod()]
        [ExpectedException(typeof(NotImplementedException))]
        public void NullValidator_IsFileValid()
        {
            NullValidator validator = new Validators.NullValidator();
            validator.IsFileValid(null, null);
        }
        #endregion
        #region DateValidator
        [TestMethod()]
        [ExpectedException(typeof(NotImplementedException))]
        public void DateValidator_IsFileValid()
        {
            DateValidator validator = new Validators.DateValidator();
            validator.IsFileValid(null, null);
        }
        #endregion
        #region ExpressionValidator
        [TestMethod()]
        [ExpectedException(typeof(NotImplementedException))]
        public void ExpressionValidator_IsFileValid()
        {
            ExpressionValidator validator = new Validators.ExpressionValidator();
            validator.IsFileValid(null, null);
        }

        [TestMethod]
        public void ExpressionValidator_IsRowValid() {
            ExpressionValidator validator = new Validators.ExpressionValidator();
            string colName = "Patient Chart Number";
            string colValue = "F";
            string ruleExpression = @"if(ismatch('^.+$', [Dsp.Record.Patient Chart Number]),if(ismatch('^([A-Za-z0-9]){1,10}$', [Dsp.Record.Patient Chart Number]), true, false),true)";            
            string msg = "Patient Chart Number";

            bool result = RunValidation(validator, colName, colValue, 0, ruleExpression, false);

            Assert.IsTrue(result, msg);
        }

        #endregion
        #region PatternValidator
        [TestMethod()]
        public void PatternValidator_IsRowValid()
        {
            PatternValidator validator = new PatternValidator();
            string colName = "Cecal Intubation";
            string colValue = "Y";
            string ruleExpression = "^(Y|N|X)$";
            int rowIndex = 0;
            string msg = "PatternValidator IsRowValid";

            bool result = RunValidation(validator, colName, colValue, rowIndex, ruleExpression );

            Assert.IsTrue(result, msg);
        }
        [TestMethod()]
        [ExpectedException(typeof(NotImplementedException))]
        public void PatternValidator_IsFileValid()
        {
            PatternValidator validator = new PatternValidator();
            validator.IsFileValid(null, null);
        }
        #endregion
        #region helpers
        private bool RunValidation(IValidator validator, string colName, string colValue, int rowIndex, string ruleExpression = null, bool IsNegated = false) {
            //rule object
            ValidationRule vr = new ValidationRule();
            vr.FieldName = colName;
            vr.IsNegated = IsNegated;
            if (!string.IsNullOrEmpty(ruleExpression))
                vr.Expression = ruleExpression;

            //hash, only one column for testing
            DataHash dh = new DataHash();
            DataTable dt = dh.Recordset;
            dt.Columns.Add(new DataColumn() { ColumnName = colName });
            DataRow dr = dt.NewRow();
            dr[colName] = colValue;
            dt.Rows.Add(dr);

            return validator.IsRowValid(vr, dh, rowIndex);
        }
        #endregion
    }
}