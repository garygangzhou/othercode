﻿using RedApple.MVC.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Routing;

namespace RedApple.Test
{
    [TestClass]
    public class RoutingTests
    {
        [TestMethod]
        [TestCategory("Routing Tests")]
        public void Home_Index()
        {
            TestRoute("~/", new
            {
                controller = "Home",
                action = "Index",
                id = string.Empty                 
            });
        }

        [TestMethod]
        [TestCategory("Routing Tests")]
        public void Home_Index2()
        {
            TestRoute("~/Home/Index", new
            {
                controller = "Home",
                action = "Index",
                id = (string)null
            });
        }

        [TestMethod]
        [TestCategory("Routing Tests")]
        public void Home_Contactus()
        {
            TestRoute("~/Home/Contactus", new
            {
                controller = "Home",
                action = "Contactus",
                id = string.Empty
            });
        }

        [TestMethod]
        [TestCategory("Routing Tests")]
        public void Auth_Agreement()
        {
            TestRoute("~/Auth/Agreement", new
            {
                controller = "Auth",
                action = "Agreement",
                id = (string)null
            });
        }

        [TestMethod]
        [TestCategory("Routing Tests")]
        public void Auth_UnAuth()
        {
            TestRoute("~/Auth/UnAuth", new
            {
                controller = "Auth",
                action = "UnAuth",
                id = (string)null
            });
        }

        private void TestRoute(string url, object expectedValues)
        {
            //Arrange: Prepare the route collection and a mock request context
            RouteCollection routes = new RouteCollection();
            RouteConfig.RegisterRoutes(routes);

            var mockHttpContext = new Moq.Mock<HttpContextBase>();
            var mockRequest = new Moq.Mock<HttpRequestBase>();
            mockHttpContext.Setup(x => x.Request).Returns(mockRequest.Object);
            mockRequest.Setup(x => x.AppRelativeCurrentExecutionFilePath).Returns(url);

            //Act: Get the mapped route
            RouteData routeData = routes.GetRouteData(mockHttpContext.Object);

            //Assert: Test the route values against expectations
            Assert.IsNotNull(routeData);

            var expectedDict = new RouteValueDictionary(expectedValues);
            foreach (var expectedVal in expectedDict)
            {
                if (expectedVal.Value == null)
                    Assert.IsNull(routeData.Values[expectedVal.Key]);
                else
                    Assert.AreEqual(expectedVal.Value.ToString(), routeData.Values[expectedVal.Key].ToString());
            }
        }
    }
}
