﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using Moq;
using RedApple.Common.Infrastructure;
using RedApple.DAL;
using System.IO;
using LumenWorks.Framework.IO.Csv;
using System.Linq;
using Microsoft.Practices.Unity;
using RedApple.BusinessLogic.Infrastructure;
using RedApple.Validation;
using System.Data;
using RedApple.Test;

namespace RedApple.BusinessLogic.Tests
{
    [TestClass()]
    public class SubmissionProcessDispatcherTests
    {
        internal static string filepath = @"../MockDataFiles/gi_endo_5555_201504.csv";      

        [TestInitialize]
        public void Init()
        {
            DependencyInjectionHelper.Initialize();

             IUnityContainer container = DependencyInjectionHelper.Container;

            //container.RegisterType<ISubmissionConfiguration, SubmissionConfiguration>(new HierarchicalLifetimeManager());
            //container.RegisterType<ISecurityProvider, TestSecurityProvider>();

           // container.RegisterType<IPortalConfiguration, FakePortalConfiguration>(new HierarchicalLifetimeManager());
            //container.RegisterType<IEDWSubmissionLogRepository, EDWSubmissionLogRepository>(new HierarchicalLifetimeManager());
            //container.RegisterType<ISubmissionLogRepository, SubmissionLogRepository>(new HierarchicalLifetimeManager());
            //container.RegisterType<ISSOISEDWSubmissionConfigurationRepository, SSOISEDWSubmissionConfigurationRepository>(new HierarchicalLifetimeManager());

            //container.RegisterType<ISubmissionProcessor, SubmissionProcessDispatcherTest>(new HierarchicalLifetimeManager());
            //container.RegisterType<ISubmissionProcessor, SubmissionProcessor>(DependencyInjectionConstants.DefaultProcessor);

        }

        [TestCleanup]
        public void CleanUp()
        {
            DependencyInjectionHelper.CleanUp();
        }

        [TestMethod()]
        public void ProcessNoDataTest()
        {
            SubmissionMetadata metadata = TestingHelper.MockGIENDOSubmissionMetaData();
            SubmissionSecurityContext context = TestingHelper.MockSecurityContext();

            SubmissionProcessDispatcherTest spd = new SubmissionProcessDispatcherTest(
                TestingHelper.MockSubmissionConfiguration_GIENDO(true), 
                TestingHelper.MockSecurityProvider(),
                TestingHelper.MockIEDWSubmissionLogRepository(),
                TestingHelper.MockISubmissionLogRepository());
            ICollection<SubmissionValidationError> errors = spd.ProcessNoData(metadata, context);

            Assert.AreEqual(errors.Count, 0);
        }

        [TestMethod()]
        [ExpectedException(typeof(TestingHelper.GivenException))]
        public void ProcessNoDataTest_WithOracleError()
        {
            SubmissionMetadata metadata = TestingHelper.MockGIENDOSubmissionMetaData();
            SubmissionSecurityContext context = TestingHelper.MockSecurityContext();

            SubmissionProcessDispatcherTest spd = new SubmissionProcessDispatcherTest(
                TestingHelper.MockSubmissionConfiguration_GIENDO(true), 
                TestingHelper.MockSecurityProvider(),
                TestingHelper.MockIEDWSubmissionLogRepository_ReturnError(),
                TestingHelper.MockISubmissionLogRepository());
            spd.ProcessNoData(metadata, context);
        }

        [TestMethod()]
        [ExpectedException(typeof(TestingHelper.GivenException))]
        public void ProcessNoDataTest_WithSQLError()
        {
            SubmissionMetadata metadata = TestingHelper.MockGIENDOSubmissionMetaData();
            SubmissionSecurityContext context = TestingHelper.MockSecurityContext();

            SubmissionProcessDispatcherTest spd = new SubmissionProcessDispatcherTest(
                TestingHelper.MockSubmissionConfiguration_GIENDO(true), 
                TestingHelper.MockSecurityProvider(),
                TestingHelper.MockIEDWSubmissionLogRepository(),
                TestingHelper.MockISubmissionLogRepository_ReturnError());
            spd.ProcessNoData(metadata, context);
        }

        [TestMethod]
        public void ProcessPackageTest()
        {            
            using (Stream fileStream = File.OpenRead(filepath))
            {
                UploadedFileProperties fileProperties = TestingHelper.MockUploadedFileProperties();
                fileProperties.Name = Path.GetFileName(filepath);
                fileProperties.Size = fileStream.Length;
                SubmissionMetadata metadata = TestingHelper.MockGIENDOSubmissionMetaData();

                SubmissionProcessDispatcherTest spd = new SubmissionProcessDispatcherTest(
                    TestingHelper.MockSubmissionConfiguration_GIENDO(true),
                    TestingHelper.MockSecurityProvider(),
                    TestingHelper.MockIEDWSubmissionLogRepository(),
                    TestingHelper.MockISubmissionLogRepository()
                    );

                ICollection<SubmissionValidationError> validationErrors =
                    spd.ProcessPackage(fileProperties, fileStream, metadata, TestingHelper.MockSecurityContext());

                if (validationErrors.Count > 0) {
                    foreach (SubmissionValidationError err in validationErrors)
                    {
                        System.Diagnostics.Debug.WriteLine($"error: {err.Message}");
                    }
                }
                Assert.AreEqual(0, validationErrors.Count(x => x.type == ValidationErrorType.Error));
                Assert.AreEqual(1, validationErrors.Count(x => x.type == ValidationErrorType.Warning));
            }
        }

        [TestMethod]
        public void ProcessPackageTest_WithError()
        {
            using (Stream fileStream = File.OpenRead(filepath))
            {
                UploadedFileProperties fileProperties = TestingHelper.MockUploadedFileProperties();
                fileProperties.Name = Path.GetFileName(filepath);
                fileProperties.Size = fileStream.Length;
                SubmissionMetadata metadata = TestingHelper.MockGIENDOSubmissionMetaData();

                //set out side of procedure date
                metadata.SubmissionPeriodStart = new DateTime(2015, 01, 01);
                metadata.SubmissionPeriodEnd = new DateTime(2015, 01, 22);

                SubmissionProcessDispatcherTest spd = new SubmissionProcessDispatcherTest(
                    TestingHelper.MockSubmissionConfiguration_GIENDO(true),
                    TestingHelper.MockSecurityProvider(),
                    TestingHelper.MockIEDWSubmissionLogRepository(),
                    TestingHelper.MockISubmissionLogRepository()
                    );

                ICollection<SubmissionValidationError> validationErrors =
                    spd.ProcessPackage(fileProperties, fileStream, metadata, TestingHelper.MockSecurityContext());

                if (validationErrors.Count > 0)
                {
                    foreach (SubmissionValidationError err in validationErrors)
                    {
                        System.Diagnostics.Debug.WriteLine($"error: {err.Message}");
                    }
                }
                Assert.AreEqual(1, validationErrors.Count);
            }
        }

        [TestMethod]
        public void ValidatePackagePropertiesTest() {
            using (Stream fileStream = File.OpenRead(filepath))
            {
                UploadedFileProperties fileProperties = TestingHelper.MockUploadedFileProperties();
                fileProperties.Name = Path.GetFileName(filepath);
                fileProperties.Size = fileStream.Length;
                SubmissionMetadata metadata = TestingHelper.MockGIENDOSubmissionMetaData();

                SubmissionProcessDispatcherTest spd = new SubmissionProcessDispatcherTest(
                    TestingHelper.MockSubmissionConfiguration_GIENDO(true),
                    TestingHelper.MockSecurityProvider(),
                    TestingHelper.MockIEDWSubmissionLogRepository(),
                    TestingHelper.MockISubmissionLogRepository()
                    );

                ICollection<SubmissionValidationError> validationErrors =
                    spd.ValidatePackageProperties(fileProperties, metadata, TestingHelper.MockSecurityContext());

                Assert.AreEqual(validationErrors.Count, 0);
            }
        }

        [TestMethod]
        public void GetProcessorTest() {
            IUnityContainer container = DependencyInjectionHelper.Container;
            container.RegisterType<ISubmissionProcessor, SubmissionProcessor>(DependencyInjectionConstants.DefaultProcessor);  
            container.RegisterType<ISubmissionProcessor, SubmissionProcessor>("GI_ENDO");
            container.RegisterType<ISubmissionConfiguration, SubmissionConfiguration>(new HierarchicalLifetimeManager());
            container.RegisterType<ISecurityProvider, SecurityProvider>();
            container.RegisterType<IPortalConfiguration, FakePortalConfiguration>(new HierarchicalLifetimeManager());
            container.RegisterType<IEDWSubmissionLogRepository, EDWSubmissionLogRepository>(new HierarchicalLifetimeManager());
            container.RegisterType<ISubmissionLogRepository, SubmissionLogRepository>(new HierarchicalLifetimeManager());

            SubmissionMetadata metadata = TestingHelper.MockGIENDOSubmissionMetaData();            

            SubmissionProcessDispatcherTest spd = new SubmissionProcessDispatcherTest(
                TestingHelper.MockSubmissionConfiguration_GIENDO(true), 
                TestingHelper.MockSecurityProvider(), 
                TestingHelper.MockIEDWSubmissionLogRepository(), 
                TestingHelper.MockISubmissionLogRepository());

            ISubmissionProcessor processor1 = spd.GetProcessorBridge(metadata);
            Assert.IsTrue(processor1 is SubmissionProcessor);

            //set to different class
            metadata.SubmissionClassName = "AnyOther";
            ISubmissionProcessor processor2 = spd.GetProcessorBridge(metadata);
            Assert.IsTrue(processor2 is SubmissionProcessor);
          
        }
    }

    public class SubmissionProcessDispatcherTest : SubmissionProcessDispatcher
    {

        protected ISubmissionConfiguration submissionConfiguration;
        protected ISecurityProvider securityProvider;
        protected IEDWSubmissionLogRepository edwSubmissionLogRepository;
        protected ISubmissionLogRepository submissionLogRepository;

        public SubmissionProcessDispatcherTest(
            ISubmissionConfiguration submissionConfiguration,
            ISecurityProvider securityProvider,
            IEDWSubmissionLogRepository edwSubmissionLogRepository,
            ISubmissionLogRepository submissionLogRepository)
        {
            this.submissionConfiguration = submissionConfiguration;
            this.securityProvider = securityProvider;
            this.edwSubmissionLogRepository = edwSubmissionLogRepository;
            this.submissionLogRepository = submissionLogRepository;
        }

        protected override void CheckUserPermissions(SubmissionMetadata metadata, SubmissionSecurityContext securityContext)
        {
            //dont do anything.
        }

        protected override ISubmissionProcessor GetProcessor(SubmissionMetadata metadata)
        {
            return new SubmissionProcessor(submissionConfiguration, securityProvider, edwSubmissionLogRepository, submissionLogRepository);
        }

        public ISubmissionProcessor GetProcessorBridge(SubmissionMetadata metadata) {
            return base.GetProcessor(metadata);
        }
    }

}
