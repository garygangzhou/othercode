﻿using RedApple.BusinessLogic;
using RedApple.Common.Enums;
using RedApple.Common.Utility;
using RedApple.DAL;
using Microsoft.Practices.Unity;
using System.Linq;

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace RedApple.Test
{
    
    /*  Unit Test is working but for TFS Auto Deployment,  it is giving error.  So COMMENTED OUT for now.     */

    /// <summary>
    /// S.L: Unit Testing is created just for the new features (Schedule) as per requirement. 
    /// All Unit Tests can be run independently but it can be slow, since real database is used instead of mock data layer (test Stored procedures + views)
    /// </summary>
    [TestClass]
    public class ScheduleTest
    {

        public ISubmissionConfiguration SubmissionConfiguration
        {
            get
            {
                // Directly create the instance instead of using Unity since it's for Unit Testing
                return new SubmissionConfiguration();
            }
        }

        public IEnumerable<SubmissionClassInfo> AllSubmissionClasses
        {
            get
            {
                return SubmissionConfiguration.GetSubmissionClasses();
            }
        }

        /// <summary>
        /// Initialization
        /// </summary>
        private void Init()
        {
            // Reset all "UseSubmissionSchedule" column flag in SubmissionClass table
            foreach (SubmissionClassInfo item in AllSubmissionClasses)
            {
                SubmissionConfiguration.UpdateUseSubmissionSchedule(item.SubmissionClassName, false);
            }

        }

        /// <summary>
        /// Check if valid to submit
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <param name="submissionClassName"></param>
        /// <param name="reportingPeriodID"></param>
        /// <param name="siteMasterNumber"></param>
        /// <returns></returns>
        private bool IsValidToSubmit(DateTime timeStamp, string submissionClassName, int reportingPeriodID, string siteMasterNumber)
        {
            IEnumerable<SubmissionPeriod> submissionPeriodList;
            submissionPeriodList = SubmissionConfiguration.GetSubmissionPeriodList(timeStamp, submissionClassName, siteMasterNumber, 4).ToList();

            SubmissionPeriod result = submissionPeriodList.Where(a => (string.Equals(a.ReportingPeriodId.ToString(), reportingPeriodID.ToString(), StringComparison.OrdinalIgnoreCase)) &&
                                                       (a.SubmissionPeriodStartDate <= timeStamp) &&
                                                       (timeStamp <= a.SubmissionPeriodEndDate)).FirstOrDefault();


            // If useSubmissionSchedule is enabled:
            //  - result returns as NULL if deadline has passed
            //  - result returns 1 row if within submission period (same one that user selected from dropdown)

            if (result == null)
                return false;
            else
                return true;

        }


        /// <summary>
        /// Test the update on Enable/Disable of Submission Schdule on Program level
        /// </summary>
        [TestMethod]
        public void TestUpdateUseSubmissionSchedule()
        {
            bool useSubmissionScheduleFlag1 = false;
            bool useSubmissionScheduleFlag2 = false;
            Init();

            // Pick the first one for testing
            SubmissionClassInfo submissionClass1 = AllSubmissionClasses.Where(a => a.ReportingPeriodType != null).FirstOrDefault();

            // Data check
            useSubmissionScheduleFlag1 = submissionClass1.UseSubmissionSchedule;
            Assert.AreEqual(false, useSubmissionScheduleFlag1, "Data was not initialized properly, UseSubmissionSchedule flag should be FALSE before testing");

            // Update the db
            useSubmissionScheduleFlag1 = true;  // flip the flag
            SubmissionConfiguration.UpdateUseSubmissionSchedule(submissionClass1.SubmissionClassName, useSubmissionScheduleFlag1);

            // Get the updated record from DB
            SubmissionClassInfo submissionClass2 = AllSubmissionClasses.Where(a => a.SubmissionClassId == submissionClass1.SubmissionClassId).FirstOrDefault();
            useSubmissionScheduleFlag2 = submissionClass2.UseSubmissionSchedule;
            Assert.AreEqual(useSubmissionScheduleFlag1, useSubmissionScheduleFlag2, "UseSubmissionSchedule flags do not matched");

        }


        /// <summary>
        /// Test the update on the SubmissionSchedule (Start/End Date) SubmissionClass Reporting Period level
        /// </summary>
        [TestMethod]
        public void TestUpdateSubmissionSchedule()
        {
            Init();

            // Pick the first one (both submissionClass + reportingPeriod) for testing
            SubmissionClassInfo submissionClass1 = AllSubmissionClasses.Where(a => a.ReportingPeriodType != null).FirstOrDefault();
            ReportingPeriod reportPeriod1 = SubmissionConfiguration.GetReportPeriodList(submissionClass1.SubmissionClassName).FirstOrDefault();

            SubmissionSchedule submissionSchedule1 = SubmissionConfiguration.GetSubmissionSchedule(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId);

            // Set the new Date/Time and update the table
            DateTime startDateTime1 = Convert.ToDateTime("2020-05-01");
            DateTime endDateTime1 = Convert.ToDateTime("2020-06-15");
            SubmissionConfiguration.UpdateSubmissionSchedule(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId, startDateTime1, endDateTime1);

            // Get the updated record from DB
            SubmissionSchedule submissionSchedule2 = SubmissionConfiguration.GetSubmissionSchedule(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId);
            DateTime startDateTime2 = submissionSchedule2.SubmissionPeriodStartDate;
            DateTime endDateTime2 = submissionSchedule2.SubmissionPeriodEndDate;

            Assert.AreEqual(startDateTime1, startDateTime2, "Submission schedule start dates do not matched");
            Assert.AreEqual(endDateTime1, endDateTime2, "Submission schedule end dates do not matched");

        }


        [TestMethod]
        public void TestUpsertOverrideSchedule()
        {
            Init();

            // Pick the first one (both submissionClass + reportingPeriod) for testing
            SubmissionClassInfo submissionClass1 = AllSubmissionClasses.Where(a => a.ReportingPeriodType != null).FirstOrDefault();
            ReportingPeriod reportPeriod1 = SubmissionConfiguration.GetReportPeriodList(submissionClass1.SubmissionClassName).FirstOrDefault();

            IEnumerable<SECURITY_Site> siteList1 = SubmissionConfiguration.GetSites();

            DateTime effectiveStartDate1 = Convert.ToDateTime("2018-03-15");
            int effectiveDays1 = 35;

            // Pick first 2 sites 
            List<int> siteIDlist = new List<int>();
            foreach (var item in siteList1)
            {
                siteIDlist.Add(item.SiteID);
            }

            // Insert new override schedule (2 of them)
            SubmissionConfiguration.UpsertOverrideSchedules(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId, siteIDlist, effectiveStartDate1, effectiveDays1);
            SubmissionScheduleOverride submissionScheduleOverride;

            // Get the updated record from DB [0]
            submissionScheduleOverride = SubmissionConfiguration.GetSubmissionScheduleOverrideList(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId, siteIDlist).ToList()[0];
            Assert.AreEqual(effectiveStartDate1, submissionScheduleOverride.EffectiveDate, "Override effective start dates do not matched");
            Assert.AreEqual(effectiveDays1, submissionScheduleOverride.NumberDaysEffective, "Override number of days effective do not matched");

            // Get the updated record from DB [1]
            submissionScheduleOverride = SubmissionConfiguration.GetSubmissionScheduleOverrideList(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId, siteIDlist).ToList()[1];
            Assert.AreEqual(effectiveStartDate1, submissionScheduleOverride.EffectiveDate, "Override effective start dates do not matched");
            Assert.AreEqual(effectiveDays1, submissionScheduleOverride.NumberDaysEffective, "Override number of days effective do not matched");


        }



        [TestMethod]
        public void TestDeleteOverrideSchedule()
        {
            Init();

            // Pick the first one (both submissionClass + reportingPeriod) for testing
            SubmissionClassInfo submissionClass1 = AllSubmissionClasses.Where(a => a.ReportingPeriodType != null).FirstOrDefault();
            ReportingPeriod reportPeriod1 = SubmissionConfiguration.GetReportPeriodList(submissionClass1.SubmissionClassName).FirstOrDefault();

            IEnumerable<SECURITY_Site> siteList1 = SubmissionConfiguration.GetSites();

            DateTime effectiveStartDate1 = Convert.ToDateTime("2018-04-16");
            int effectiveDays1 = 36;

            // Pick first 2 sites 
            List<int> siteIDlist = new List<int>();
            foreach (var item in siteList1)
            {
                siteIDlist.Add(item.SiteID);
            }

            // Insert new/update override schedule (2 of them)
            SubmissionConfiguration.UpsertOverrideSchedules(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId, siteIDlist, effectiveStartDate1, effectiveDays1);

            // Delete the same items 
            SubmissionConfiguration.DeleteOverrideSchedules(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId, siteIDlist);

            // Get the updated record from DB
            IEnumerable<SubmissionScheduleOverride> submissionScheduleOverrides = SubmissionConfiguration.GetSubmissionScheduleOverrideList(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId, siteIDlist);
            Assert.AreEqual(0, submissionScheduleOverrides.Count(), "Number of deleted records do not matched");


        }


        [TestMethod]
        public void TestSubmitWithScheduleEnabled()
        {
            Init();

            string submissionClassName;
            int reportingPeriodID;
            string masterNumber;
            bool isValidToSbumit;

            // 1. SubmissionClass - Pick the first one for testing
            SubmissionClassInfo submissionClass1 = AllSubmissionClasses.Where(a => a.ReportingPeriodType != null).FirstOrDefault();
            SubmissionConfiguration.UpdateUseSubmissionSchedule(submissionClass1.SubmissionClassName, true); // set to ENABLE schedule

            submissionClassName = submissionClass1.SubmissionClassName;

            // 2. Period - pick the first period for testing
            ReportingPeriod reportPeriod1 = SubmissionConfiguration.GetReportPeriodList(submissionClass1.SubmissionClassName).FirstOrDefault();
            reportingPeriodID = reportPeriod1.ReportingPeriodId;

            // Update the Period Start/End Date to be a specific date/Time for more controlable testing
            DateTime startDateTime1 = Convert.ToDateTime("2015-03-01");
            DateTime endDateTime1 = Convert.ToDateTime("2015-05-15");
            SubmissionConfiguration.UpdateSubmissionSchedule(submissionClass1.SubmissionClassName, reportPeriod1.ReportingPeriodId, startDateTime1, endDateTime1);


            // 3. Site - pick the first site for testing
            SECURITY_Site siteList1 = SubmissionConfiguration.GetSites().FirstOrDefault();
            masterNumber = siteList1.MasterNumber;

            // Call the stored procedure to get the SubmissionPeriod summary
            DateTime timeStamp;

            // Check #1: Deadline passed
            timeStamp = Convert.ToDateTime("2015-05-16");
            isValidToSbumit = IsValidToSubmit(timeStamp, submissionClassName, reportingPeriodID, masterNumber);

            Assert.IsFalse(isValidToSbumit, "Deadline has passed, should not able to submit");

            // Check #2: Within deadline
            timeStamp = Convert.ToDateTime("2015-05-14");
            isValidToSbumit = IsValidToSubmit(timeStamp, submissionClassName, reportingPeriodID, masterNumber);

            Assert.IsTrue(isValidToSbumit, "Within deadline but not able to submit");


            // Check #3: Passed the deadline but with override 
            DateTime overrideEffective = Convert.ToDateTime("2015-05-14"); // set to 1 day before
            int overrideNumberOfDays = 2;  // till 2015-05-16 is still valid
            List<int> siteIDList = new List<int>();
            siteIDList.Add(siteList1.SiteID);
            SubmissionConfiguration.UpsertOverrideSchedules(submissionClassName, reportingPeriodID, siteIDList, overrideEffective, overrideNumberOfDays);

            timeStamp = Convert.ToDateTime("2015-05-16");
            isValidToSbumit = IsValidToSubmit(timeStamp, submissionClassName, reportingPeriodID, masterNumber);

            Assert.IsTrue(isValidToSbumit, "Override has enabled, should be able to submit");


            // Check #4: Change the date with override still on, should not able to submit pass the override date        
            timeStamp = Convert.ToDateTime("2015-05-17");
            isValidToSbumit = IsValidToSubmit(timeStamp, submissionClassName, reportingPeriodID, masterNumber);

            Assert.IsFalse(isValidToSbumit, "Override has enabled, but date has passed. Should not able to submit");

        }
    }
     /*  */
}
