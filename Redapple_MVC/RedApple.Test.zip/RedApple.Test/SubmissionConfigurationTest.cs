﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RedApple.DAL;
using RedApple.BusinessLogic;
using RedApple.Validation;
using System.Linq;
using Moq;

namespace RedApple.Test
{
	[TestClass]
	public class SubmissionConfigurationTest
	{
        #region Test class
        private SubmissionClassInfo Test_SubmissionClassInfoInit() {
            return new SubmissionClassInfo()
            {
                SubmissionClassId = 2,
                Description = "test2",
                SubmissionClassName = "test class2",
                ShowNumberOfPeriods = 3
            };
        }
        [TestMethod]
        public void TestShowNumberOfPeriod()
        {
            var context = new FakePortalConfiguration();
            context.initializeSubmissionClasses(Test_SubmissionClassInfoInit());

            var submissionConfigurationService = new SubmissionConfiguration(context);
            var result = submissionConfigurationService.GetSubmissionShowNumberOfPeriod("test class2");
            Console.Out.WriteLine(result);
            Assert.IsNotNull(result);
        }


        [TestMethod]
		public void TestGetSubmissionClassInfo()
		{
			var context = new FakePortalConfiguration();
			context.initializeSubmissionClasses(Test_SubmissionClassInfoInit());
			var submissionConfigurationService = new SubmissionConfiguration(context);
			var result = submissionConfigurationService.GetSubmissionClassInfo("test class2");
			Assert.IsNotNull(result);
		}
        #endregion
        #region GI ENDO
        private SubmissionClassInfo GI_ENDO_SubmissionClassInfoInit() {
           return  new SubmissionClassInfo()
            {
                SubmissionClassId = 18,
                Description = "test",
                SubmissionClassName = "test class",
                Recordsets = new List<RecordsetInfo>()
                {
                    new RecordsetInfo()
                    {
                        RecordsetId = 9,
                        RecordsetName = "gi_endo",
                        IsRequired = true,
                        Description = "gi_endo recordset",
                        FilenameRegEx = @"^gi_endo_\d\d\d\d\d\d\d_\d\d\d\d\d\d.csv$",
                        IsEmptyFileAllowed = false,
                        SubmissionClassId = 18
                    }
                },
                ShowNumberOfPeriods = 0,
                ReportingPeriodType = new ReportingPeriodType()
                {
                    ReportingPeriodTypeName = "Monthly",
                    ReportingPeriodTypeId = 1,
                    ReportingPeriod = new List<ReportingPeriod>()
                                                           {
                                                                new ReportingPeriod()
                                                                {
                                                                    ReportingPeriodId = 1,
                                                                    ReportingPeriodCode = "201504",
                                                                    ReportingPeriodName = "April, 2015",
                                                                    ReportingPeriodStartDate = new DateTime(2015,05,01),
                                                                    ReportingPeriodEndDate = new DateTime(2015,05,31)
                                                                }
                                                           }
                }

            };
        }
        private void LoadDatahashDictionaryValue_GI_ENDO(DataHash ds)
        {
            ds.Add("Dsp.Package.SubmissionClassId", "18");
            ds.Add("Dsp.Package.ReportingPeriodTypeName", "Monthly");
            ds.Add("Dsp.Package.Filename", "giendo.csv");
            ds.Add("Dsp.Package.AllComissionedSites", "5555,4334,3432,4180");

            ds.Add("Dsp.User.Name", "testLogin");
            ds.Add("Dsp.User.Email", "test@cancercare.on.ca");
            ds.Add("Dsp.User.SiteName", "test site");
            ds.Add("Dsp.User.SiteMasterNumber", "5555123");
            ds.Add("Dsp.User.FacilityName", "Test Facility Site Name");
            ds.Add("Dsp.User.FacilityNumber", "555");

            ds.Add("Dsp.Meta.SubmissionDate", DateTime.Now.ToString("yyyyMMddHHmmss"));
            ds.Add("Dsp.Meta.ReportingPeriodStartDate", "20150501");
            ds.Add("Dsp.Meta.ReportingPeriodEndDate", "20150531"); ds.Add("Dsp.Meta.ReportingPeriodName", "Monthly");
            ds.Add("Dsp.Meta.ReportingPeriodCode", "CURMONTH");
        }
        [TestMethod]
        public void TestValidationRule_GI_ENDO()
        {
            int GIENDO_RecordSetID = 9;
            int GIENDO_SubmissionClassID = 18;

            DataHash hash = new DataHash();
            LoadDatahashDictionaryValue_GI_ENDO(hash);

            var context = new FakePortalConfiguration();
            context.initializeSubmissionClasses(GI_ENDO_SubmissionClassInfoInit());
            
            context.initializeColumnsAndRules("../MockDataFiles/RecordsetColumn.csv", "../MockDataFiles/Rules.csv",0);
           
            var submissionConfigurationService = new SubmissionConfiguration(context);
            //submissionConfigurationService.GetSubmissionValidationRule(GIENDO_RecordSetID, hash);
            List<Validation.ValidationRule> rules = submissionConfigurationService.GetSubmissionValidationRule(GIENDO_RecordSetID);
            hash.Rules.AddRange(rules);

            hash.Recordset = submissionConfigurationService.GetDataFromCsvFile("../MockDataFiles/gi_endo_5555_201504.csv",  "GI_ENDO");            

            ValidationEngine ve = new ValidationEngine();
            ve.Validate(hash);

            if (hash.Errors.Count > 0)
            {
                foreach (ValidationError vr in hash.Errors)
                {
                    Console.Out.WriteLine(vr.RuleId.ToString() + ": " + vr.ColumnName + " - " + vr.ErrorMessage);
                }
            }
            if (hash.FileLevelErrors.Count > 0)
            {
                foreach (ValidationError vr in hash.FileLevelErrors)
                {
                    Console.Out.WriteLine(vr.RuleId.ToString() + ": " + vr.ColumnName + " - " + vr.ErrorMessage);
                }
            }

            Assert.AreEqual(0, hash.Errors.Count);
            Assert.AreEqual(2, hash.FileLevelErrors.Count);
        }

        [TestMethod]
        public void TestDuplicateEntryValidationRule_GI_ENDO()
        {
            int GIENDO_RecordSetID = 9;
            int GIENDO_SubmissionClassID = 18;

            DataHash hash = new DataHash();
            LoadDatahashDictionaryValue_GI_ENDO(hash);

            var context = new FakePortalConfiguration();
            context.initializeSubmissionClasses(GI_ENDO_SubmissionClassInfoInit());
            context.initializeColumnsAndRules("../MockDataFiles/RecordsetColumn.csv", "../MockDataFiles/Rules.csv", 0);

            var submissionConfigurationService = new SubmissionConfiguration(context);
           // submissionConfigurationService.GetSubmissionValidationRule(GIENDO_RecordSetID, hash);
            List<Validation.ValidationRule> rules = submissionConfigurationService.GetSubmissionValidationRule(GIENDO_RecordSetID);
            hash.Rules.AddRange(rules);

            hash.Recordset = submissionConfigurationService.GetDataFromCsvFile("../MockDataFiles/GI_ENDO_5555_201602.csv",  "GI_ENDO");

            ValidationEngine ve = new ValidationEngine();
            ve.Validate(hash);
            
            Assert.AreEqual(4, hash.FileLevelErrors.Count(e => e.isWarning == true));
        }
               
        #endregion
        #region RNFS
        private SubmissionClassInfo RNFS_SubmissionClassInfoInit()
        {
            return new SubmissionClassInfo()
            {
                SubmissionClassId = 17,
                Description = "test",
                SubmissionClassName = "test class",
                Recordsets = new List<RecordsetInfo>()
                {
                    new RecordsetInfo()
                    {
                        RecordsetId = 8,
                        RecordsetName = "RNFS",
                        IsRequired = true,
                        Description = "rnfs recordset",
                        FilenameRegEx = @"^rnfs_\d\d\d\d_\d\d\d\d\d\d.csv$",
                        IsEmptyFileAllowed = false,
                        SubmissionClassId = 17
                    }
                },
                ShowNumberOfPeriods = 0,
                ReportingPeriodType = new ReportingPeriodType()
                {
                    ReportingPeriodTypeName = "Monthly",
                    ReportingPeriodTypeId = 1,
                    ReportingPeriod = new List<ReportingPeriod>()
                                                           {
                                                                new ReportingPeriod()
                                                                {
                                                                    ReportingPeriodId = 1,
                                                                    ReportingPeriodCode = "201502",
                                                                    ReportingPeriodName = "Feburary, 2015",
                                                                    ReportingPeriodStartDate = new DateTime(2015,02,01),
                                                                    ReportingPeriodEndDate = new DateTime(2015,02,28)
                                                                }
                                                           }
                }

            };
        }
        private void LoadDatahashDictionaryValue_RNFS(DataHash ds)
        {
            ds.Add("Dsp.Package.SubmissionClassId", "17");
            ds.Add("Dsp.Package.ReportingPeriodTypeName", "Monthly");
            ds.Add("Dsp.Package.Filename", "rnfs.csv");
            ds.Add("Dsp.Package.AllComissionedSites", "5555,4334,3432,4180");

            ds.Add("Dsp.User.Name", "testLogin");
            ds.Add("Dsp.User.Email", "test@cancercare.on.ca");
            ds.Add("Dsp.User.SiteName", "test site");
            ds.Add("Dsp.User.SiteMasterNumber", "5555123");
            ds.Add("Dsp.User.FacilityName", "Test Facility Site Name");
            ds.Add("Dsp.User.FacilityNumber", "555");

            ds.Add("Dsp.Meta.SubmissionDate", DateTime.Now.ToString("yyyyMMddHHmmss"));
            ds.Add("Dsp.Meta.ReportingPeriodStartDate", "20150501");
            ds.Add("Dsp.Meta.ReportingPeriodEndDate", "20150531"); ds.Add("Dsp.Meta.ReportingPeriodName", "Monthly");
            ds.Add("Dsp.Meta.ReportingPeriodCode", "CURMONTH");
        }
        [TestMethod]
        public void TestValidationRule_RNFS() {
            int RNFS_RecordSetID = 8;
            int RNFS_SubmissionClassID = 17;

            DataHash hash = new DataHash();
            LoadDatahashDictionaryValue_RNFS(hash);

            var context = new FakePortalConfiguration();
            context.initializeSubmissionClasses(RNFS_SubmissionClassInfoInit());
            context.initializeColumnsAndRules("../MockDataFiles/RecordsetColumn.csv", "../MockDataFiles/Rules.csv", 0);

            var submissionConfigurationService = new SubmissionConfiguration(context);
            //submissionConfigurationService.GetSubmissionValidationRule(RNFS_RecordSetID, hash);
            List<Validation.ValidationRule> rules = submissionConfigurationService.GetSubmissionValidationRule(RNFS_RecordSetID);
            hash.Rules.AddRange(rules);

            hash.Recordset = submissionConfigurationService.GetDataFromCsvFile("../MockDataFiles/RNFS_4180_201502.csv",  "RNFS");

            ValidationEngine ve = new ValidationEngine();
            ve.Validate(hash);
            if (hash.Errors.Count > 0)
            {
                foreach (ValidationError err in hash.Errors) {
                    System.Diagnostics.Debug.WriteLine($"{err.RowNum}:{err.RuleId}:{err.ErrorMessage}");
                }    
            }
            Assert.AreEqual(0, hash.Errors.Count);
            //Assert.AreEqual(4, hash.FileLevelErrors.Count(e => e.isWarning == true));
        }
        #endregion

    }
}
