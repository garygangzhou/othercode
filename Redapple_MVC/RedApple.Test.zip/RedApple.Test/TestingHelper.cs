﻿using RedApple.BusinessLogic;
using RedApple.DAL;
using RedApple.MVC.Web.Helpers;
using Moq;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using LumenWorks.Framework.IO.Csv;
using System.Data;

namespace RedApple.Test
{
    /// <summary>
    /// internal helper class
    /// mock necessary objects for testing
    /// </summary>
    internal class TestingHelper
    {
        internal static ISubmissionConfiguration MockSubmissionConfiguration_GIENDO(bool loadRulesAndData = false)
        {
            Mock<ISubmissionConfiguration> obj = new Mock<ISubmissionConfiguration>();
            SECURITY_Facility sf = MockSubmissionFacilitys().First();
            SECURITY_Site ss = MockSubmissionClassUserSites().First();
            obj.Setup(x => x.GetSiteByNumber(It.IsAny<string>())).Returns(ss);
            obj.Setup(x => x.GetSiteFacility(It.IsAny<SECURITY_Site>())).Returns(sf);

            IEnumerable<SubmissionClassInfo> sci = MockSubmissionClassInfoList();
            obj.Setup(x => x.GetSubmissionClassInfo(It.IsAny<string>())).Returns(sci.First());
            obj.Setup(x => x.GetSubmissionClasses()).Returns(sci);
            obj.Setup(x => x.ValidatePackageFileName(It.IsAny<SubmissionMetadata>(), It.IsAny<string>())).Returns(true);
            obj.Setup(x => x.GetNoCaseSubmissionReasonBySubmissionClass(It.IsAny<string>())).Returns(GetNoCaseSubmissionReasons_GI_ENDO);
            obj.Setup(x => x.IsSubmissionScheduleDefined("GI_ENDO")).Returns(true);
            obj.Setup(x => x.IsSubmissionScheduleEnabled("GI_ENDO")).Returns(true);
            obj.Setup(x => x.GetSubmissionShowNumberOfPeriod("GI_ENDO")).Returns(4);
            obj.Setup(x => x.GetSubmissionPeriodList(It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>())).Returns(MockSubmissionPeriodList_GI_ENDO());
            obj.Setup(x => x.IsAllowedOverrideDateTime).Returns(true);
            obj.Setup(x => x.UploadFolder).Returns(@"../MockDataFiles");
            obj.Setup(x => x.GetSubmissionClassSecurityRoles("GI_ENDO")).Returns(MockGI_ENDOSecurityRoles);
            obj.Setup(x => x.GetSitesByRoleList(It.IsAny<IEnumerable<SECURITY_Role>>())).Returns(MockSubmissionClassUserSites());
            obj.Setup(x => x.HasPeviousLoadBySiteNumberReportingPeriodId("GI_ENDO", It.IsAny<string>(), It.IsAny<int>())).Returns(true);

            if (loadRulesAndData)
            {
                obj.Setup(x => x.GetSubmissionValidationRule(It.IsAny<int>())).Returns(LoadValidationRulesFromCsvFile(@"../MockDataFiles/RulesGI_ENDO.csv"));
                obj.Setup(x => x.GetDataFromCsvFile(It.IsAny<string>(), It.IsAny<string>())).Returns(LoadDataFromCsvFile(@"../MockDataFiles/gi_endo_5555_201504.csv"));
            }

            return obj.Object;
        }

        internal static IEnumerable<SubmissionPeriod> MockSubmissionPeriodList_GI_ENDO()
        {
            return new List<SubmissionPeriod>() {
                new SubmissionPeriod {
                    SubmissionClassId = 18,
                    ReportingPeriodId = 260,
                    ReportingPeriodStartDate = DateTime.Parse("2017-04-01"),
                    ReportingPeriodEndDate = DateTime.Parse("2017-04-30"),
                    SubmissionPeriodStartDate = DateTime.Parse("2017-05-01"),
                    SubmissionPeriodEndDate = DateTime.Parse("2017-06-01"),
                    ReportingPeriodName = "2017, April",
                    HasOverridden = false,
                    IsCurrentPeriod = false
                },
                new SubmissionPeriod {
                    SubmissionClassId = 18,
                    ReportingPeriodId = 261,
                    ReportingPeriodStartDate = DateTime.Parse("2017-05-01"),
                    ReportingPeriodEndDate = DateTime.Parse("2017-05-31"),
                    SubmissionPeriodStartDate = DateTime.Parse("2017-06-01"),
                    SubmissionPeriodEndDate = DateTime.Parse("2017-07-01"),
                    ReportingPeriodName = "2017, May",
                    HasOverridden = false,
                    IsCurrentPeriod = false
                },
                new SubmissionPeriod {
                    SubmissionClassId = 18,
                    ReportingPeriodId = 262,
                    ReportingPeriodStartDate = DateTime.Parse("2017-06-01"),
                    ReportingPeriodEndDate = DateTime.Parse("2017-06-30"),
                    SubmissionPeriodStartDate = DateTime.Parse("2017-07-01"),
                    SubmissionPeriodEndDate = DateTime.Parse("2017-08-01"),
                    ReportingPeriodName = "2017, June",
                    HasOverridden = false,
                    IsCurrentPeriod = false
                },
               new SubmissionPeriod {
                    SubmissionClassId = 18,
                    ReportingPeriodId = 263,
                    ReportingPeriodStartDate = DateTime.Parse("2017-07-01"),
                    ReportingPeriodEndDate = DateTime.Parse("2017-07-31"),
                    SubmissionPeriodStartDate = DateTime.Parse("2017-08-01"),
                    SubmissionPeriodEndDate = DateTime.Parse("2017-09-1"),
                    ReportingPeriodName = "2017, July",
                    HasOverridden = false,
                    IsCurrentPeriod = true
                },
            };
        }

        internal static ISecurityProvider MockSecurityProvider()
        {
            Mock<ISecurityProvider> provider = new Mock<ISecurityProvider>();
            provider.Setup(x => x.HasPermissions(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(true);
            provider.Setup(x => x.GetUserInfo(It.IsAny<string>())).Returns(MockApplicationUser());
            provider.Setup(x => x.GetUserSubmissionClasses(It.IsAny<string>())).Returns(MockSubmissionClassInfoList());
            provider.Setup(x => x.GetSubmissionClassUserSites(It.IsAny<string>(), It.IsAny<string>())).Returns(MockSubmissionClassUserSites());

            return provider.Object;
        }

        internal static IEnumerable<SECURITY_Facility> MockSubmissionFacilitys()
        {
            SECURITY_Facility sf = new SECURITY_Facility() {
                FacilityName = "CCO Test Facility",
                FacilityNumber = "555"
            };
            return new List<SECURITY_Facility>() { sf };
        }

        internal static IEnumerable<SECURITY_Site> MockSubmissionClassUserSites()
        {
            SECURITY_Site ss = new SECURITY_Site()
            {
                MasterNumber = "5555",
                SiteName = "CCO testing site"
            };

            return new List<SECURITY_Site>() { ss };
        }

        internal static ApplicationUser MockApplicationUser()
        {
            return new ApplicationUser
            {
                UserId = 12345,
                DisplayName = "DisplayName: LogonNmae",
                LogonName = "logonName",
                EMail = "test@test.com",
                EULA = new DateTime(2015, 1, 1)
            };
        }

        internal static IEnumerable<SubmissionClassInfo> MockSubmissionClassInfoList()
        {          

            return new List<SubmissionClassInfo>() { MockSubmissionClassInfo_GIENDO(true), MockSubmissionClassInfo_RNFS() };
        }

        internal static SubmissionClassInfo MockSubmissionClassInfo_GIENDO(bool loadRecordSet = false )
        {
            //GI ENDO
            SubmissionClassInfo sci_gi_endo = new SubmissionClassInfo()
            {
                NoCaseSubmissionReasons = GetNoCaseSubmissionReasons_GI_ENDO(),
                SubmissionClassId = 18,
                Description = "GI ENDO",
                SubmissionClassName = "GI_ENDO",
                PackageFilenameRegEx = @"^gi_endo_(\d{4}|\d{7})_\d{6}.csv$",
                Version = 2,
                Recordsets = new List<RecordsetInfo>()
                {
                    new RecordsetInfo()
                    {
                        RecordsetId = 9,
                        RecordsetName = "gi_endo",
                        IsRequired = true,
                        Description = "gi_endo recordset",
                        FilenameRegEx = @"^gi_endo_(\d{4}|\d{7})_\d{6}.csv$",
                        IsEmptyFileAllowed = false,
                        SubmissionClassId = 18,
                        TemplateFilePath = "",
                        TemplateFileMIMEType = @"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    }
                },
                ShowNumberOfPeriods = 4,
                ReportingPeriodType = new ReportingPeriodType()
                {
                    ReportingPeriodTypeName = "Monthly",
                    ReportingPeriodTypeId = 2,
                    ReportingPeriod = new List<ReportingPeriod>()
                                                           {
                                                                new ReportingPeriod()
                                                                {
                                                                    ReportingPeriodId = 1,
                                                                    ReportingPeriodCode = "201504",
                                                                    ReportingPeriodName = "April, 2015",
                                                                    ReportingPeriodStartDate = new DateTime(2015,05,01),
                                                                    ReportingPeriodEndDate = new DateTime(2015,05,31)
                                                                }
                                                           }


                }

            };
            if (loadRecordSet)
            {
                LoadRecordsetColumnsFromCsvFile(@"../MockDataFiles/RecordsetColumnGI_ENDO.csv", sci_gi_endo.Recordsets.First());
            }

            return  sci_gi_endo ;
        }

        private static void LoadRecordsetColumnsFromCsvFile(string filePath, RecordsetInfo sci)
        {

            using (CsvReader csv = new CsvReader(
                   new System.IO.StreamReader(filePath), true))
            {
                while (csv.ReadNextRecord())
                {
                    sci.RecordsetColumns.Add(
                        new RecordsetColumnInfo()
                        {
                            RecordsetColumnId = Convert.ToInt16(csv[0]),
                            RecordsetColumnName = csv[2],
                            RecordsetColumnSequence = Convert.ToInt16(csv[3]),
                            RecordsetId = Convert.ToInt16(csv[1])
                        }
                    );
                }
            }
        }

        internal static SubmissionClassInfo MockSubmissionClassInfo_RNFS()
        {
            //RNFS
            SubmissionClassInfo sci_rnfs = new SubmissionClassInfo()
            {
                NoCaseSubmissionReasons = new List<NoCaseSubmissionReasons>(),
                SubmissionClassId = 17,
                Description = "test",
                SubmissionClassName = "RNFS",
                PackageFilenameRegEx = @"^rnfs_\\d\\d\\d\\d_\\d\\d\\d\\d\\d\\d.csv$",
                Version = 2,
                Recordsets = new List<RecordsetInfo>()
                {
                    new RecordsetInfo()
                    {
                        RecordsetId = 8,
                        RecordsetName = "RNFS",
                        IsRequired = true,
                        Description = "RNFS template",
                        FilenameRegEx = @"^rnfs_\d\d\d\d_\d\d\d\d\d\d.csv$",
                        IsEmptyFileAllowed = true,
                        SubmissionClassId = 17,
                        TemplateFilePath = "",
                        TemplateFileMIMEType = @"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    }
                },
                ShowNumberOfPeriods = 4,
                ReportingPeriodType = new ReportingPeriodType()
                {
                    ReportingPeriodTypeName = "Monthly",
                    ReportingPeriodTypeId = 2,
                    ReportingPeriod = new List<ReportingPeriod>()
                                                           {
                                                                new ReportingPeriod()
                                                                {
                                                                    ReportingPeriodId = 260,
                                                                    ReportingPeriodCode = "201704",
                                                                    ReportingPeriodName = "2017, April",
                                                                    ReportingPeriodStartDate = new DateTime(2017,04,01),
                                                                    ReportingPeriodEndDate = new DateTime(2017,04,30)
                                                                }
                                                           }


                }
            };

            return sci_rnfs;
        }

        internal static List<NoCaseSubmissionReasons> GetNoCaseSubmissionReasons_GI_ENDO()
        {
            return new List<NoCaseSubmissionReasons>()
                {
                        new NoCaseSubmissionReasons() {
                            NoCaseSubmissionReasonId = 1,
                            Text = "No Visiting Surgeon",
                            SubmissionClassId = 18,
                            SortOrder = 0
                        },

                        new NoCaseSubmissionReasons() {
                            NoCaseSubmissionReasonId = 2,
                            Text = "No Procedures Performed",
                            SubmissionClassId = 18,
                            SortOrder = 1
                        },

                        new NoCaseSubmissionReasons() {
                            NoCaseSubmissionReasonId = 4,
                            Text = @"Permanent Closure (eg. Hospital\Site)",
                            SubmissionClassId = 18,
                            SortOrder = 3
                        },

                        new NoCaseSubmissionReasons() {
                            NoCaseSubmissionReasonId = 5,
                            Text = "Other",
                            SubmissionClassId = 18,
                            SortOrder = 4
                        },

                        new NoCaseSubmissionReasons() {
                            NoCaseSubmissionReasonId = 6,
                            Text = @"Temporary Closure (eg. OR\Endoscopy Suite\Renovation)",
                            SubmissionClassId = 18,
                            SortOrder = 2
                        },
                };
        }

        internal static  List<SECURITY_Role> MockGI_ENDOSecurityRoles()
        {
            List<SECURITY_Role> roles = new List<SECURITY_Role>();
            SECURITY_Role role = new SECURITY_Role()
            {
                RoleID = 18,
                Description = "GI_ENDO_Uploader",
                RoleName = "GI_ENDO_Uploader"
            };
            roles.Add(role);
            return roles;
        }

        internal static List<Validation.ValidationRule> LoadValidationRulesFromCsvFile(string rulesFilePath)
        {
            List<Validation.ValidationRule> rules = new List<Validation.ValidationRule>();

            using (CsvReader csv = new CsvReader(
                   new System.IO.StreamReader(rulesFilePath), true))
            {

                while (csv.ReadNextRecord())
                {
                    rules.Add(new Validation.ValidationRule()
                    {
                        Id = Convert.ToInt16(csv["ValidationRuleId"]),
                        Expression = csv["ValidationExpression"],
                        ValidatorType = csv["ValidatorType"],
                        ErrorMessage = csv["ErrorMessageTemplate"],
                        IsNegated = (Convert.ToInt16(csv["IsNegated"]) == 1 ? true : false),
                        FieldName = csv["RecordsetColumnName"],
                        RejectionActionFlag = csv["RejectionActionFlag"],
                        RuleCode = csv["ValidationRuleCode"],
                        FileLevelValidation = csv["FileLevelValidation"] == "1" ? true : false,
                        IsWarning = csv["IsWarning"] == "1" ? true : false,
                        FileLevelValidationColumns = csv["DuplicateEntryValidatorColumns"].Split('+').ToList<string>()
                    });
                }
            }
            return rules;
        }

        internal static DataTable LoadDataFromCsvFile(string filePath)
        {
            return new SubmissionConfiguration().GetDataFromCsvFile(filePath, "GI_ENDO");
        }

        internal static SubmissionMetadata MockGIENDOSubmissionMetaData()
        {
            SubmissionMetadata metaData = new SubmissionMetadata();
            metaData.SubmissionClassName = "GI_ENDO";
            metaData.SubmissionSiteNumber = "5555";
            metaData.Version = 2;
            metaData.SubmissionPeriodStart = new DateTime(2015, 05, 1);
            metaData.SubmissionPeriodEnd = new DateTime(2015, 05, 31);
            metaData.SubmissionPeriodCode = "201504";
            return metaData;
        }

        internal static SubmissionSecurityContext MockSecurityContext()
        {
            SubmissionSecurityContext context = new SubmissionSecurityContext();
            context.UserInfo = MockApplicationUser();

            return context;
        }

        internal static UploadedFileProperties MockUploadedFileProperties()
        {
            UploadedFileProperties fileProperties = new UploadedFileProperties()
            {
                Name = "gi_endo_5555_201504.csv",
                Size = 1112,
                FileSubmissionTime = new DateTime(2015, 06, 02)
            };
            return fileProperties;
        }

        internal static IEDWSubmissionLogRepository MockIEDWSubmissionLogRepository()
        {
            Mock<IEDWSubmissionLogRepository> obj = new Mock<IEDWSubmissionLogRepository>();
            obj.Setup(x => x.InsertDataSubmissionEventDirect(It.IsAny<DATA_SUBMISSION_EVENT>())).Returns(9999);
            obj.Setup(x => x.GetDataSubmissionEventById(It.IsAny<long>())).Returns(new DATA_SUBMISSION_EVENT());
            obj.Setup(x => x.UpdateDataSubmissionEventDirect(It.IsAny<DATA_SUBMISSION_EVENT>()));
            return obj.Object;
        }

        internal static IEDWSubmissionLogRepository MockIEDWSubmissionLogRepository_ReturnError()
        {
            Mock<IEDWSubmissionLogRepository> obj = new Mock<IEDWSubmissionLogRepository>();
            obj.Setup(x => x.InsertDataSubmissionEventDirect(It.IsAny<DATA_SUBMISSION_EVENT>())).Throws(new GivenException());
            obj.Setup(x => x.GetDataSubmissionEventById(It.IsAny<long>())).Returns(new DATA_SUBMISSION_EVENT());
            obj.Setup(x => x.UpdateDataSubmissionEventDirect(It.IsAny<DATA_SUBMISSION_EVENT>()));
            return obj.Object;
        }

        internal static ISubmissionLogRepository MockISubmissionLogRepository()
        {
            Mock<ISubmissionLogRepository> obj = new Mock<ISubmissionLogRepository>();
            obj.Setup(x => x.GetSubmissionEventById(It.IsAny<long>())).Returns(new SubmissionEvent());
            obj.Setup(x => x.InsertSubmissionEventDirect(It.IsAny<SubmissionEvent>()));
            obj.Setup(x => x.UpdateSubmissionEventDirect(It.IsAny<SubmissionEvent>()));
            return obj.Object;
        }

        internal static ISubmissionLogRepository MockISubmissionLogRepository_ReturnError()
        {
            Mock<ISubmissionLogRepository> obj = new Mock<ISubmissionLogRepository>();
            obj.Setup(x => x.GetSubmissionEventById(It.IsAny<long>())).Returns(new SubmissionEvent());
            obj.Setup(x => x.InsertSubmissionEventDirect(It.IsAny<SubmissionEvent>())).Throws(new GivenException());
            obj.Setup(x => x.UpdateSubmissionEventDirect(It.IsAny<SubmissionEvent>()));
            return obj.Object;
        }

        internal static ISubmissionProcessor MockSubmissionProcessor() {
            Mock<ISubmissionProcessor> obj = new Mock<ISubmissionProcessor>();
            obj.Setup(x => x.ProcessNoData(It.IsAny<SubmissionMetadata>(), It.IsAny<SubmissionSecurityContext>())).Returns( new List<BusinessLogic.SubmissionValidationError>());
            obj.Setup(x => x.ProcessPackage(It.IsAny<UploadedFileProperties>(), It.IsAny<System.IO.Stream>(), It.IsAny<SubmissionMetadata>(), It.IsAny<SubmissionSecurityContext>())).Returns(new List<BusinessLogic.SubmissionValidationError>());
            obj.Setup(x => x.ValidatePackageProperties(It.IsAny<UploadedFileProperties>(), It.IsAny<SubmissionMetadata>(), It.IsAny<SubmissionSecurityContext>())).Returns(new List<BusinessLogic.SubmissionValidationError>());
            return obj.Object;
        }
      
        //mock http context for web testing
        internal class ContextMocks
        {
            public Mock<HttpContextBase> HttpContext { get; private set; }
            public Mock<HttpRequestBase> Request { get; private set; }
            public Mock<HttpResponseBase> Response { get; private set; }
            public RouteData RouteData { get; private set; }
            public ContextMocks(Controller onController)
            {
                // Define all the common context objects, plus relationships between them
                HttpContext = new Mock<HttpContextBase>();
                Request = new Mock<HttpRequestBase>();
                Response = new Mock<HttpResponseBase>();
                HttpContext.Setup(x => x.Request).Returns(Request.Object);
                HttpContext.Setup(x => x.Response).Returns(Response.Object);
                HttpContext.Setup(x => x.Session).Returns(new FakeSessionState());
                Request.Setup(x => x.Cookies).Returns(new HttpCookieCollection());
                Response.Setup(x => x.Cookies).Returns(new HttpCookieCollection());
                Request.Setup(x => x.QueryString).Returns(new NameValueCollection());
                Request.Setup(x => x.Form).Returns(new NameValueCollection());
                Request.Setup(x => x.UserHostAddress).Returns("http://localhost/dsp");

                // Apply the mock context to the supplied controller instance
                RequestContext rc = new RequestContext(HttpContext.Object, new RouteData());
                HttpContextManager.SetCurrentContext(HttpContext.Object);

                onController.ControllerContext = new ControllerContext(rc, onController);
            }

            private class FakeSessionState : HttpSessionStateBase
            {
                Dictionary<string, object> items = new Dictionary<string, object>();
                Guid id = Guid.NewGuid();
                public override object this[string name]
                {
                    get { return items.ContainsKey(name) ? items[name] : null; }
                    set { items[name] = value; }
                }

                public override void Add(string name, object value)
                {
                    items.Add(name, value);
                }

                public override string SessionID
                {
                    get
                    {
                        return id.ToString();
                    }
                }
            }
        }

        internal class GivenException : Exception { }
    }
}
