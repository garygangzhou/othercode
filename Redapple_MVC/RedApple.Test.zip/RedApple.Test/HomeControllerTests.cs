﻿using RedApple.BusinessLogic;
using RedApple.MVC.Web;
using RedApple.MVC.Web.Controllers;
using RedApple.MVC.Web.Helpers;
using RedApple.MVC.Web.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Specialized;
using System.Web.Mvc;

namespace RedApple.Test
{
    [TestClass]
    public class HomeControllerTests
    {
        [TestMethod]
        [TestCategory("Web_HomeController")]
        public void Index_View_Test()
        {
            HomeController hc = InitHomeController();
            ActionResult view = hc.Index();

            //check for ?
            Assert.IsNotNull(view);
        }

        [TestMethod]
        [TestCategory("Web_HomeController")]
        public void Index_Upload_Test() {
            SubmissionViewModel vm = new SubmissionViewModel();
            SubmissionUserInput input = vm.Inputs;
            input.SubmissionClass = "GI_ENDO";
            input.FacilitySites = "5555";
            input.SubmissionPeriodID = 262;
            input.NoCase = true;
            input.NoCaseReaseonID = 1;

            HomeController hc = InitHomeController();
            hc.Request.Form.Add("hiddenbox", "");
            hc.Request.QueryString["DateTime"] = "2017-07-02";

            ActionResult view = hc.Index(vm, null);

            //check for ?
            Assert.IsNotNull(view);
        }

        [TestMethod]
        [TestCategory("Web_HomeController")]
        public void Dcouments_View_Test()
        {
            HomeController hc = InitHomeController();
            ActionResult view = hc.Documents();

            //check for ?
            Assert.IsNotNull(view);

        }

        [TestMethod]
        [TestCategory("Web_HomeController")]
        public void CheckPreviousLoad_Test() {
            HomeController hc = InitHomeController();
            ActionResult ar = hc.CheckPreviousLoad("GI_ENDO", "5555", "262");

            Assert.IsNotNull(ar);
            Assert.IsTrue((bool.Parse((ar as JsonResult).Data.ToString())));
        }

        [TestMethod]
        [TestCategory("Web_HomeController")]
        public void Contactus_View_Test()
        {
            HomeController hc = InitHomeController();
            ActionResult view = hc.Contactus();

            //check for ?
            Assert.IsNotNull(view);
        }

        [TestMethod]
        [TestCategory("Web_HomeController")]
        public void SubmissionCustomBinderTest()
        {
            NameValueCollection values = GetValues();
            ModelBindingContext mbc = new ModelBindingContext()
            {
                ModelName = "SubmissionViewModel",
                ValueProvider = new NameValueCollectionValueProvider(values, null),
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(null, typeof(SubmissionViewModel))               
            };

            SubmissioCustomBinder binder = new SubmissioCustomBinder();
            SubmissionViewModel vm = binder.BindModel(null, mbc) as SubmissionViewModel;

            Assert.AreEqual(values["submissionclasses"], vm.Inputs.SubmissionClass);
            Assert.AreEqual(values["facilitysites"], vm.Inputs.FacilitySites);
            Assert.AreEqual(values["submissionperiod"], vm.Inputs.SubmissionPeriodID.ToString());
            Assert.AreEqual(-1, vm.Inputs.NoCaseReaseonID);
            Assert.IsFalse(vm.Inputs.NoCase);
        }

        [TestMethod]
        [TestCategory("Web_HomeController")]
        public void SubmissionCustomBinderTest2()
        {
            NameValueCollection values = GetValues2();
            ModelBindingContext mbc = new ModelBindingContext()
            {
                ModelName = "SubmissionViewModel",
                ValueProvider = new NameValueCollectionValueProvider(values, null),
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(null, typeof(SubmissionViewModel))
            };

            SubmissioCustomBinder binder = new SubmissioCustomBinder();
            SubmissionViewModel vm = binder.BindModel(null, mbc) as SubmissionViewModel;

            Assert.AreEqual(values["submissionclasses"], vm.Inputs.SubmissionClass);
            Assert.AreEqual(values["facilitysites"], vm.Inputs.FacilitySites);
            Assert.AreEqual(values["submissionperiod"], vm.Inputs.SubmissionPeriodID.ToString());
            Assert.AreEqual(45, vm.Inputs.NoCaseReaseonID);
            Assert.IsTrue(vm.Inputs.NoCase);
        }

        private static NameValueCollection GetValues()
        {
            return new NameValueCollection() {
                        {"submissionclasses", "TestingSubmissionClass" },
                        {"facilitysites", "5555" },
                        {"submissionperiod", "23" },
                        {"nocasesreasons", "45" },
                        {"chknocasestosubmit", "" }
                    };
        }

        private static NameValueCollection GetValues2()
        {
            return new NameValueCollection() {
                        {"submissionclasses", "TestingSubmissionClass" },
                        {"facilitysites", "5555" },
                        {"submissionperiod", "23" },
                        {"nocasesreasons", "45" },
                        {"chknocasestosubmit", "on" }
                    };
        }

        private static HomeController InitHomeController()
        {
            ISubmissionConfiguration sc = TestingHelper.MockSubmissionConfiguration_GIENDO(false);
            ISecurityProvider sp = TestingHelper.MockSecurityProvider();
            ISubmissionProcessor processor = TestingHelper.MockSubmissionProcessor();

            HomeController hc = new HomeController(sc, sp, processor);
            new TestingHelper.ContextMocks(hc);

            //add a user to session
            HttpContextManager.Current.Session.Add(Constants.SessionKeys.UserInfo, TestingHelper.MockApplicationUser());
            return hc;
        }
    }
}
