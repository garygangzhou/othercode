﻿using CCO.UMA.UMAAPIClient;
using RedApple.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic
{
    public class SecurityProvider : ISecurityProvider
    {
        public const string AdminRolePostfix = "Admin";
        public const string UploaderRolePostfix = "Uploader";

        public const string UploadAccessRightPostfix = "Upload";
        public const string ReportAccessRightPostfix = "Report";


        private UmaApplicationUser umaUser;

        private ISubmissionConfiguration submissionConfiguration;

        public SecurityProvider(ISubmissionConfiguration submissionConfiguration)
        {
            this.submissionConfiguration = submissionConfiguration;
        }

        public ApplicationUser GetUserInfo(string logonName)
        {
            LoadUmaUser(logonName);            
            if (umaUser == null)
            {
                return null;
            }
            else
            {                
                return new ApplicationUser 
                { 
                    UserId = umaUser.UserId,
                    DisplayName = umaUser.DisplayName,
                    LogonName = umaUser.UserName,
                    EMail = umaUser.Email,
                    EULA = GetEulaDate(umaUser.UserId)                                        
                };
            }
        }

        public IEnumerable<SubmissionClassInfo> GetUserSubmissionClasses(string logonName)
        {
            LoadUmaUser(logonName);
            if (umaUser == null)
            {
                return new List<SubmissionClassInfo>();
            }

            return submissionConfiguration.GetSubmissionClassesByRoleNameList(umaUser.GetRoles());
        }

        public IEnumerable<SECURITY_Site> GetSubmissionClassUserSites(string logonName, string submissionClassName)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            LoadUmaUser(logonName);
            if (umaUser == null)
            {
                return new List<SECURITY_Site>();
            }

            var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(submissionClassName);
            var nonAdminRoles = GetNonAdminRoles(submissionClassRoles);
            // assume that all submissionClass sites are linked to submissionClass through non-admin roles (according to Lalin)
            var sites = submissionConfiguration.GetSitesByRoleList(nonAdminRoles);

            if (IsSubmissionClassAdmin(submissionClassRoles))
            {
                return sites;
            }
            else
            {
                var q = from s in umaUser.GetSites()
                        from scr in nonAdminRoles
                        where umaUser.IsInRole(scr.RoleName, s)
                        join ss in sites on s equals ss.SiteID
                        select ss;

                return q.ToList();
            }
        }
        
        public bool HasPermissions(string logonName, string submissionClassName, string submissionSiteNumber, string accessRight)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            if (string.IsNullOrWhiteSpace(submissionSiteNumber))
            {
                throw new ArgumentNullException("submissionSiteNumber");
            }

            if (string.IsNullOrWhiteSpace(accessRight))
            {
                throw new ArgumentNullException("accessRight");
            }

            bool hasPermissions = false;

            LoadUmaUser(logonName);
            if (umaUser != null)
            {
                var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(submissionClassName);

                if (IsSubmissionClassAdmin(submissionClassRoles))
                {
                    hasPermissions = true;
                }
                else
                {
                    var siteInfo = submissionConfiguration.GetSiteByNumber(submissionSiteNumber);
                    hasPermissions = submissionClassRoles.Any(r => umaUser.IsInRole(r.RoleName, siteInfo.SiteID)
                        && r.SECURITY_RoleAccessRight.Any(rar => rar.SECURITY_AccessRight.AccessRightName.Equals(accessRight, StringComparison.OrdinalIgnoreCase)));                    
                }
            }

            return hasPermissions;
        }

        public IEnumerable<ReportInfo> GetUserReports(string logonName)
        {
            LoadUmaUser(logonName);
            if (umaUser == null)
            {
                return new List<ReportInfo>();
            }

            return submissionConfiguration.GetReportsByAccessRightNameList(
                submissionConfiguration.GetSecurityRoles()
                .Where(r => umaUser.IsInRole(r.RoleName))
                .SelectMany(r => r.SECURITY_RoleAccessRight.Select(rar => rar.SECURITY_AccessRight.AccessRightName))
                .Distinct()
                );
        }

        public IEnumerable<ReportInfo> GetSubmissionClassUserReports(string logonName, string submissionClassName)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            LoadUmaUser(logonName);
            if (umaUser == null)
            {
                return new List<ReportInfo>();
            }

            var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(submissionClassName);

            return submissionConfiguration.GetReportsByAccessRightNameList(
                submissionClassRoles
                .Where(r => umaUser.IsInRole(r.RoleName))
                .SelectMany(r => r.SECURITY_RoleAccessRight.Select(rar => rar.SECURITY_AccessRight.AccessRightName))
                .Distinct()
                );
        }

        public IEnumerable<ReportInfo> GetSubmissionClassUserReports(string logonName, string submissionClassName, int siteId)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            LoadUmaUser(logonName);
            if (umaUser == null)
            {
                return new List<ReportInfo>();
            }

            var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(submissionClassName);

            bool isAdmin = IsSubmissionClassAdmin(submissionClassRoles);

            return submissionConfiguration.GetReportsByAccessRightNameList(
                submissionClassRoles
                .Where(r => (isAdmin && umaUser.IsInRole(r.RoleName)) || umaUser.IsInRole(r.RoleName, siteId))
                .SelectMany(r => r.SECURITY_RoleAccessRight.Select(rar => rar.SECURITY_AccessRight.AccessRightName))
                .Distinct()
                );
        }


        private IEnumerable<SECURITY_Role> GetAdminRoles(IEnumerable<SECURITY_Role> roles)
        {
            return roles.Where(r => r.RoleName.EndsWith(AdminRolePostfix)).ToList();
        }

        private IEnumerable<SECURITY_Role> GetNonAdminRoles(IEnumerable<SECURITY_Role> roles)
        {
            return roles.Where(r => !r.RoleName.EndsWith(AdminRolePostfix)).ToList();
        }

        private bool IsSubmissionClassAdmin(IEnumerable<SECURITY_Role> submissionClassRoles)
        {
            return GetAdminRoles(submissionClassRoles).Any(r => umaUser.IsInRole(r.RoleName));
        }

        private void LoadUmaUser(string logonName)
        {
            if (string.IsNullOrWhiteSpace(logonName))
            {
                throw new ArgumentNullException("logonName");
            }

            if (umaUser == null || !UmaApplicationUser.StripDomain(logonName).Equals(umaUser.LogonName, StringComparison.OrdinalIgnoreCase))
            {
                umaUser = UmaApplicationUser.GetUser(logonName);
            }
        }

        private System.Nullable<DateTime> GetEulaDate(int userId)
        {
            var eulaInfo = submissionConfiguration.GetSecurityUserByUserId(userId);
            if(eulaInfo == null)
            {
                return null;
            }
            else
            {
                return eulaInfo.EulaAcceptedDateTime;
            }

        }
                             
        public void SetEulaDate(ApplicationUser userInfo)
        {
            SECURITY_User su = submissionConfiguration.GetSecurityUserByUserId(userInfo.UserId);            
            su.EulaAcceptedDateTime = DateTime.Now;
            submissionConfiguration.UpdateSecurityUserEULA(su);
        }

        /// <summary>
        /// Permission to edit Submission schedule and override at least for one submission class (Rules: Admin = yes, Uploader = no)
        /// This is to show the edit button
        /// </summary>
        /// <param name="logonName"></param>
        /// <returns></returns>
        public bool HasEditSubmissionPeriodPermission(string logonName)
        {
            return (GetEditableSubmissionPeriods(logonName).Count() > 0);
        }


        /// <summary>
        /// Get User Submission Classes with editable periods (e.g. eClaims has none,  SSO has) based on the user access (basically it is ADMIN who can edit)
        /// </summary>
        /// <param name="logonName"></param>
        /// <returns></returns>
        public IEnumerable<SubmissionClassInfo> GetEditableSubmissionPeriods(string logonName)
        {
            List<SubmissionClassInfo> resultList = new List<SubmissionClassInfo>();

            // List of submission class where a user has permission + has reporting period (e.g. eClaims does not have, SSO has)
            IEnumerable<SubmissionClassInfo> userSubmissionClassList = GetUserSubmissionClasses(logonName).Where(a => a.ReportingPeriodType != null);

            foreach (var item in userSubmissionClassList)
            {
                var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(item.SubmissionClassName);
                if (IsSubmissionClassAdmin(submissionClassRoles))       // Check if Admin
                {
                    resultList.Add(item);
                }
            }

            return resultList;
        }

    }
}
