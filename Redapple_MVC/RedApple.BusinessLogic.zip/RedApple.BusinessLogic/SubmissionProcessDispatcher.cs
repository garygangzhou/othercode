﻿using RedApple.BusinessLogic.Infrastructure;
using RedApple.Common.Infrastructure;
using RedApple.DAL;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic
{
    /// <summary>
    /// This class serves as an additional abstraction layer between submission processing logic and its clients
    /// Each ISubmissionProcessor member is implemented as follows:
    ///     - User permissions are checked
    ///     - Appropriate processor is selected based on the metadata provided
    ///     - Processor's ISubmissionProcessor member is invoked to do real work
    /// </summary>
    public class SubmissionProcessDispatcher : ISubmissionProcessor, IDisposable
    {
        private bool disposed = false;

        private IUnityContainer childContainer;

        public SubmissionProcessDispatcher()
        {
            childContainer = DependencyInjectionHelper.Container.CreateChildContainer();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    childContainer.Dispose();
                    childContainer = null;
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        public virtual ICollection<SubmissionValidationError> ProcessPackage(UploadedFileProperties packageProperties, Stream uploadedFileStream,
            SubmissionMetadata metadata, SubmissionSecurityContext securityContext)
        {
            CheckUserPermissions(metadata, securityContext);

            ISubmissionProcessor processor = GetProcessor(metadata);
            return processor.ProcessPackage(packageProperties, uploadedFileStream, metadata, securityContext);
        }

        public virtual ICollection<SubmissionValidationError> ValidatePackageProperties(UploadedFileProperties packageProperties,
            SubmissionMetadata metadata, SubmissionSecurityContext securityContext)
        {
            CheckUserPermissions(metadata, securityContext);

            ISubmissionProcessor processor = GetProcessor(metadata);
            return processor.ValidatePackageProperties(packageProperties, metadata, securityContext);
        }


        protected virtual ISubmissionProcessor GetProcessor(SubmissionMetadata metadata)
        {
            ISubmissionProcessor result;
            if (childContainer.IsRegistered<ISubmissionProcessor>(metadata.SubmissionClassName))
            {
                result = childContainer.Resolve<ISubmissionProcessor>(metadata.SubmissionClassName);
            }
            else
            {
                result = childContainer.Resolve<ISubmissionProcessor>(DependencyInjectionConstants.DefaultProcessor);
            }

            return result;
        }

        /// <summary>
        /// Validates if the user has permissions to access upload functionality.
        /// Throws NoPermissionsException if the user doesn't have permissions.
        /// </summary>
        /// <param name="metadata"></param>
        /// <exception cref="NoPermissionsException"></exception>
        protected virtual void CheckUserPermissions(SubmissionMetadata metadata, SubmissionSecurityContext securityContext)
        {
            var securityProvider = childContainer.Resolve<ISecurityProvider>();

            if (!securityProvider.HasPermissions(securityContext.UserInfo.LogonName, 
                    metadata.SubmissionClassName, metadata.SubmissionSiteNumber, SecurityProvider.UploadAccessRightPostfix))
            {
                throw new NoPermissionsException();
            }
        }

        /// <summary>
        /// Process "No Data" submissions, user does not submits any file for this as there isn't any data to report
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="securityContext"></param>
        /// <returns>Collection of error messages</returns>
        public virtual ICollection<SubmissionValidationError> ProcessNoData(SubmissionMetadata metadata, SubmissionSecurityContext securityContext)
        {
            CheckUserPermissions(metadata, securityContext);

            ISubmissionProcessor processor = GetProcessor(metadata);
            return processor.ProcessNoData(metadata, securityContext);
        }
    }
}
