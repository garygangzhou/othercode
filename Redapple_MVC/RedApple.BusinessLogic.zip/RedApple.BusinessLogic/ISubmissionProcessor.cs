﻿using System;
using System.Collections.Generic;

namespace RedApple.BusinessLogic
{
    public interface ISubmissionProcessor
    {
        /// <summary>
        /// Validates, loads, and saves submission package if the validation passed.
        /// Basic and most common CCO procedure of uploading a data file package as a first step of data collection workflow
        /// includes the following steps:
        /// - (external) Upload metadata
        /// - (external) Upload package (zip or single data) file 
        /// - Register load with optional additional metadata in data receiving application. Get loadId for future reference
        /// - Validate package file properties
        /// - Save package file / Decompress zip file if needed
        /// - Validate extracted files: properties, headers/structure (possibly against metadata)
        /// - Log validation results: to receiving application, to local configuration db
        /// - (excluded from scope) Notify the user by e-mail
        /// 
        /// </summary>
        /// <param name="packageProperties"></param>
        /// <param name="uploadedFileStream"></param>
        /// <param name="metadata"></param>
        /// <returns>Collection of error messages</returns>
        ICollection<SubmissionValidationError> ProcessPackage(UploadedFileProperties packageProperties, System.IO.Stream uploadedFileStream, 
            SubmissionMetadata metadata, SubmissionSecurityContext securityContext);

        /// <summary>
        /// Validates submission package properties (file name, size, etc.)
        /// </summary>
        /// <param name="packageProperties"></param>
        /// <param name="metadata"></param>
        /// <returns>Collection of error messages</returns>
        ICollection<SubmissionValidationError> ValidatePackageProperties(UploadedFileProperties packageProperties,
            SubmissionMetadata metadata, SubmissionSecurityContext securityContext);
  
        /// <summary>
        /// Process "No Data" submissions, user does not submits any file for this as there isn't any data to report
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="securityContext"></param>
        /// <returns>Collection of error messages</returns>
        ICollection<SubmissionValidationError> ProcessNoData(SubmissionMetadata metadata, SubmissionSecurityContext securityContext);
    }
}
