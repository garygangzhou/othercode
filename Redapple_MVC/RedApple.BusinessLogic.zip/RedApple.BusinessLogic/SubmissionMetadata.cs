﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic
{
    public class SubmissionMetadata
    {
        public string SubmissionClassName { get; set; }
        public string SubmissionSiteNumber { get; set; }

        public DateTime SubmissionPeriodStart { get; set; }
        public DateTime SubmissionPeriodEnd { get; set; }

        // [S.L] This submissionMetaData is mainly for Oracle, there is no information about Reporting period, the original code used the DateUtil to calculate
        //       dynamically based on the SubmissionPeriodStart date. However, the new design supports different type (Fiscal Quarter, Monthly and Calendar Quarter) 
        //       and we do need to add the associated Reporting information
        public string SubmissionPeriodCode { get; set; }   // This is a short name that goes into "submission_Fisc_Qtr" column in Oracle db

        //This contain version number of submission class, all the existing submission classes.
        //if version == 1 then only file level validation will be done on front-end, rest of the validation will be performed at backend
        //if version == 2 then all validation will be performed at front-end
        //the value of this can be changed on database under dbo.SubmissionClass table
        public int Version { get; set; }

        public int SubmissionClassId { get; set; }

        public string ReportingPeriodName { get; set; }

        public string ReportingPeriodTypeName { get; set; }

        public int ReportingPeriodId { get; set; }

        // Id for the selected no case reason if applicable
        public decimal? NoCaseReasonId { get; set; }

        // Description for the selected no case reason if applicable
        public string NoCaseReasonDesc { get; set; }

    }
}
