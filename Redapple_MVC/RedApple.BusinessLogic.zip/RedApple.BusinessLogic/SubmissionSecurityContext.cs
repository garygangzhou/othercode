﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic
{
    public class SubmissionSecurityContext
    {
        public ApplicationUser UserInfo { get; set; }
        public string SessionId { get; set; }
        public string SourceAddress { get; set; }
    }
}
