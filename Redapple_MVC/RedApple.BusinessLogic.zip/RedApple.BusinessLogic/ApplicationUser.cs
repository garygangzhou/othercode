﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RedApple.BusinessLogic
{
    public class ApplicationUser
    {
        public long UserId { get; set; }
        public string LogonName { get; set; }
        public string DisplayName { get; set; }
        public string EMail { get; set; }
        public System.Nullable<DateTime> EULA { get; set; }        
    }
}