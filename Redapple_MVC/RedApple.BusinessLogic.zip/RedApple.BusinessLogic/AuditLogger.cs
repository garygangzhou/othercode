﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using RedApple.DAL;

namespace RedApple.BusinessLogic
{
    public enum AuditEventClass
    {
        UserLogin = 1,
        UserLogout,
        UserLoginFailed,
        UserNotAuthorized,
        UploadFile,
        EulaAcceptance,
        EulaDeclension,
        EulaPresentation
    }
       

    public static class AuditLogger
    {
        public static IEnumerable<AuditEvent> GetAuditEvents()
        {
            using (AuditLog auditLogContext = new AuditLog())
            {
                return auditLogContext.AuditEvents
                    .Include(ae => ae.AuditEventType)
                    .ToList();
            }
        }

        public static void WriteAuditEntry(Audit entry)
        {
            using (AuditLog auditLogContext = new AuditLog())
            {
                auditLogContext.Audits.Add(entry);
                auditLogContext.SaveChanges();
            }
        }

        public static void WriteSecurityAuditEntry(AuditEventClass auditEventClass, SubmissionSecurityContext securityContext)
        {
            var entry = new Audit
            {
                AuditDateTime = DateTime.Now,
                AuditEventID = (int)auditEventClass
            };

            FillEntrySecurityInfo(entry, securityContext);

            if (auditEventClass == AuditEventClass.UserLoginFailed)
            {
                entry.UserID = null;                
            }

            if ((auditEventClass == AuditEventClass.EulaAcceptance) || (auditEventClass == AuditEventClass.EulaDeclension)||(auditEventClass==AuditEventClass.EulaPresentation))
            {
                entry.CustomString3Value = System.Configuration.ConfigurationManager.AppSettings["EulaVersion"];
            }


            WriteAuditEntry(entry);
        }
        
        public static void WriteFileAuditEntry(AuditEventClass auditEventClass, SubmissionSecurityContext securityContext, 
            string siteNumber, string fileName, long loadId)
        {
            var entry = new Audit
            {
                AuditDateTime = DateTime.Now,
                AuditEventID = (int)auditEventClass,

                CustomString2Value = siteNumber,
                CustomString3Value = fileName,
                CustomNumber3Value = loadId
            };

            FillEntrySecurityInfo(entry, securityContext);

            WriteAuditEntry(entry);
        }

        private static void FillEntrySecurityInfo(Audit entry, SubmissionSecurityContext securityContext)
        {
            if (securityContext.UserInfo != null)
            {
                entry.UserID = securityContext.UserInfo.UserId;
                entry.UserName = securityContext.UserInfo.LogonName;
            }
            entry.SessionID = securityContext.SessionId;
            entry.SourceAddress = securityContext.SourceAddress;
        }
    }
}
