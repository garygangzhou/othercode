﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic
{
    public class UploadedFileProperties
    {
        public string Name;
        public long Size;
        public DateTime FileSubmissionTime;
    }
}
