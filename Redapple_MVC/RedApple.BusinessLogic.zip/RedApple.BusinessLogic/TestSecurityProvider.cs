﻿using CCO.UMA.UMAAPIClient;
using RedApple.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic
{
    public class TestSecurityProvider : ISecurityProvider
    {
        public const string AdminRolePostfix = "Admin";
        public const string UploaderRolePostfix = "Uploader";

        //private UmaApplicationUser umaUser;

        private ISubmissionConfiguration submissionConfiguration;

        public TestSecurityProvider(ISubmissionConfiguration submissionConfiguration)
        {
            this.submissionConfiguration = submissionConfiguration;
        }

        public ApplicationUser GetUserInfo(string logonName)
        {
            if (!string.IsNullOrWhiteSpace(logonName))
            {
                int i = logonName.LastIndexOf('\\');
                if (i != -1)
                {
                    logonName = logonName.Substring(i + 1);
                }
            }

            return new ApplicationUser 
            { 
                UserId = 12345,
                DisplayName = "DisplayName: " + logonName,
                LogonName = logonName,
                EMail = "test@test.com",
                EULA = GetEULA(1)
                
            };
        }

        public IEnumerable<SubmissionClassInfo> GetUserSubmissionClasses(string logonName)
        {
            var roleList = new List<string>();
            roleList.Add("eClaims_Uploader");
            roleList.Add("SSOISSTEMCELL_Uploader");
            roleList.Add("SSOISSARCHEMO_Uploader");
            roleList.Add("SSOISSARPATHO_Uploader");
            roleList.Add("SSOISSARPROS_Uploader");
            roleList.Add("SSOISLEUKEMIA_Uploader");
            roleList.Add("SSOISNEUROEND_Uploader");
            roleList.Add("RNFS_Uploader");
            roleList.Add("GI_ENDO_Uploader");
            return submissionConfiguration.GetSubmissionClassesByRoleNameList(roleList);
        }

        public IEnumerable<SECURITY_Site> GetSubmissionClassUserSites(string logonName, string submissionClassName)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(submissionClassName);
            var nonAdminRoles = GetNonAdminRoles(submissionClassRoles);
            // assume that all submissionClass sites are linked to submissionClass through non-admin roles (according to Lalin)
            var sites = submissionConfiguration.GetSitesByRoleList(nonAdminRoles);

            return sites;

            //if (IsSubmissionClassAdmin(submissionClassRoles))
            //{
            //    return sites;
            //}
            //else
            //{
            //    var q = from s in umaUser.GetSites()
            //            from scr in nonAdminRoles
            //            where umaUser.IsInRole(scr.RoleName, s)
            //            join ss in sites on s equals ss.SiteID
            //            select ss;

            //    return q.ToList();
            //}
        }

        public bool HasPermissions(string logonName, string submissionClassName, string submissionSiteNumber, string accessRight)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            if (string.IsNullOrWhiteSpace(submissionSiteNumber))
            {
                throw new ArgumentNullException("submissionSiteNumber");
            }

            if (string.IsNullOrWhiteSpace(accessRight))
            {
                throw new ArgumentNullException("accessRight");
            }

            return true;
            //bool hasPermissions = false;

            //LoadUmaUser(logonName);
            //if (umaUser != null)
            //{
            //    var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(submissionClassName);

            //    if (IsSubmissionClassAdmin(submissionClassRoles))
            //    {
            //        hasPermissions = true;
            //    }
            //    else
            //    {
            //        var siteInfo = submissionConfiguration.GetSiteByNumber(submissionSiteNumber);
            //        hasPermissions = submissionClassRoles.Any(r => umaUser.IsInRole(r.RoleName, siteInfo.SiteID));
            //    }
            //}

            //return hasPermissions;
        }


        public IEnumerable<ReportInfo> GetUserReports(string logonName)
        {
            //LoadUmaUser(logonName);
            //if (umaUser == null)
            //{
            //    return new List<Report>();
            //}

            return submissionConfiguration.GetReportsByAccessRightNameList(
                submissionConfiguration.GetSecurityRoles()
                //.Where(r => umaUser.IsInRole(r.RoleName))
                .SelectMany(r => r.SECURITY_RoleAccessRight.Select(rar => rar.SECURITY_AccessRight.AccessRightName))
                .Distinct()
                );
        }

        public IEnumerable<ReportInfo> GetSubmissionClassUserReports(string logonName, string submissionClassName)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            //LoadUmaUser(logonName);
            //if (umaUser == null)
            //{
            //    return new List<Report>();
            //}

            var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(submissionClassName);

            return submissionConfiguration.GetReportsByAccessRightNameList(
                submissionClassRoles
                //.Where(r => umaUser.IsInRole(r.RoleName))
                .SelectMany(r => r.SECURITY_RoleAccessRight.Select(rar => rar.SECURITY_AccessRight.AccessRightName))
                .Distinct()
                );
        }

        public IEnumerable<ReportInfo> GetSubmissionClassUserReports(string logonName, string submissionClassName, int siteId)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            //LoadUmaUser(logonName);
            //if (umaUser == null)
            //{
            //    return new List<Report>();
            //}

            var submissionClassRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(submissionClassName);

            bool isAdmin = IsSubmissionClassAdmin(submissionClassRoles);

            return submissionConfiguration.GetReportsByAccessRightNameList(
                submissionClassRoles
                //.Where(r => (isAdmin && umaUser.IsInRole(r.RoleName)) || umaUser.IsInRole(r.RoleName, siteId))
                .SelectMany(r => r.SECURITY_RoleAccessRight.Select(rar => rar.SECURITY_AccessRight.AccessRightName))
                .Distinct()
                );
        }

        private IEnumerable<SECURITY_Role> GetAdminRoles(IEnumerable<SECURITY_Role> roles)
        {
            return roles.Where(r => r.RoleName.EndsWith(AdminRolePostfix)).ToList();
        }

        private IEnumerable<SECURITY_Role> GetNonAdminRoles(IEnumerable<SECURITY_Role> roles)
        {
            return roles.Where(r => !r.RoleName.EndsWith(AdminRolePostfix)).ToList();
        }

        private bool IsSubmissionClassAdmin(IEnumerable<SECURITY_Role> submissionClassRoles)
        {
            return true;
            //return GetAdminRoles(submissionClassRoles).Any(r => umaUser.IsInRole(r.RoleName));
        }

        
        private System.Nullable<DateTime> GetEULA(int userId)
        {
            return submissionConfiguration.GetSecurityUserByUserId(userId).EulaAcceptedDateTime;
        }


        public void SetEulaDate(ApplicationUser userInfo)
        {
            SECURITY_User su = submissionConfiguration.GetSecurityUserByUserId(userInfo.UserId);
            su.EulaAcceptedDateTime = userInfo.EULA;
            submissionConfiguration.UpdateSecurityUserEULA(su);
        }

        public bool HasEditSubmissionPeriodPermission(string logonName)
        {
            return false;
        }

        public IEnumerable<SubmissionClassInfo> GetEditableSubmissionPeriods(string logonName)
        {
            return null;
        }

    }
}
