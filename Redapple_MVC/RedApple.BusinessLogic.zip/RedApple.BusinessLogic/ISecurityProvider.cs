﻿using RedApple.DAL;
using CCO.UMA.UMAAPIClient;
using System;
using System.Collections.Generic;
namespace RedApple.BusinessLogic
{
    public interface ISecurityProvider
    {
        ApplicationUser GetUserInfo(string logonName);
        IEnumerable<SECURITY_Site> GetSubmissionClassUserSites(string logonName, string submissionClassName);
        IEnumerable<SubmissionClassInfo> GetUserSubmissionClasses(string logonName);
        bool HasPermissions(string logonName, string submissionClassName, string submissionSiteNumber, string accessRight);
        IEnumerable<ReportInfo> GetUserReports(string logonName);
        IEnumerable<ReportInfo> GetSubmissionClassUserReports(string logonName, string submissionClassName);
        IEnumerable<ReportInfo> GetSubmissionClassUserReports(string logonName, string submissionClassName, int siteId);
        void SetEulaDate(ApplicationUser userInfo);

        bool HasEditSubmissionPeriodPermission(string logonName);
        IEnumerable<SubmissionClassInfo> GetEditableSubmissionPeriods(string logonName);
   }
}
