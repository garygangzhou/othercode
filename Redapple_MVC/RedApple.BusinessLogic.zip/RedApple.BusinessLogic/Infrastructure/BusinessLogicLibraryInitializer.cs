﻿using RedApple.BusinessLogic.SSOIS;
using RedApple.Common.Enums;
using RedApple.Common.Infrastructure;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic.Infrastructure
{
    public class BusinessLogicLibraryInitializer : IDependencyInjectionConfigurator
    {
        public void Configure(IUnityContainer container)
        {
            // disposable types must use HierarchicalLifetimeManager since this is the only way Unity would call dispose on the objects
            // types should by resolved using a child container which emulates a scope : 
            // it should be created at the beginning at disposed at the end thus disposing all objects it tracks 

            container.RegisterType<ISubmissionConfiguration, SubmissionConfiguration>(new HierarchicalLifetimeManager());
            container.RegisterType<ISecurityProvider, SecurityProvider>();
            //            container.RegisterType<ISecurityProvider, TestSecurityProvider>();

            container.RegisterType<ISubmissionProcessor, SubmissionProcessDispatcher>(new HierarchicalLifetimeManager());

            container.RegisterType<ISubmissionProcessor, SubmissionProcessor>(DependencyInjectionConstants.DefaultProcessor);
            // Not required after BRD change container.RegisterType<ISubmissionProcessor, SSOISSubmissionProcessor>(SubmissionClass.SSOIS.ToString());
        }
    }
}
