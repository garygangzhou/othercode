﻿using RedApple.BusinessLogic.SSOIS;
using RedApple.Common.Enums;
using RedApple.Common.Infrastructure;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic.Infrastructure
{
    public class DependencyInjectionConstants
    {
        public const string DefaultProcessor = "DefaultProcessor";
    }
}
