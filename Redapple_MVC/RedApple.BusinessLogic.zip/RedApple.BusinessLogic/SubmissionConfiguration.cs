﻿using RedApple.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Data.Entity;
using System.Data;
using LumenWorks.Framework.IO.Csv;

namespace RedApple.BusinessLogic
{
    public class SubmissionConfiguration : ISubmissionConfiguration, IDisposable
    {
        private IPortalConfiguration configDb;
        private ISubmissionLogRepository subLogDb;
        private bool disposed = false;

        private const string ApplicationNameKey = "applicationName";
        private const string UploadFolderKey = "dropFolderPath";
        private const string TemplatesFolderKey = "templatesFolderPath";
        private const string ShowNumberOfPeriodsKey = "showNumberOfPeriods";
        private const string IsAllowedOverrideDateTimeKey = "isAllowedOverrideDateTime";

        public string DataApplicationName { get { return ConfigurationManager.AppSettings[ApplicationNameKey]; } }
        public string UploadFolder { get { return ConfigurationManager.AppSettings[UploadFolderKey]; } }
        public string TemplatesFolder { get { return ConfigurationManager.AppSettings[TemplatesFolderKey]; } }

        public bool IsAllowedOverrideDateTime
        {
            // Return default as false if configure is not being setup
            get
            {
                return (ConfigurationManager.AppSettings[IsAllowedOverrideDateTimeKey] == null) ? false : Convert.ToBoolean(ConfigurationManager.AppSettings[IsAllowedOverrideDateTimeKey]);
            }
        }
        
        public SubmissionConfiguration()
        {
            configDb = new PortalConfiguration();
            subLogDb = new SubmissionLogRepository();
        }

        public SubmissionConfiguration(IPortalConfiguration config_db)
        {
            configDb = config_db;
        }

        public SubmissionConfiguration(IPortalConfiguration config_db, ISubmissionLogRepository subLog_db)
        {
            configDb = config_db;
            subLogDb = subLog_db;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    configDb.Dispose();
                    configDb = null;
                    subLogDb.Dispose();
                    subLogDb = null;
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        public SubmissionClassInfo GetSubmissionClassInfo(string submissionClassName)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            return configDb
                .SubmissionClasses
                .Include(sc => sc.Recordsets.Select(rs => rs.RecordsetColumns))
                .SingleOrDefault(sc => submissionClassName.Equals(sc.SubmissionClassName, StringComparison.OrdinalIgnoreCase));
        }

        public IEnumerable<SubmissionClassInfo> GetSubmissionClasses()
        {
            return configDb.SubmissionClasses.ToList();
        }

        public IEnumerable<SubmissionClassInfo> GetSubmissionClassesByRoleNameList(IEnumerable<string> roleNames)
        {
            if (roleNames == null)
            {
                throw new ArgumentNullException("roleNames");
            }

            var scrQuery = from rn in roleNames
                           join r in configDb.SECURITY_Role on rn equals r.RoleName
                           join scr in configDb.SubmissionClassRoles on r.RoleID equals scr.RoleId
                           select scr.SubmissionClassId;

            var q = configDb.SubmissionClasses.Where(sc => scrQuery.Any(scId => sc.SubmissionClassId == scId));

            return q.ToList();
        }

        public IEnumerable<SECURITY_Role> GetSubmissionClassSecurityRoles(string submissionClassName)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            var q = from r in configDb.SECURITY_Role
                        .Include(r => r.SECURITY_RoleAccessRight.Select(rar => rar.SECURITY_AccessRight))
                    join scr in configDb.SubmissionClassRoles on r.RoleID equals scr.RoleId
                    join sc in configDb.SubmissionClasses on scr.SubmissionClassId equals sc.SubmissionClassId
                    where submissionClassName.Equals(sc.SubmissionClassName, StringComparison.OrdinalIgnoreCase)
                    select r;

            return q.ToList();
        }

        public IEnumerable<SECURITY_Role> GetSecurityRoles()
        {
            var q = from r in configDb.SECURITY_Role
                        .Include(r => r.SECURITY_RoleAccessRight.Select(rar => rar.SECURITY_AccessRight))
                    select r;

            return q.ToList();
        }

        public IEnumerable<SECURITY_Site> GetSites()
        {
            return configDb
                .SECURITY_Site
                .Include(ss => ss.SECURITY_FacilitySite.Select(sfs => sfs.SECURITY_Facility))
                .Where(ss => ss.ExpiredDate == null || ss.ExpiredDate > DateTime.Now)
                .ToList();
        }

        public IEnumerable<SECURITY_Site> GetSitesByRoleList(IEnumerable<SECURITY_Role> roles)
        {
            if (roles == null)
            {
                throw new ArgumentNullException("roles");
            }

            // assume that all submissionClass sites are linked to submissionClass through non-admin roles (according to Lalin)
            var siteRolesQuery = from r in roles
                                 join ssr in configDb.SECURITY_SiteRole on r.RoleID equals ssr.RoleID
                                 select ssr.SiteID;

            var q = GetSites().Where(ss => siteRolesQuery.Any(ssrId => ss.SiteID == ssrId));

            return q.ToList();
        }

        public SECURITY_Site GetSiteByNumber(string siteNumber)
        {
            if (string.IsNullOrWhiteSpace(siteNumber))
            {
                throw new ArgumentNullException("siteNumber");
            }

            return configDb
                .SECURITY_Site
                .SingleOrDefault(sc => siteNumber.Equals(sc.MasterNumber, StringComparison.OrdinalIgnoreCase));
        }

        public SECURITY_Facility GetSiteFacility(SECURITY_Site site)
        {
            // according to business rules a site must belong to exactly one facility at a given time (Vladan)
            // some sites may not be assosiated with facilities, but these sites should not be used with this application 
            var linkQuery = site
                .SECURITY_FacilitySite
                .Where(sfs => sfs.EffectiveStartDate <= DateTime.Now && (sfs.EffectiveEndDate == null || sfs.EffectiveEndDate >= DateTime.Now));
            var link = linkQuery.FirstOrDefault();

            SECURITY_Facility facility;
            if (link == null || link.SECURITY_Facility.ExpiredDate <= DateTime.Now)
            {
                facility = new SECURITY_Facility
                {
                    FacilityID = -1,
                    FacilityName = "N/A",
                    FacilityNumber = "*N*"
                };
            }
            else
            {
                facility = link.SECURITY_Facility;
            }

            return facility;
        }

        public IEnumerable<ReportInfo> GetReportsByAccessRightNameList(IEnumerable<string> accessRightNames)
        {
            if (accessRightNames == null)
            {
                throw new ArgumentNullException("accessRightNames");
            }

            var q = configDb
                .Reports
                .Where(rp =>
                    rp.ReportAccessRights.Any(rar =>
                        accessRightNames.Any(arn =>
                            rar.SECURITY_AccessRight.AccessRightName.Equals(arn, StringComparison.OrdinalIgnoreCase))));

            return q.ToList();
        }

        public ReportInfo GetReportById(int reportId)
        {
            return configDb
                .Reports
                .Include(rp => rp.ReportingService)
                .Include(rp => rp.ReportParameters)
                .SingleOrDefault(rp => rp.ReportID == reportId);
        }


        public SECURITY_User GetSecurityUserByUserId(long userId)
        {
            return configDb.SECURITY_User.Find(userId);
        }

        public void UpdateSecurityUserEULA(SECURITY_User securityUser)
        {
            configDb.Entry(securityUser).State = EntityState.Modified;
            configDb.SaveChanges();
        }


        /// <summary>
        /// Helper method:  Get the submission period by taking the submissionClassName (string) and submissionSiteNumber (string)
        /// </summary>
        /// <param name="dateTime"></param>
        /// <param name="submissionClassName"></param>
        /// <param name="submissionSiteNumber"></param>
        /// <param name="numberOfPreviousPeriodShown"></param>
        /// <returns></returns>
        public IEnumerable<SubmissionPeriod> GetSubmissionPeriodList(DateTime dateTime, string submissionClassName, string submissionSiteNumber, int numberOfPreviousPeriodShown)
        {

            SubmissionClassInfo classInfo = GetSubmissionClassInfo(submissionClassName);
            SECURITY_Site siteInfo = GetSiteByNumber(submissionSiteNumber);

            return GetSubmissionPeriodList(dateTime, classInfo.SubmissionClassId, siteInfo.SiteID, numberOfPreviousPeriodShown);
        }


        /// <summary>
        /// Call the SP to get the Submission Period, parameters matches the stored procedure signature all passing IDs
        /// </summary>
        /// <param name="dateTime"></param>
        /// <param name="submissionClassID"></param>
        /// <param name="submissionSiteID"></param>
        /// <param name="numberOfPreviousPeriodShown"></param>
        /// <returns></returns>
        public IEnumerable<SubmissionPeriod> GetSubmissionPeriodList(DateTime dateTime, int submissionClassID, int submissionSiteID, int numberOfPreviousPeriodShown)
        {
            List<SubmissionPeriod> result = new List<SubmissionPeriod>();

            // Call the stored procedure to get the submission schedule 
            // Note 1: The submission schedule returned (usp_GetSubmissionPeriod_Result) is for one particular site + one particular Class ID, so this can be used for both dropdown and validation
            // Note 2: The idea of using Stored Procedure is coded based on Lalin Perera's architecture, please refer to the design document for details

            var tempResult = configDb.usp_GetSubmissionPeriod(dateTime, submissionClassID, submissionSiteID, numberOfPreviousPeriodShown);

            // Convert the result as a generic list 
            if (tempResult != null)
                result = tempResult.ToList<SubmissionPeriod>();

            return result;
        }



        /// <summary>
        /// Check if the selected class is enabled 
        /// </summary>
        /// <returns></returns>
        public bool IsSubmissionScheduleEnabled(string submissionClassName)
        {
            bool result = false;

            SubmissionClassInfo info = GetSubmissionClassInfo(submissionClassName);

            // Get the Reporting Period Start/End Date 
            if ((info.ReportingPeriodType != null) && (info.UseSubmissionSchedule == true))
                result = true;

            return result;
        }


        /// <summary>
        /// Check if the selected class is reported by submission period (e.g. eClaims is not, but SSO is)
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <returns></returns>
        public bool IsSubmissionScheduleDefined(string submissionClassName)
        {
            bool result = false;

            SubmissionClassInfo info = GetSubmissionClassInfo(submissionClassName);

            // Get the Reporting Period Start/End Date
            if (info.ReportingPeriodType != null)
                result = true;

            return result;
        }


        /// <summary>
        /// Get Report Period List
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <returns></returns>
        public IEnumerable<ReportingPeriod> GetReportPeriodList(string submissionClassName)
        {
            SubmissionClassInfo info = GetSubmissionClassInfo(submissionClassName);


            var result = from a in configDb.ReportingPeriod
                         join b in configDb.SubmissionSchedule on a.ReportingPeriodId equals b.ReportingPeriodId
                         where b.SubmissionClassId == info.SubmissionClassId
                         select a;

            return result.ToList();
        }


        /// <summary>
        /// Update the changes on EF 
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <param name="isEnabled"></param>
        public bool UpdateUseSubmissionSchedule(string submissionClassName, bool isEnabled)
        {
            SubmissionClassInfo info = GetSubmissionClassInfo(submissionClassName);
            info.UseSubmissionSchedule = isEnabled;

            // Save to EF 
            int rowsUpdated = configDb.SaveChanges();

            return (rowsUpdated >= 1);

        }

        /// <summary>
        /// Get Submission Schedule from SubmissionSchedule entity/table
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <param name="reportingPeriodID"></param>
        /// <returns></returns>
        public SubmissionSchedule GetSubmissionSchedule(string submissionClassName, int reportingPeriodID)
        {
            SubmissionClassInfo info = GetSubmissionClassInfo(submissionClassName);

            var result = from a in configDb.SubmissionSchedule
                         where (a.SubmissionClassId == info.SubmissionClassId) && (a.ReportingPeriodId == reportingPeriodID)
                         select a;

            SubmissionSchedule submissionSchedule = result.FirstOrDefault();

            return submissionSchedule;
        }


        /// <summary>
        /// Update Submission Schedule based on the given new dates
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <param name="reportingPeriodID"></param>
        /// <param name="newStartDate"></param>
        /// <param name="newEndDate"></param>
        /// <returns></returns>
        public bool UpdateSubmissionSchedule(string submissionClassName, int reportingPeriodID, DateTime newStartDate, DateTime newEndDate)
        {
            SubmissionSchedule submissionSchedule = GetSubmissionSchedule(submissionClassName, reportingPeriodID);

            if (submissionSchedule != null)
            {
                submissionSchedule.SubmissionPeriodStartDate = newStartDate;
                submissionSchedule.SubmissionPeriodEndDate = newEndDate;
            }

            // Save to EF 
            int rowsUpdated = configDb.SaveChanges();

            // it shows you at least one row has been updated, if no changes. It will return 0 (still valid)
            return (rowsUpdated >= 1);


        }


        /// <summary>
        /// Get the submissionScheduleOverride 
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <param name="reportingPeriodID"></param>
        /// <param name="siteIDList"></param>
        /// <returns></returns>
        public IEnumerable<SubmissionScheduleOverride> GetSubmissionScheduleOverrideList(string submissionClassName, int reportingPeriodID, IEnumerable<int> siteIDList)
        {
            SubmissionClassInfo info = GetSubmissionClassInfo(submissionClassName);

            IEnumerable<SubmissionScheduleOverride> result = from a in configDb.SubmissionScheduleOverride
                                                             where a.SubmissionClassId == info.SubmissionClassId &&
                                                                  a.ReportingPeriodId == reportingPeriodID &&
                                                                  siteIDList.Contains(a.SiteID)
                                                             select a;

            return result.ToList();
        }

        /// <summary>
        /// Insert or Update the override schedule
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <param name="reportingPeriodID"></param>
        /// <param name="siteID"></param>
        /// <param name="effectiveDateTime"></param>
        /// <param name="numberOfDaysEffective"></param>
        /// <returns></returns>
        public bool UpsertOverrideSchedules(string submissionClassName, int reportingPeriodID, IEnumerable<int> siteIDList, DateTime effectiveDateTime, int numberOfDaysEffective)
        {
            IEnumerable<SubmissionScheduleOverride> submissionScheduleOverrideList = GetSubmissionScheduleOverrideList(submissionClassName, reportingPeriodID, siteIDList);

            // Update existing override schedule
            foreach (SubmissionScheduleOverride item in submissionScheduleOverrideList)
            {
                if (item != null)
                {
                    // Update
                    item.EffectiveDate = effectiveDateTime;
                    item.NumberDaysEffective = numberOfDaysEffective;
                }
            }

            // Insert new rows by getting the list where they are not currently in db 
            IEnumerable<int> insertSiteIDList = siteIDList.Except(submissionScheduleOverrideList.Select(a => a.SiteID));

            foreach (int item in insertSiteIDList)
            {
                // Insert
                SubmissionClassInfo info = GetSubmissionClassInfo(submissionClassName);

                SubmissionScheduleOverride submissionScheduleOverride = new SubmissionScheduleOverride();
                submissionScheduleOverride.SubmissionClassId = info.SubmissionClassId;
                submissionScheduleOverride.ReportingPeriodId = reportingPeriodID;
                submissionScheduleOverride.SiteID = item;       // item is ID
                submissionScheduleOverride.EffectiveDate = effectiveDateTime;
                submissionScheduleOverride.NumberDaysEffective = numberOfDaysEffective;

                configDb.SubmissionScheduleOverride.Add(submissionScheduleOverride);
            }


            // Save to EF 
            int rowsUpdated = configDb.SaveChanges();

            // it shows you at least one row has been updated, if no changes. It will return 0 (still valid)
            return (rowsUpdated >= 1);

        }


        /// <summary>
        /// Delete override schedule from db
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <param name="reportingPeriodID"></param>
        /// <param name="siteID"></param>
        /// <returns></returns>
        public bool DeleteOverrideSchedules(string submissionClassName, int reportingPeriodID, IEnumerable<int> siteIDList)
        {
            IEnumerable<SubmissionScheduleOverride> submissionScheduleOverrideList = GetSubmissionScheduleOverrideList(submissionClassName, reportingPeriodID, siteIDList);

            foreach (var item in submissionScheduleOverrideList)
            {
                configDb.SubmissionScheduleOverride.Remove(item);
            }

            // Save to EF 
            int rowsUpdated = configDb.SaveChanges();

            // it shows you at least one row has been updated, if no changes. It will return 0 (still valid)
            return (rowsUpdated >= 1);


        }

        /// <summary>
        /// load validation rules from database into a datahash
        /// </summary>
        /// <param name="recordSetId">rule set id to get validation rules</param>
        /// <param name="hash">a datahas class which will be poppulated with validation rules, this datahash will be feed to validators to validate</param>
        //public void GetSubmissionValidationRule(int recordSetId, DataHash hash)
        //{            
        //    hash.Rules.AddRange(GetSubmissionValidationRule(recordSetId));
        //}

        public List<Validation.ValidationRule> GetSubmissionValidationRule(int recordSetId)
        {
            List<Validation.ValidationRule> validationRule = (from vr in configDb.ValidationRule
                                                                  join rc in configDb.RecordsetColumns on vr.RecordsetColumnId equals rc.RecordsetColumnId
                                                                  into columnList
                                                                  from column in columnList.DefaultIfEmpty()
                                                                  join vrs in configDb.ValidationRuleSet on vr.ValidationRuleId equals vrs.ValidationRuleId
                                                                  where vr.RecordsetId == recordSetId && vrs.IsDisabled == false
                                                                  select new Validation.ValidationRule
                                                                  {
                                                                      Id = vr.ValidationRuleId,
                                                                      Expression = vr.ValidationExpression,
                                                                      ValidatorType = vr.ValidatorType,
                                                                      ErrorMessage = vr.ErrorMessageTemplate,
                                                                      IsNegated = vr.IsNegated,
                                                                      FieldName = column.RecordsetColumnName,
                                                                      RejectionActionFlag = vr.RejectionActionFlag,
                                                                      RuleCode = vr.ValidationRuleCode,
                                                                      FileLevelValidation = vr.FileLevelValidation,
                                                                      IsWarning = vr.IsWarning,
                                                                      FileLevelValidatorId = vr.DuplicateEntryValidatorId
                                                                  }).ToList();

            foreach (var duplicateValidator in validationRule.Where(x => x.ValidatorType == "DuplicateEntryValidator"))
            {
                duplicateValidator.FileLevelValidationColumns = (from duplicateColumn in configDb.DuplicateEntryValidatorColumn
                                                                 where duplicateColumn.DuplicateEntryValidatorId == duplicateValidator.FileLevelValidatorId
                                                                 join recordsetColumn in configDb.RecordsetColumns on duplicateColumn.RecordsetColumnId equals recordsetColumn.RecordsetColumnId
                                                                 select recordsetColumn.RecordsetColumnName).ToList();
            }
            return validationRule;
        }

        /// <summary>
        /// load records/data from csv file into datahash
        /// </summary>
        /// <param name="filePath">a path for csv file that is uploaded by the user and which contains data</param>
        /// <param name="hash">a datahas class which will be poppulated with data, this datahash will be feed to validators to validate</param>
        /// <returns></returns>
        //public void GetDataFromCsvFile(string filePath, DataHash hash, string submissionClassName)
        //{
        //        //read all other files

        //        // By default CSV reader is trimming all leading and trailing whitespaces of the value.
        //        // To overwrite CSVReader's default behaviour of trimming leading and trainling, CSVReader needs to be constructed with "ValueTrimmingOptions.None" property
        //        // which tells it not to TRIM the value. Below is detail information about CSVReader constructor parameters
        //        //https://www.nuget.org/packages/LumenWorksCsvReader/

        //        #region CSVReader 
        //        // Constructor: CsvReader(TextReader reader, bool hasHeaders, char delimiter, char quote, char escape, char comment, ValueTrimmingOptions trimmingOptions)
        //        /// <param name="reader">pointing to the CSV file.</param>
        //        /// <param name="hasHeaders">true if field names are located on the first non commented line, otherwise false.</param>
        //        /// <param name="delimiter">The delimiter character separating each field (default is ',').</param>
        //        /// <param name="quote">The quotation character wrapping every field (default is '"').</param>
        //        /// <param name="escape">
        //        /// The escape character letting insert quotation characters inside a quoted field (default is '"').
        //        /// </param>
        //        /// <param name="comment">The comment character indicating that a line is commented out (default is '#')
        //        /// ,each line will be treated as a row of data.</param>
        //        /// <param name="trimmingOptions">Determines which values should be trimmed. 'ValueTrimmingOptions.None' indicates not to trim anything</param>
        //        #endregion CSVReader 
        //    char quote = '"';
        //    char escape = '"';
        //    if (!string.IsNullOrEmpty(submissionClassName) && submissionClassName == "GI_ENDO")
        //    {
        //        //GI ENDO ignore escape
        //        quote = '\0';
        //        escape = '\0';
        //    }

        //    using (CsvReader csv = new CsvReader(
        //        new System.IO.StreamReader(filePath), true, ',', quote, escape, '\0', ValueTrimmingOptions.None))
        //    {
        //        // missing fields will not throw an exception,
        //        // but will instead be treated as if there was a null value
        //        csv.MissingFieldAction = MissingFieldAction.ReplaceByNull;
        //        int fieldCount = csv.FieldCount;
        //        string[] headers = csv.GetFieldHeaders();
        //        foreach (string str in headers)
        //        {
        //            hash.Recordset.Columns.Add(str);
        //        }
        //        string[] data = new string[fieldCount];
        //        while (csv.ReadNextRecord())
        //        {
        //            csv.CopyCurrentRecordTo(data);
        //            hash.Recordset.Rows.Add(data);
        //        }
        //    }
        //}

        public DataTable GetDataFromCsvFile(string filePath, string submissionClassName)
        {
            #region CSVReader 
            // Constructor: CsvReader(TextReader reader, bool hasHeaders, char delimiter, char quote, char escape, char comment, ValueTrimmingOptions trimmingOptions)
            /// <param name="reader">pointing to the CSV file.</param>
            /// <param name="hasHeaders">true if field names are located on the first non commented line, otherwise false.</param>
            /// <param name="delimiter">The delimiter character separating each field (default is ',').</param>
            /// <param name="quote">The quotation character wrapping every field (default is '"').</param>
            /// <param name="escape">
            /// The escape character letting insert quotation characters inside a quoted field (default is '"').
            /// </param>
            /// <param name="comment">The comment character indicating that a line is commented out (default is '#')
            /// ,each line will be treated as a row of data.</param>
            /// <param name="trimmingOptions">Determines which values should be trimmed. 'ValueTrimmingOptions.None' indicates not to trim anything</param>
            #endregion CSVReader 

            char quote = '"';
            char escape = '"';
            if (!string.IsNullOrEmpty(submissionClassName) && submissionClassName == "GI_ENDO")
            {
                //GI ENDO ignore escape
                quote = '\0';
                escape = '\0';
            }

            DataTable dt = new DataTable();
            using (CsvReader csv = new CsvReader(
                new System.IO.StreamReader(filePath), true, ',', quote, escape, '\0', ValueTrimmingOptions.None))
            {
                // missing fields will not throw an exception,
                // but will instead be treated as if there was a null value
                csv.MissingFieldAction = MissingFieldAction.ReplaceByNull;
                int fieldCount = csv.FieldCount;
                string[] headers = csv.GetFieldHeaders();
                foreach (string str in headers)
                {
                    dt.Columns.Add(str);
                }
                string[] data = new string[fieldCount];
                while (csv.ReadNextRecord())
                {
                    csv.CopyCurrentRecordTo(data);
                    dt.Rows.Add(data);
                }
            }
            return dt;
        }

        //ShowNumberOfPeriod was defined in web.config, now since this value needed per submission class (i.e. for RNFS, submission period dropdown list should
        //display 3 records, where as others should display 5 records), it is moved to database (Table: SubmissionClass, Column: ShowNumberOfPeriod)
        public int GetSubmissionShowNumberOfPeriod(string submissionClassName)
        {
            if (string.IsNullOrWhiteSpace(submissionClassName))
            {
                throw new ArgumentNullException("submissionClassName");
            }

            var result = (configDb.SubmissionClasses.FirstOrDefault(sClass => sClass.SubmissionClassName == submissionClassName) == null) ? 0 : configDb.SubmissionClasses.FirstOrDefault(sClass => sClass.SubmissionClassName == submissionClassName)
                .ShowNumberOfPeriods;
            return result;

        }

        /// <summary>
        /// Check if there is file submitted successfully for parameters selected by user
        /// </summary>
        /// <param name="submissionClassName"></param>
        /// <param name="siteNumber"></param>
        /// <param name="reportingPeriodId"></param>
        /// <returns></returns>
        public bool HasPeviousLoadBySiteNumberReportingPeriodId(string submissionClassName, string submissionSiteNumber, int reportingPeriodId)
        {
            bool retVal = false;
            retVal = subLogDb.GetSubmissionEventsBySiteNumberReportingId(submissionClassName, submissionSiteNumber, reportingPeriodId).Where(se => se.Status == "REC").Any() ? true : false;
            return retVal;
        }

        /// <summary>
        /// Validate package file name against valid package name
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="packageName"></param>
        /// <returns></returns>
        public bool ValidatePackageFileName(SubmissionMetadata metadata, string packageName)
        {
            bool retVal = true;
            var rules = (from pvr in configDb.PackageNameValidationRule
                         where pvr.SubmissionClassId == metadata.SubmissionClassId
                         select pvr
                         ).ToList();
            foreach (var rule in rules)
            {
                retVal = string.Equals(packageName, GeneratePackageNameFromExpression(metadata, rule.ValidationExpression), StringComparison.InvariantCultureIgnoreCase);
            }

            return retVal;
        }

        public List<NoCaseSubmissionReasons> GetNoCaseSubmissionReasonBySubmissionClass(string submissionClass)
        {
            List<NoCaseSubmissionReasons> reasons = null;
            reasons = configDb.NoCaseSubmissionReasons.Where(x => x.SubmissionClass.SubmissionClassName == submissionClass).ToList();
            return reasons;
        }

        /// <summary>
        /// convert expression to valid filename
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="expression"></param>
        /// <returns></returns>
        protected string GeneratePackageNameFromExpression(SubmissionMetadata metadata, string expression)
        {
            string validFileName = expression;
            if (expression.Contains("MASTERNUMBER")) validFileName = validFileName.Replace("<<MASTERNUMBER>>", metadata.SubmissionSiteNumber);
            if (expression.Contains("REPORTINGPERIODCODE")) validFileName = validFileName.Replace("<<REPORTINGPERIODCODE>>", metadata.SubmissionPeriodCode);
            return validFileName;
        }


    }
}
