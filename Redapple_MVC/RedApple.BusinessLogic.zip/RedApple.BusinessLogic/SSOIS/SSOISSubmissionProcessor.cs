﻿using RedApple.DAL;
using RedApple.DAL.SSOIS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic.SSOIS
{
    internal class SSOISSubmissionProcessor : SubmissionProcessor
    {
        protected ISSOISEDWSubmissionConfigurationRepository ssoisEDWSubmissionConfigurationRepository;

        public SSOISSubmissionProcessor(ISubmissionConfiguration submissionConfiguration, ISecurityProvider securityProvider,
            IEDWSubmissionLogRepository edwSubmissionLogRepository, ISubmissionLogRepository submissionLogRepository,
            ISSOISEDWSubmissionConfigurationRepository ssoisEDWSubmissionConfigurationRepository) :
            base (submissionConfiguration, securityProvider, edwSubmissionLogRepository, submissionLogRepository)
        {
            this.ssoisEDWSubmissionConfigurationRepository = ssoisEDWSubmissionConfigurationRepository;
        }

        protected override SubmissionClassInfo GetSubmissionClassInfo(SubmissionMetadata metadata)
        {
            var submissionClassInfo = submissionConfiguration.GetSubmissionClassInfo(metadata.SubmissionClassName);
            string facilityNumber = submissionConfiguration.GetSiteFacility(submissionConfiguration.GetSiteByNumber(metadata.SubmissionSiteNumber)).FacilityNumber;
            var facilityPrograms = ssoisEDWSubmissionConfigurationRepository.GetAllSSOPrograms()
                .Where(p => 
                    p.LNK_SSO_PRG_TO_FACILITY.Any(lnk =>
                        facilityNumber.Equals(lnk.DIM_SSO_FACILITY.SUBMISSION_FACILITY_NUM, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            return new SubmissionClassInfo
            {
                Description = submissionClassInfo.Description,
                PackageFilenameRegEx = submissionClassInfo.PackageFilenameRegEx,
                Recordsets = submissionClassInfo.Recordsets
                    .Where(rs => 
                        facilityPrograms.Any(fp => 
                            rs.RecordsetName.Equals(fp.SSO_PROGRAM_CD, StringComparison.OrdinalIgnoreCase)))
                    .ToList(),
                SubmissionClassId = submissionClassInfo.SubmissionClassId,
                SubmissionClassName = submissionClassInfo.SubmissionClassName
            };
        }

    }
}
