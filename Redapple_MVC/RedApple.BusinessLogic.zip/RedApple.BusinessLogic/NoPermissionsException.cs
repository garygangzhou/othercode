﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace RedApple.BusinessLogic
{
    [Serializable]
    public class NoPermissionsException : Exception
    {
        // Summary:
        //     Initializes a new instance of the NoPermissionsException class.
        public NoPermissionsException()
            : base()
        { }
        //
        // Summary:
        //     Initializes a new instance of the NoPermissionsException class
        //     with a specified error message.
        //
        // Parameters:
        //   message:
        //     The message that describes the error.
        public NoPermissionsException(string message)
            : base(message)
        { }
        //
        // Summary:
        //     Initializes a new instance of the NoPermissionsException class
        //     with serialized data.
        //
        // Parameters:
        //   info:
        //     The System.Runtime.Serialization.SerializationInfo that holds the serialized
        //     object data about the exception being thrown.
        //
        //   context:
        //     The System.Runtime.Serialization.StreamingContext that contains contextual
        //     information about the source or destination.
        protected NoPermissionsException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        { }
        //
        // Summary:
        //     Initializes a new instance of the NoPermissionsException class
        //     with a specified error message and a reference to the inner exception that
        //     is the cause of this exception.
        //
        // Parameters:
        //   message:
        //     The error message that explains the reason for the exception.
        //
        //   inner:
        //     The exception that is the cause of the current exception. If the inner parameter
        //     is not a null reference (Nothing in Visual Basic), the current exception
        //     is raised in a catch block that handles the inner exception.
        public NoPermissionsException(string message, Exception inner)
            : base(message, inner) 
        { }
    }
}
