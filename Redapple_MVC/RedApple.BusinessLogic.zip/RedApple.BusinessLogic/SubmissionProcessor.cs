﻿using RedApple.DAL;
using RedApple.Common.Enums;
using RedApple.Common.Utility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using RedApple.Validation;

namespace RedApple.BusinessLogic
{
    /// <summary>
    /// Implements basic and most common CCO procedure of uploading a data file package as a first step of data collection workflow
    /// Steps:
    /// - (external) Upload metadata
    /// - (external) Upload package (zip or single data) file 
    /// - Register load with optional additional metadata in data receiving application. Get loadId for future reference
    /// - Validate package file properties
    /// - Save package file / Decompress zip file if needed
    /// - Validate extracted files: properties, headers/structure (possibly against metadata)
    /// - Log validation results: to receiving application, to local configuration db
    /// 
    /// </summary>
    public class SubmissionProcessor : ISubmissionProcessor
    {
        protected ISubmissionConfiguration submissionConfiguration;
        protected ISecurityProvider securityProvider;

        protected IEDWSubmissionLogRepository edwSubmissionLogRepository;
        protected ISubmissionLogRepository submissionLogRepository;

        public SubmissionProcessor(ISubmissionConfiguration submissionConfiguration, ISecurityProvider securityProvider,
            IEDWSubmissionLogRepository edwSubmissionLogRepository, ISubmissionLogRepository submissionLogRepository)
        {
            this.submissionConfiguration = submissionConfiguration;
            this.securityProvider = securityProvider;

            this.edwSubmissionLogRepository = edwSubmissionLogRepository;
            this.submissionLogRepository = submissionLogRepository;
        }

        /// <summary>
        /// Validates, loads, and saves submission package if the validation passed.
        /// </summary>
        /// <param name="packageProperties"></param>
        /// <param name="uploadedFileStream"></param>
        /// <param name="metadata"></param>
        /// <returns>Collection of error messages</returns>
        public virtual ICollection<SubmissionValidationError> ProcessPackage(UploadedFileProperties packageProperties,
            Stream uploadedFileStream, SubmissionMetadata metadata, SubmissionSecurityContext securityContext)
        {
            List<SubmissionValidationError> validationErrors = new List<SubmissionValidationError>();

            long loadId = 0;
            //this indicates the status of submission in version 2 (RNFS etc.) in SQL server (Table: "SubmissionEvent", Column: RejectionFlag )
            //this will be set after data validation which is the last validation step of the submission process
            //this flag has been initialized with string.empty, as for version 1 (eClaims, SSO), this will remail empty as data is not being validated for Version 1
            string submissionRejectionFlag = string.Empty;
            try
            {
                loadId = RegisterLoad(packageProperties.Name, metadata, securityContext, SubmissionStatus.PRE);

                validationErrors.AddRange(ValidatePackageProperties(packageProperties, metadata, securityContext));
                if (!validationErrors.Any())
                {
                    // - Save package file / Decompress zip file if needed
                    validationErrors.AddRange(SavePackage(packageProperties, uploadedFileStream, loadId));

                    if (!validationErrors.Any())
                    {
                        // - Validate extracted files: properties, headers/structure
                        validationErrors.AddRange(ValidatePackageContent(packageProperties, metadata, loadId));
                    }
                }

                SubmissionClassVersion version = (SubmissionClassVersion)Enum.Parse(typeof(SubmissionClassVersion), "VersionWithDataValidation");

                if ((!validationErrors.Any()) && metadata.Version == Convert.ToInt16(version))
                {
                    validationErrors.AddRange(ValidateRecordsetData(packageProperties, securityContext, metadata, loadId, out submissionRejectionFlag));
                    if (validationErrors.Any(vr => vr.Code == SubmissionValidationError.Error100_System.Code))
                        throw new Exception("System error occured during file data validaton");
                }

                // - Log validation results: to receiving application
                var status = validationErrors.Any(ve => ve.type == ValidationErrorType.Error) ? SubmissionStatus.ERR : SubmissionStatus.REC;

                //this will be used to insert in submission
                SetLoadStatus(loadId, status, validationErrors, submissionRejectionFlag);

                // - Create audit record
                if (status == SubmissionStatus.REC)
                {
                    AuditLogger.WriteFileAuditEntry(AuditEventClass.UploadFile, securityContext,
                        metadata.SubmissionSiteNumber, packageProperties.Name, loadId);
                }

                // - x Notify the user by e-mail
            }
            catch
            {
                if (validationErrors.All(vr => vr.Code != SubmissionValidationError.Error100_System.Code)) validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error100_System));
                if (loadId != 0)
                {
                    SetLoadStatus(loadId, SubmissionStatus.ABT, validationErrors, submissionRejectionFlag);
                }
                throw;
            }

            return validationErrors;
        }

        /// <summary>
        /// Process "No Data" submissions, user does not submits any file for this as there isn't any data to report
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="securityContext"></param>
        /// <returns>Collection of error messages</returns>
        public virtual ICollection<SubmissionValidationError> ProcessNoData(SubmissionMetadata metadata, SubmissionSecurityContext securityContext)
        {
            List<SubmissionValidationError> validationErrors = new List<SubmissionValidationError>();
            long loadId = 0;
            string submissionRejectionFlag = string.Empty;
            try
            {
                loadId = RegisterLoad(string.Empty, metadata, securityContext, SubmissionStatus.NOC);
            }
            catch
            {
                if (validationErrors.All(vr => vr.Code != SubmissionValidationError.Error100_System.Code))
                {
                    validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error100_System));
                }

                if (loadId != 0)
                {
                    SetLoadStatus(loadId, SubmissionStatus.ABT, validationErrors, submissionRejectionFlag);
                }
                throw;
            }
            return validationErrors;
        }

        /// <summary>
        /// Validates submission package properties (file name, size, etc.)
        /// </summary>
        /// <param name="packageProperties"></param>
        /// <param name="metadata"></param>
        /// <returns>Collection of error messages</returns>
        public virtual ICollection<SubmissionValidationError> ValidatePackageProperties(UploadedFileProperties packageProperties,
            SubmissionMetadata metadata, SubmissionSecurityContext securityContext)
        {

            List<SubmissionValidationError> validationErrors = new List<SubmissionValidationError>();

            if (packageProperties == null)
            {
                throw new ArgumentNullException("packageProperties");
            }

            if (metadata == null)
            {
                throw new ArgumentNullException("metadata");
            }

            if (packageProperties.Size <= 0)
            {
                validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error104_EmptyFile, packageProperties.Name));
            }


            SubmissionClassInfo submissionClassInfo = GetSubmissionClassInfo(metadata);

            Regex fileNameRegex = new Regex(submissionClassInfo.PackageFilenameRegEx, RegexOptions.IgnoreCase);
            if (!fileNameRegex.IsMatch(packageProperties.Name) || !submissionConfiguration.ValidatePackageFileName(metadata, packageProperties.Name))
            {
                validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error103_InvalidFileName, packageProperties.Name));
                SubmissionValidationError e = new SubmissionValidationError();
            }

            return validationErrors;
        }


        /// <summary>
        /// Validates all files inside the submission package
        /// </summary>
        /// <param name="packageProperties"></param>
        /// <param name="metadata"></param>
        /// <param name="loadId"></param>
        /// <returns>Collection of error messages</returns>
        protected virtual ICollection<SubmissionValidationError> ValidatePackageContent(UploadedFileProperties packageProperties, SubmissionMetadata metadata, long loadId)
        {
            List<SubmissionValidationError> validationErrors = new List<SubmissionValidationError>();

            if (packageProperties == null)
            {
                throw new ArgumentNullException("fileProperties");
            }

            if (metadata == null)
            {
                throw new ArgumentNullException("metadata");
            }

            string loadDirectory = GetLoadDirectoryName(loadId);

            DirectoryInfo objDir = new DirectoryInfo(loadDirectory);
            FileInfo[] fileList = objDir.GetFiles("*.*");

            if (fileList == null || fileList.Length == 0)
            {
                validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error104_EmptyFile, packageProperties.Name));
                return validationErrors;
            }

            SubmissionClassInfo submissionClassInfo = GetSubmissionClassInfo(metadata);

            foreach (RecordsetInfo r in submissionClassInfo.Recordsets)
            {
                Regex fileNameRegex = new Regex(r.FilenameRegEx, RegexOptions.IgnoreCase);

                var matchedNames = new List<string>();
                foreach (FileInfo fileItem in fileList)
                {
                    if (fileNameRegex.IsMatch(fileItem.Name))
                    {
                        matchedNames.Add(fileItem.Name);
                    }
                }

                if (matchedNames.Count < 1 && r.IsRequired)
                {
                    validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error102_MissingFile, r.RecordsetName));
                }
                if (matchedNames.Count > 1)
                {
                    validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error103_InvalidFileName, string.Join("; ", matchedNames)));
                }
            }

            if (!validationErrors.Any())
            {
                foreach (FileInfo fileItem in fileList)
                {
                    validationErrors.AddRange(ValidateRecordset(submissionClassInfo, fileItem, metadata));
                }
            }

            return validationErrors;
        }

        /// <summary>
        /// Validates single file in the package against configured rules.
        /// File contents must be a valid CSV with header row. Quoted line breaks (CRLF) are not supported.
        /// Header columns must match the config.
        /// Validation stops after the first error found. The file is then rejected.
        /// </summary>
        /// <param name="submissionClassInfo"></param>
        /// <param name="fileItem"></param>
        /// <param name="metadata"></param>
        /// <returns>Collection of error messages</returns>
        protected virtual ICollection<SubmissionValidationError> ValidateRecordset(SubmissionClassInfo submissionClassInfo,
            FileInfo fileItem, SubmissionMetadata metadata)
        {
            List<SubmissionValidationError> validationErrors = new List<SubmissionValidationError>();

            if (fileItem == null)
            {
                throw new ArgumentNullException("fileProperties");
            }

            bool recordsetMatchFound = false;
            foreach (var recordsetInfo in submissionClassInfo.Recordsets)
            {
                Regex fileNameRegex = new Regex(recordsetInfo.FilenameRegEx, RegexOptions.IgnoreCase);
                if (fileNameRegex.IsMatch(fileItem.Name))
                {
                    recordsetMatchFound = true;

                    if (fileItem.Length <= 0)
                    {
                        if (!recordsetInfo.IsEmptyFileAllowed)
                        {
                            validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error104_EmptyFile, fileItem.Name));
                        }
                        return validationErrors;
                    }

                    using (StreamReader sr = new StreamReader(fileItem.FullName))
                    {
                        char[] delimiter = new char[] {','};
                        // validate header
                        string header = sr.ReadLine();
                        if (string.IsNullOrWhiteSpace(header) || header.Split(delimiter, StringSplitOptions.RemoveEmptyEntries).Length == 0)
                        {
                            validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error105_InvalidHeader, fileItem.Name, "Header row is empty."));
                            return validationErrors;
                        }

                        // require all columns and exactly in the same order as in config
                        string[] columnHeaders = header.Split(delimiter, StringSplitOptions.None);
                        var configuredHeaders = recordsetInfo
                            .RecordsetColumns
                            .OrderBy(rc => rc.RecordsetColumnSequence)
                            .Select(rc => rc.RecordsetColumnName)
                            .ToArray();

                        if (columnHeaders.Length != configuredHeaders.Length)
                        {
                            validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error105_InvalidHeader, fileItem.Name, "Invalid number of columns."));
                            return validationErrors;
                        }

                        int columnCount = configuredHeaders.Length;
                        for (int i = 0; i < columnCount; ++i)
                        {
                            if (!string.Equals(configuredHeaders[i], columnHeaders[i], StringComparison.OrdinalIgnoreCase))
                            {
                                validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error105_InvalidHeader, fileItem.Name,
                                    string.Format("Invalid column name or position. Expected [{0}] found [{1}].", configuredHeaders[i], columnHeaders[i])));
                                return validationErrors;
                            }
                        }

                        // validate records
                        string line;
                        int lineNumber = 1;
                        bool ignoreEscape = (submissionClassInfo.SubmissionClassName == "GI_ENDO");
                        // don't support quoted line breaks (CRLF)
                        while ((line = sr.ReadLine()) != null)
                        {
                            ++lineNumber;

                            int dataElementCount = 0;
                            bool inQuote = false;
                            foreach (char ch in line)
                            {
                                switch (ch)
                                {
                                    case '"':
                                        if (!ignoreEscape) 
                                        {
                                            inQuote = !inQuote;
                                        }
                                        break;
                                    case ',':
                                        if (!inQuote)
                                        {
                                            ++dataElementCount;
                                        }
                                        break;
                                }
                            }

                            if (columnCount - 1 != dataElementCount || inQuote)
                            {
                                validationErrors.Add(
                                    SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error106_InvalidDataRowFormat, fileItem.Name, lineNumber));
                                return validationErrors;
                            }
                        }

                        // It is valid to check lineNumber only (as opposed to evaluating the entire line as NULL or Empty), because the code above 
                        // validates if the row is a valid data row (i.e. number of fields match the number of expected fields).
                        if (lineNumber == 1 && submissionClassInfo.SubmissionClassName == "GI_ENDO")
                        {
                            validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error104_EmptyFile, fileItem.Name));
                        }

                        if ((lineNumber == 1) && submissionClassInfo.SubmissionClassName == "SSOISIR")
                        {
                            // This is an warning
                            validationErrors.Add(SubmissionValidationWarning.CreateByTemplate(SubmissionValidationWarning.Warning191_NoDataSubmitted, fileItem.Name));
                        }

                    }
                }
            }

            if (!recordsetMatchFound)
            {
                validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error103_InvalidFileName, fileItem.Name));
            }

            return validationErrors;
        }


        protected virtual ICollection<SubmissionValidationError> ValidateRecordsetData(UploadedFileProperties packageProperties,
            SubmissionSecurityContext securityContext, SubmissionMetadata metadata, long loadId, out string submissionRejectionFlag)
        {

            List<SubmissionValidationError> validationErrors = new List<SubmissionValidationError>();

            string loadDirectory = GetLoadDirectoryName(loadId);

            DirectoryInfo objDir = new DirectoryInfo(loadDirectory);
            FileInfo[] fileList = objDir.GetFiles("*.*");


            SubmissionClassInfo submissionClassInfo = GetSubmissionClassInfo(metadata);

            SECURITY_Site securitySiteSiteInfo = submissionConfiguration.GetSiteByNumber(metadata.SubmissionSiteNumber);
            SECURITY_Facility securityFacilityInfo = submissionConfiguration.GetSiteFacility(securitySiteSiteInfo);

            //initiate datahash needed for validation engine
            DataHash ds = new DataHash();

            //get all assosiated sites with submission class
            IEnumerable<SECURITY_Role> sRoles = submissionConfiguration.GetSubmissionClassSecurityRoles(metadata.SubmissionClassName);

            //get all masternumber for sites assosiated with roles
            string[] availableSites = (from sSite in submissionConfiguration.GetSitesByRoleList(sRoles)
                                       select sSite.MasterNumber).ToArray();

            //populate datahash dictionary with submission metadata, package/file data, user data
            //these values will be used in validators to validate different rules
            ds.Add("Dsp.Package.SubmissionClassId", metadata.SubmissionClassId.ToString());
            ds.Add("Dsp.Package.ReportingPeriodTypeName", metadata.ReportingPeriodTypeName);
            ds.Add("Dsp.Package.Filename", packageProperties.Name);
            ds.Add("Dsp.Package.AllComissionedSites", String.Join(",", availableSites));

            ds.Add("Dsp.User.Name", securityContext.UserInfo.DisplayName);
            ds.Add("Dsp.User.Email", securityContext.UserInfo.EMail);
            ds.Add("Dsp.User.SiteName", securitySiteSiteInfo.SiteName);
            ds.Add("Dsp.User.SiteMasterNumber", securitySiteSiteInfo.MasterNumber);
            ds.Add("Dsp.User.FacilityName", securityFacilityInfo.FacilityName);
            ds.Add("Dsp.User.FacilityNumber", securityFacilityInfo.FacilityNumber);

            ds.Add("Dsp.Meta.SubmissionDate", packageProperties.FileSubmissionTime.ToString("yyyyMMddHHmmss"));
            ds.Add("Dsp.Meta.ReportingPeriodStartDate", metadata.SubmissionPeriodStart.ToString("yyyyMMdd"));
            ds.Add("Dsp.Meta.ReportingPeriodEndDate", metadata.SubmissionPeriodEnd.ToString("yyyMMdd"));
            ds.Add("Dsp.Meta.ReportingPeriodName", metadata.ReportingPeriodName);
            ds.Add("Dsp.Meta.ReportingPeriodCode", metadata.SubmissionPeriodCode);


            //RejectionFlag for dataset level (.zip file)
            short datasetFlagVal = 0;
            string datasetFlagKey = string.Empty;

            //RejectionFlag for recordset level (single .csv file)
            short recordsetFlagVal;
            string recordsetFlagKey = string.Empty;

            foreach (FileInfo fileItem in fileList)
            {
                ds.Add("Dsp.File.Filename", fileItem.Name);
                foreach (RecordsetInfo r in submissionClassInfo.Recordsets)
                {
                    Regex fileNameRegex = new Regex(r.FilenameRegEx, RegexOptions.IgnoreCase);
                    if (fileNameRegex.IsMatch(fileItem.Name))
                    {
                        ds.Add("Dsp.File.RecordsetName", r.RecordsetName);

                        //populate datahash with rules
                        List<Validation.ValidationRule> rules = submissionConfiguration.GetSubmissionValidationRule(r.RecordsetId);
                        ds.Rules.AddRange(rules);

                        //populate data hash submissoion file data
                        ds.Recordset = submissionConfiguration.GetDataFromCsvFile(fileItem.FullName, submissionClassInfo.SubmissionClassName);

                        ValidationEngine engine = new ValidationEngine();

                        //if validation fails or if there are any errors, it is possible that all validation rules are passed for the file but there are 
                        //erros raised (system related errors), in that case 
                        if (!engine.Validate(ds))
                        {

                            int fileLevelValidationErrorCount = ds.FileLevelErrors.Count;
                            int warningsCount = ds.FileLevelErrors.Count(x => x.isWarning);

                            // There are errors or (file validation errors and count of file validation errors is not the same 
                            if (ds.Errors.Count > 0 || (fileLevelValidationErrorCount > 0 && fileLevelValidationErrorCount != warningsCount))
                            {
                                validationErrors.Add(
                                        SubmissionValidationError.CreateByTemplate(
                                            SubmissionValidationError.Error111_InvalidData, fileItem.Name));
                            }
                            else if (warningsCount > 0)
                            {
                                validationErrors.Add(
                                        SubmissionValidationWarning.CreateByTemplate(
                                            SubmissionValidationWarning.Warning192_PotentialDuplicate, fileItem.Name));
                            }

                            //get all validation errors, and log it in database 
                            foreach (ValidationError ve in ds.Errors)
                            {
                                submissionLogRepository.InsertSubmissionValidationErrorDirect(
                                    new RedApple.DAL.SubmissionValidationError
                                    {
                                        ValidationRuleId = ve.RuleId,
                                        SubmissionEventId = loadId,
                                        ErrorMessage = ve.ErrorMessage,
                                        RowNumber = ve.RowNum,
                                        FileName = fileItem.Name,
                                        RejectionActionFlag = (!string.IsNullOrEmpty(ve.RejectionActionFlag)) ? ve.RejectionActionFlag : null
                                    }
                                );
                            }


                            //get all file level validation errors, and log it in database 
                            foreach (FileLevelError ve in ds.FileLevelErrors)
                            {
                                submissionLogRepository.InsertSubmissionFileLevelErrorDirect(
                                    new RedApple.DAL.SubmissionFileLevelError
                                    {
                                        ValidationRuleId = ve.RuleId,
                                        SubmissionEventId = loadId,
                                        ErrorMessage = ve.ErrorMessage,
                                        ImpactedRows = ve.impactedRows,
                                        FileName = fileItem.Name,
                                        RejectionActionFlag = (!string.IsNullOrEmpty(ve.RejectionActionFlag)) ? ve.RejectionActionFlag : null
                                    }
                                );
                            }

                            string [] rejectionFlags = ds.Errors.Select(x => x.RejectionActionFlag).ToArray();
                            rejectionFlags = rejectionFlags.Concat(ds.FileLevelErrors.Select(x => x.RejectionActionFlag).ToArray()).ToArray();

                            #region Setting RejectionFlag
                            RejectionFlag rj = new RejectionFlag();
                            var rjFlag = (from ve in rejectionFlags
                                          join rjStr in rj.Keys on ve equals rjStr
                                          select new
                                          {
                                              flagVal = (rj.TryGetValue(rjStr, out recordsetFlagVal)) ? recordsetFlagVal : rj.Values.First(),
                                              flagKey = (recordsetFlagVal > 0) ? rjStr : rj.Keys.First(),
                                          }
                                         ).Distinct().OrderByDescending(ord => ord.flagVal).First();

                            recordsetFlagKey = (rjFlag != null) ? rjFlag.flagKey : rj.Keys.First();
                            recordsetFlagVal = (rjFlag != null) ? rjFlag.flagVal : rj.Values.First();

                            if (recordsetFlagVal > datasetFlagVal)
                            {
                                datasetFlagVal = recordsetFlagVal;
                                datasetFlagKey = recordsetFlagKey;
                            }
                            #endregion Setting RejectionFlag
                        }
                        //if there are system error, notify user that there are syste error occured
                        else if (ds.SystemErrorFlag)
                        {
                            validationErrors.Add(
                                SubmissionValidationError.CreateByTemplate(
                                    SubmissionValidationError.Error100_System));
                        }
                        //need to set RejectionFlag in database as validation has failed
                        SubmissionRecordset sr = new SubmissionRecordset { RecordsetName = fileItem.Name, SubmissionEventId = loadId, NumberOfRecords = ds.Recordset.Rows.Count, RecordsetId = r.RecordsetId, RejectionActionFlag = (String.IsNullOrEmpty(recordsetFlagKey)) ? null : recordsetFlagKey };
                        submissionLogRepository.InsertSubmissionRecordsetDirect(sr);
                    }
                }
            }

            submissionRejectionFlag = datasetFlagKey;
            return validationErrors;
        }
        /// <summary>
        /// Registers new submission in backend control table as well as portal submission and audit tables
        /// </summary>
        /// <param name="packageProperties"></param>
        /// <param name="metadata"></param>
        /// <returns>loadId</returns>
        protected virtual long RegisterLoad(string packageName, SubmissionMetadata metadata, SubmissionSecurityContext securityContext, SubmissionStatus subStatus)
        {
            var userInfo = securityProvider.GetUserInfo(securityContext.UserInfo.LogonName);

            if (userInfo == null || userInfo.UserId == 0)
            {
                throw new LoginFailedException();
            }

            string facilityNumber = submissionConfiguration.GetSiteFacility(submissionConfiguration.GetSiteByNumber(metadata.SubmissionSiteNumber)).FacilityNumber;

            // Update two different data stores in different transactions 
            // because it is not essential to keep them in sync and to avoid creating another failure point


            // EDW DataMart Oracle db
            DATA_SUBMISSION_EVENT dse = new DATA_SUBMISSION_EVENT
            {
                CONTACT_EMAIL_ADDRESS = userInfo.EMail,
                CREATEDATETIME = DateTime.Now,
                STATUS = subStatus.ToString(),

                // [S.L]  Original code was using DateUtility to calculate the STRING based on the SubmissionPeriodStart
                // SUBMISSION_FISC_QTR = metadata.SubmissionPeriodStart.Equals(DateTime.MinValue) ? "" : DateUtility.GetFiscalQuarterString(metadata.SubmissionPeriodStart),
                SUBMISSION_FISC_QTR = metadata.SubmissionPeriodCode,

                SUBMISSION_SYSTEM = metadata.SubmissionClassName,
                SUBMITTER_FACILITY_NO = facilityNumber,
                SUBMITTER_SITE_NO = metadata.SubmissionSiteNumber,
                SUBMITTER_USERNAME = userInfo.LogonName,
                
                // ----- Added for GI-ENDO -----
                NO_CASES_REASON_KEY = metadata.NoCaseReasonId,
                NO_CASES_REASON_DESC = metadata.NoCaseReasonDesc
            };


            long loadId = edwSubmissionLogRepository.InsertDataSubmissionEventDirect(dse);
            // make sure EDW record correctly updated in case of an error since two separate transactions used

            try
            {
                // portal SQL db
                SubmissionEvent submissionEvent = new SubmissionEvent
                {
                    SubmissionEventId = loadId,
                    Status = (subStatus == SubmissionStatus.NOC) ? SubmissionStatus.REC.ToString() : subStatus.ToString(), //was reccomended by Lalin to add status "REC" in if there is no case (NOC), in oracle update it as NOC
                    SubmitterUserName = userInfo.LogonName,
                    ContactEMail = userInfo.EMail,
                    SubmissionClassName = metadata.SubmissionClassName,
                    SubmitterSiteNumber = metadata.SubmissionSiteNumber,
                    SubmitterFacilityNumber = facilityNumber,
                    PackageFileName = packageName,
                    CreateDateTime = DateTime.Now,
                    SubmissionClassId = metadata.SubmissionClassId,
                    ReportingPeriodId = (metadata.ReportingPeriodId > 0) ? (int?)metadata.ReportingPeriodId : null, //eClaims does not have Submission Period, in that case the value needs to be NULL in SubmissionEvent table 
                    NoDataDeclaredInd = (subStatus == SubmissionStatus.NOC) ? true : false,
                    NoCaseSubmissionReasonId = (int?)metadata.NoCaseReasonId
                };

                submissionLogRepository.InsertSubmissionEventDirect(submissionEvent);
            }
            catch
            {
                dse = edwSubmissionLogRepository.GetDataSubmissionEventById(loadId);
                if (dse != null)
                {
                    dse.STATUS = SubmissionStatus.ABT.ToString();
                    dse.UPDATEDATETIME = DateTime.Now;

                    edwSubmissionLogRepository.UpdateDataSubmissionEventDirect(dse);
                }

                throw;
            }

            return loadId;
        }

        /// <summary>
        /// Sets submission processing status in backend control table as well as portal submission table.
        /// Saves error messages if any in a portal submission error log table.
        /// </summary>
        /// <param name="loadId"></param>
        /// <param name="submissionStatus"></param>
        /// <param name="errors"></param>
        /// <param name="submissionRejectionFlag">this is for Version 2, default value is "NONE"</param>
        protected virtual void SetLoadStatus(long loadId, SubmissionStatus submissionStatus, ICollection<SubmissionValidationError> errors, string submissionRejectionFlag)
        {
            // Update two different data stores in different transactions 
            // because it is not essential to keep them in sync and to avoid creating another failure point

            // EDW DataMart Oracle db
            DATA_SUBMISSION_EVENT dse = edwSubmissionLogRepository.GetDataSubmissionEventById(loadId);
            if (dse == null)
            {
                throw new Exception(string.Format("Load with Id=[{0}] not found in EDW database.", loadId));
            }

            dse.STATUS = submissionStatus.ToString();
            dse.UPDATEDATETIME = DateTime.Now;

            edwSubmissionLogRepository.UpdateDataSubmissionEventDirect(dse);


            // portal SQL db
            SubmissionEvent se = submissionLogRepository.GetSubmissionEventById(loadId);
            if (se == null)
            {
                throw new Exception(string.Format("Load with Id=[{0}] not found in DataSubmissionPortal database.", loadId));
            }

            se.Status = submissionStatus.ToString();
            se.UpdateDateTime = DateTime.Now;
            if (!String.IsNullOrEmpty(submissionRejectionFlag)) se.RejectionStatusFlag = submissionRejectionFlag;

            foreach (var err in errors)
            {
                SubmissionEventError submissionEventError = new SubmissionEventError
                {
                    ErrorCode = err.Code,
                    ErrorMessage = err.Message,
                    SubmissionEventId = loadId,
                    IsWarning = err.type == ValidationErrorType.Warning ? true : false
                };
                se.SubmissionEventErrors.Add(submissionEventError);
            }

            submissionLogRepository.UpdateSubmissionEventDirect(se);
        }



        /// <summary>
        /// Saves package data files to the target location. Location root is configured.
        /// </summary>
        /// <param name="packageProperties"></param>
        /// <param name="uploadedFileStream"></param>
        /// <param name="loadId"></param>
        protected virtual ICollection<SubmissionValidationError> SavePackage(UploadedFileProperties packageProperties, Stream uploadedFileStream, long loadId)
        {
            List<SubmissionValidationError> validationErrors = new List<SubmissionValidationError>();

            try
            {
                string fileDirectory = GetLoadDirectoryName(loadId);
                Directory.CreateDirectory(fileDirectory);

                string fileExt = Path.GetExtension(packageProperties.Name);
                if (".zip".Equals(fileExt, StringComparison.OrdinalIgnoreCase))
                {
                    FileUtility.Decompress(uploadedFileStream, fileDirectory);
                }
                else
                {
                    string filePath = Path.Combine(fileDirectory, Path.GetFileName(packageProperties.Name));

                    using (Stream stream = File.Create(filePath))
                    {
                        uploadedFileStream.CopyTo(stream);
                    }
                }
            }
            catch (FileUtilityException)
            {
                validationErrors.Add(SubmissionValidationError.CreateByTemplate(SubmissionValidationError.Error101_InvalidZIPFile, packageProperties.Name));
            }

            return validationErrors;
        }

        /// <summary>
        /// Builds data target location using configured location root and current loadId
        /// </summary>
        /// <param name="loadId"></param>
        /// <returns></returns>
        protected virtual string GetLoadDirectoryName(long loadId)
        {
            return Path.Combine(submissionConfiguration.UploadFolder, loadId.ToString());
        }

        protected virtual SubmissionClassInfo GetSubmissionClassInfo(SubmissionMetadata metadata)
        {
            return submissionConfiguration.GetSubmissionClassInfo(metadata.SubmissionClassName);
        }

    }
}
