﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedApple.BusinessLogic
{
    public enum ValidationErrorType
    {
        Error = 1,
        Warning = 2
    }

    public class SubmissionValidationError
    {
        public static readonly SubmissionValidationError Error100_System = new SubmissionValidationError { Code = 100, Message = "System Error." };
        public static readonly SubmissionValidationError Error101_InvalidZIPFile = new SubmissionValidationError { Code = 101, Message = "File Error - File [{0}] is not a valid ZIP file." };
        public static readonly SubmissionValidationError Error102_MissingFile = new SubmissionValidationError { Code = 102, Message = "File Error - File for [{0}] is missing in the package." };
        public static readonly SubmissionValidationError Error103_InvalidFileName = new SubmissionValidationError { Code = 103, Message = "File Error - File(s) [{0}] is incorrectly named." };
        public static readonly SubmissionValidationError Error104_EmptyFile = new SubmissionValidationError { Code = 104, Message = "File Error - File [{0}] is empty." };
        public static readonly SubmissionValidationError Error105_InvalidHeader = new SubmissionValidationError { Code = 105, Message = "File Error - File [{0}]: header list is incorrect.{1}" };
        public static readonly SubmissionValidationError Error106_InvalidDataRowFormat = new SubmissionValidationError { Code = 106, Message = "File Error - File [{0}]: invalid number of data columns in line [{1}]." };

        /*
         SSO BRD:
            107  File name mask File name check  (file name should follow name mask provided in Appendix 1, #A, B) File  Error –File is incorrectly named
            108 Facility number Facility number in the file name should correspond  to the source file location File  Error –File is incorrectly named
            109 Submitting year Year in file name between 2010 and current year (all inclusive) File  Error –File submission year is incorrect
            110 Submitting Quarter Quarter number in file name must be one of the values 1,2,3 or 4 File  Error –Invalid submitting Quarter 
         */

        public static readonly SubmissionValidationError Error111_InvalidData = new SubmissionValidationError { Code = 111, Message = "File Data Error: [{0}]: Invalid data" };        


        public int Code { get; set; }
        public string Message { get; set; }

        public virtual ValidationErrorType type { get { return ValidationErrorType.Error; } }

        public static SubmissionValidationError CreateByTemplate(SubmissionValidationError template, params object[] args)
        {
            return new SubmissionValidationError { Code = template.Code, Message = string.Format(template.Message, args) };
        }
    }


    // [S.L] V1.4 SSO Warning is introduced, inherited from the base to distinguish between the two types

    public class SubmissionValidationWarning : SubmissionValidationError
    {
        public static readonly SubmissionValidationWarning Warning191_NoDataSubmitted = new SubmissionValidationWarning { Code = 191, Message = "Warning – No data submitted. If there are data records, please resubmit." };

        public static readonly SubmissionValidationWarning Warning192_PotentialDuplicate = new SubmissionValidationWarning { Code = 192, Message = "File Warning: [{0}]: You are seeing this warning message because there are duplicate records (more than one procedure record for the same person on the same day) on the file" };

        public override ValidationErrorType type { get { return ValidationErrorType.Warning; } }

        public static SubmissionValidationWarning CreateByTemplate(SubmissionValidationWarning template, params object[] args)
        {
            return new SubmissionValidationWarning { Code = template.Code, Message = string.Format(template.Message, args) };
        }
    }

}
