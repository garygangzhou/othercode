﻿using RedApple.DAL;
using System;
using System.Collections.Generic;
using System.Data;

namespace RedApple.BusinessLogic
{
    public interface ISubmissionConfiguration
    {
        string DataApplicationName { get; }
        string UploadFolder { get; }
        string TemplatesFolder { get; }
        //string EmailFromAddress { get; }
        //string EmailServer { get; }

        bool IsAllowedOverrideDateTime { get; }       // For debug/qa to use, set it to FALSE in production or higher environment


        IEnumerable<SECURITY_Role> GetSecurityRoles();

        IEnumerable<SECURITY_Site> GetSites();
        IEnumerable<SECURITY_Site> GetSitesByRoleList(IEnumerable<SECURITY_Role> roles);
        SECURITY_Site GetSiteByNumber(string siteNumber);
        SECURITY_Facility GetSiteFacility(SECURITY_Site site);
        IEnumerable<SubmissionClassInfo> GetSubmissionClasses();
        IEnumerable<SubmissionClassInfo> GetSubmissionClassesByRoleNameList(IEnumerable<string> roleNames);
        SubmissionClassInfo GetSubmissionClassInfo(string submissionClassName);
        IEnumerable<SECURITY_Role> GetSubmissionClassSecurityRoles(string submissionClassName);

        IEnumerable<ReportInfo> GetReportsByAccessRightNameList(IEnumerable<string> accessRightNames);
        ReportInfo GetReportById(int reportId);
        SECURITY_User GetSecurityUserByUserId(long userId);

        void UpdateSecurityUserEULA(SECURITY_User securityUser);

        // S.L: Note that all the new methods takes string (submissionClassName) instead of int (submissionClassID) as parameter, 
        //      simply because the original design populates the dropdown box based on name instead of ID. Therefore, we follow 
        //      the existing architecure. Personally, I think there are 2 drawbacks, firstly it may have additional overhead to 
        //      convert the classname to object to get the ID. Secondly "SubmissionClassName" column is not unique in dbo.SubmissionClass table
        //      in terms of data integrity. Same thing applies to Site dropdown, it uses "MasterNumber" instead of the primary key as ID.

        IEnumerable<SubmissionPeriod> GetSubmissionPeriodList(DateTime dateTime, string submissionClassName, string submissionSiteNumber, int numberOfPreviousPeriodShown);  // Helper method that takes string instead of int for IDs
        IEnumerable<SubmissionPeriod> GetSubmissionPeriodList(DateTime dateTime, int submissionClassID, int submissionSiteID, int numberOfPreviousPeriodShown);  // SubmissionPeriod is a new Entity geneated by VIEW/SP (In EF, it is a complex-type)
        bool IsSubmissionScheduleEnabled(string submissionClassName);
        bool IsSubmissionScheduleDefined(string submissionClassName);
        IEnumerable<ReportingPeriod> GetReportPeriodList(string submissionClassName);
        bool UpdateUseSubmissionSchedule(string submissionClassName, bool isEnabled);                    // Class level - SubmissionClass db table
        SubmissionSchedule GetSubmissionSchedule(string submissionClassName, int reportingPeriodID);     // Class level - SubmissionClass db table
        bool UpdateSubmissionSchedule(string submissionClassName, int reportingPeriodID,   DateTime newStartDate, DateTime newEndDate);     // Reporting period level - SubmissionSchedule db table
        IEnumerable<SubmissionScheduleOverride> GetSubmissionScheduleOverrideList(string submissionClassName, int reportingPeriodID, IEnumerable<int> siteIDList);                             // Override - SubmissionScheduleOverride db table
        bool UpsertOverrideSchedules(string submissionClassName, int reportingPeriodID, IEnumerable<int> siteIDList, DateTime effectiveDateTime, int numberOfDaysEffective);   // Override - SubmissionScheduleOverride db table
        bool DeleteOverrideSchedules(string submissionClassName, int reportingPeriodID, IEnumerable<int> siteIDList);    // Override - SubmissionScheduleOverride db table

        //this is to get ShowNumberOfPeriod (number of items in "Submission Period" dropdown list)
        int GetSubmissionShowNumberOfPeriod(string submissionClassName);

        // These are new methods added to support data validation on front-end
        List<Validation.ValidationRule> GetSubmissionValidationRule(int recordSetId);
        DataTable GetDataFromCsvFile(string filePath, string submissionClassName);

        bool HasPeviousLoadBySiteNumberReportingPeriodId(string submissionClassName, string submissionSiteNumber, int reportingPeriodId);

        bool ValidatePackageFileName(SubmissionMetadata metadata, string packageName);

        List<NoCaseSubmissionReasons> GetNoCaseSubmissionReasonBySubmissionClass(string submissionClass);
    }
}
