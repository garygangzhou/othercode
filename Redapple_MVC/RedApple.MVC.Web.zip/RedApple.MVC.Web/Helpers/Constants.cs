﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RedApple.MVC.Web
{
    public static class Constants
    {
        public static class ApplicationKeys
        {
            public static string Unity = "Unity";
        }

        public static class SessionKeys
        {
            public static string UserInfo = "UserInfo";
            public static string SubmissionClassName = "SubmissionClassName";
            public static string SubmissionSiteNumber = "SubmissionSiteNumber";
            public static string ReportId = "ReportId";
            public static string TargetUrl = "TargetUrl";
        }

        public static class UrlKeys
        {
            public static string SubmissionClass = "SubmissionClass";
        }

    }
}