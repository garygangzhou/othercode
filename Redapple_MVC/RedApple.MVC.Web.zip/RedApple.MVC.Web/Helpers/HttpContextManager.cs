﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RedApple.MVC.Web.Helpers
{
    public static class HttpContextManager
    {
        private static HttpContextBase theContext;
        public static HttpContextBase Current
        {
            get
            {
                if (theContext != null)
                    return theContext;

                if (HttpContext.Current == null)
                    throw new InvalidOperationException("HttpContext not available");

                return new HttpContextWrapper(HttpContext.Current);
            }
        }

        public static void SetCurrentContext(HttpContextBase context)
        {
            theContext = context;
        }
    }
}