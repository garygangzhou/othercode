﻿using RedApple.BusinessLogic;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RedApple.MVC.Web.Helpers 
{
    public static class SecurityHelper 
    {
        public static ApplicationUser UserInfo
        {
            get
            {
                ApplicationUser appUser = HttpContextManager.Current.Session[Constants.SessionKeys.UserInfo] as ApplicationUser;
                return appUser;
            }

            private set
            {
                HttpContextManager.Current.Session[Constants.SessionKeys.UserInfo] = value;
            }
        }

        public static void Login()
        {
            string userLogonName = HttpContextManager.Current.User.Identity.Name;
            if (UserInfo == null)
            {
                ISecurityProvider securityProvider = DependencyResolver.Current.GetService<ISecurityProvider>();

                UserInfo = securityProvider.GetUserInfo(userLogonName);
                
            }
        }

        public static void Logout()
        {
            HttpContextManager.Current.Session.Clear();
            HttpContextManager.Current.Session.Abandon();            
        }

        public static SubmissionSecurityContext GetSubmissionSecurityContext()
        {
            var userInfo = UserInfo;

            var newUserInfo = new ApplicationUser();
            if (userInfo != null)
            {
                newUserInfo.UserId = userInfo.UserId;
                newUserInfo.DisplayName = userInfo.DisplayName;
                newUserInfo.LogonName = userInfo.LogonName;
                newUserInfo.EMail = userInfo.EMail;
                newUserInfo.EULA = userInfo.EULA;                
            }

            if (string.IsNullOrWhiteSpace(newUserInfo.LogonName))
            {
                newUserInfo.LogonName = HttpContextManager.Current.User.Identity.Name;
                if (!string.IsNullOrWhiteSpace(newUserInfo.LogonName))
                {
                    int i = newUserInfo.LogonName.LastIndexOf('\\');
                    if (i != -1)
                    {
                        newUserInfo.LogonName = newUserInfo.LogonName.Substring(i + 1);
                    }
                }
            }

            return new SubmissionSecurityContext 
            {
                UserInfo = newUserInfo,
                SessionId = HttpContextManager.Current.Session.SessionID,
                SourceAddress = HttpContextManager.Current.Request.UserHostAddress
            };
        }

        public static void RefreshUserInfo()
        {
            if ( UserInfo != null)
            {
                ISecurityProvider securityProvider = DependencyResolver.Current.GetService<ISecurityProvider>();
                UserInfo = securityProvider.GetUserInfo(UserInfo.LogonName);
            }            
        }

        public static bool IsValidEULA()
        {
            if (UserInfo.EULA.HasValue)
                return true;

            return false;
        }
    }
}