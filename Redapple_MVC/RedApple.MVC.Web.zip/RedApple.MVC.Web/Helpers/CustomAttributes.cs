﻿using RedApple.BusinessLogic;
using RedApple.MVC.Web.Controllers;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace RedApple.MVC.Web.Helpers
{
    internal class EulaRequiredAttribute : FilterAttribute, IActionFilter
    {
        void IActionFilter.OnActionExecuted(ActionExecutedContext filterContext)
        {
            // Method intentionally left empty.            
        }

        void IActionFilter.OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (
                !(filterContext.Controller is AuthController)  // Actions in AuthController doesn't require EULA 
                &&
                !SecurityHelper.IsValidEULA()
                )
            {
                SubmissionSecurityContext securityContext = SecurityHelper.GetSubmissionSecurityContext();
                AuditLogger.WriteSecurityAuditEntry(AuditEventClass.EulaPresentation, securityContext);
                filterContext.Result = new RedirectToRouteResult("EULA", new RouteValueDictionary { { "f", filterContext.HttpContext.Request.Url.PathAndQuery } });
            }
        }
    }

    internal class AuthorizationAttribute : FilterAttribute, IActionFilter
    {
        private readonly string[] roles;
        /// <summary>
        /// determine whether current user in one of given roles.          
        /// </summary>
        /// <param name="roles"></param>
        public AuthorizationAttribute(params string[] roles) {
            this.roles = roles;
        }

        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
            //empty
        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            ISecurityProvider securityProvider = DependencyResolver.Current.GetService<ISecurityProvider>() ;
            if (securityProvider == null)
            {
                filterContext.Result = NotAuthAction();
                return;
            }

            if (roles == null || !roles.Any())
            {
                filterContext.Result = NotAuthAction();
                return;
            }

            if (SecurityHelper.UserInfo == null) {
                //session time out
                filterContext.Result = new RedirectResult("~/SessionExpired.html", false);
                return;
            }

            bool authorizated = false;
            foreach (string role in roles)
            {
                //one role granted is enough
                if (authorizated) break;

                switch (role)
                {
                    case "Upload":
                        //all user can submit
                        authorizated = true;                        
                        break;
                    case "EditSchedule":
                        authorizated = securityProvider.HasEditSubmissionPeriodPermission(SecurityHelper.UserInfo.LogonName);                        
                        break;
                    default:                        
                        break;

                }//end of switch
            }

            if (!authorizated)
            {
                filterContext.Result = NotAuthAction();
            }
        }

        private ActionResult NotAuthAction()
        {            
            return new RedirectToRouteResult("UnAuth", null);
        }
    }
    
}
