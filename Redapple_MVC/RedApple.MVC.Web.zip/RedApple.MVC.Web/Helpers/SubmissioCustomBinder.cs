﻿using RedApple.MVC.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RedApple.MVC.Web.Helpers
{
    public class SubmissioCustomBinder : IModelBinder 
    {
        public  object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {            
            var vm = (SubmissionViewModel)(bindingContext.Model ?? new SubmissionViewModel());
            SubmissionUserInput input = vm.Inputs;

            input.SubmissionClass = GetValue<string>(bindingContext, "submissionclasses");
            input.FacilitySites = GetValue<string>(bindingContext, "facilitysites");

            string submissionperiod = GetValue<string>(bindingContext, "submissionperiod");
            input.SubmissionPeriodID = string.IsNullOrEmpty(submissionperiod) ? -1 : int.Parse(submissionperiod);

            string nocasesreasons = GetValue<string>(bindingContext, "nocasesreasons");
            string chknocasestosubmit = GetValue<string>(bindingContext, "chknocasestosubmit");

            input.NoCase = string.IsNullOrEmpty(chknocasestosubmit) ? false : chknocasestosubmit == "on";
            input.NoCaseReaseonID = string.IsNullOrEmpty(nocasesreasons) ? -1 : int.Parse(nocasesreasons);

            if (!input.NoCase)
            {
                input.NoCaseReaseonID = -1;//override form value, in case drop down being hidden after user's selection
            }

            return vm;
        }

        private T GetValue<T>(ModelBindingContext bindingContext, string key)
        {
            ValueProviderResult valueProviderResult = bindingContext.ValueProvider.GetValue(key);
            if (valueProviderResult == null)
            {
                return default(T);
            }
            bindingContext.ModelState.SetModelValue(key, valueProviderResult);
            return (T)valueProviderResult.ConvertTo(typeof(T));
        }
    }
}
