﻿using RedApple.BusinessLogic;
using RedApple.DAL;
using RedApple.MVC.Web.Helpers;
using RedApple.MVC.Web.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RedApple.MVC.Web.Controllers
{
    [Authorization("Upload")]
    public class HomeController : BaseController
    {
        private readonly ISubmissionProcessor submissionProcessor;
        public HomeController(ISubmissionConfiguration submissionConfiguration, ISecurityProvider securityProvider, ISubmissionProcessor submissionProcessor) : base(submissionConfiguration, securityProvider)
        {
            this.submissionProcessor = submissionProcessor;
        }

        public ActionResult Index()
        {           
            //populate view model    
            SubmissionViewModel vm = InitialViewModel();
            return View(vm);
        }

        [ValidateAntiForgeryToken]
        [HttpPost]        
        public ActionResult Index(SubmissionViewModel vm, HttpPostedFileBase userSelectedFile)
        {
            Session[Constants.SessionKeys.SubmissionClassName] = vm.Inputs.SubmissionClass;
            Session[Constants.SessionKeys.SubmissionSiteNumber] = vm.Inputs.FacilitySites;

            //get posted file, model binder doesn't handle
            vm.Inputs.UploadFile = userSelectedFile;

            if (Request.Form.Get("hiddenbox") == null)
            {
                //user change submission classes or facility/site drop down
                //adding code before render view
            }
            else
            {
                //submission button clicked               
                bool valid = ValidateInputs(vm.Inputs);

                if (valid)
                {
                    //valid input, submission processing
                    ProcessSubmission(vm.Inputs);
                }
            }
            
            SubmissionViewModel wrapper = InitialViewModel(vm.Inputs);
            return View(wrapper);
        }
                
        [HttpPost]
        public ActionResult CheckPreviousLoad(string submissionClassName, string submissionSiteNumber, string repPeriodId)
        {
            bool retVal = false;
            int reportingPeriodId = 0;
            if (int.TryParse(repPeriodId, out reportingPeriodId)
                &&
                submissionConfiguration.HasPeviousLoadBySiteNumberReportingPeriodId(submissionClassName, submissionSiteNumber, reportingPeriodId))
            {
                retVal = true;
            }

            return new JsonResult() { Data = retVal, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }

        public ActionResult Contactus()
        {
            return View();
        }

        public ActionResult Documents()
        {
            //get list of documents          
            var userSubmissionClasses = securityProvider.GetUserSubmissionClasses(SecurityHelper.UserInfo.LogonName)
                   .OrderBy(sc => sc.SubmissionClassId);
            List<Document> documents = new List<Models.Document>();

            // get doc list for each submission class
            if (userSubmissionClasses != null && userSubmissionClasses.Any())
            {
                foreach (SubmissionClassInfo sci in userSubmissionClasses)
                {
                    Document d = new Document();
                    d.DocumentDescription = sci.Description;
                    documents.Add(d);

                    var templateFiles = sci.Recordsets
                        .Where(r => !(string.IsNullOrEmpty(r.TemplateFilePath) || string.IsNullOrEmpty(r.TemplateFileMIMEType))
                        && System.IO.File.Exists(GetFullTemplateFilePath(r.TemplateFilePath))
                        )
                    .OrderBy(r => r.RecordsetId);

                    if (templateFiles != null && templateFiles.Any())
                    {
                        foreach (var theTemplateFile in templateFiles)
                        {
                            d.DocumentRecordSets.Add(new DocumentRecordSet()
                            {
                                DocumentRecordSetDescription = theTemplateFile.Description,
                                DocumentRecordSetID = theTemplateFile.RecordsetId
                            });
                        }
                    }
                }
            }

            return View(documents);
        }

        public void DownloadPDF(int id)
        {
            RecordsetInfo ri = GetRecordsetById(id);
            if (ri != null)
            {
                string filePath = GetFullTemplateFilePath(ri.TemplateFilePath);
                string fileName = Path.GetFileName(ri.TemplateFilePath);

                Response.Clear();

                Response.ContentType = ri.TemplateFileMIMEType;

                Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

                Response.WriteFile(filePath);
                Response.End();
            }
            else
            {
                //error
            }
        }

        private string GetFullTemplateFilePath(string templateFilePath)
        {
            string root = submissionConfiguration.TemplatesFolder;
            if (string.IsNullOrWhiteSpace(root))
            {
                root = Server.MapPath("~/UploadFileTemplates");
            }

            return Path.Combine(root, templateFilePath);
        }

        private RecordsetInfo GetRecordsetById(int recordsetId)
        {
            RecordsetInfo ret = null;
            var userSubmissionClasses = securityProvider.GetUserSubmissionClasses(SecurityHelper.UserInfo.LogonName);
            foreach (var sc in userSubmissionClasses)
            {
                SubmissionClassInfo sci = submissionConfiguration.GetSubmissionClassInfo(sc.SubmissionClassName);
                ret = sci.Recordsets.SingleOrDefault(r => r.RecordsetId == recordsetId);
                if (ret != null)
                {
                    break;
                }
            }

            return ret;
        }

        private SubmissionViewModel InitialViewModel(SubmissionUserInput inputs = null)
        {
            SubmissionViewModel vm = new SubmissionViewModel();
            vm.Inputs = inputs;

            //submission classes
            string selectedSubmissionClassName = Request.QueryString[Constants.UrlKeys.SubmissionClass];
            if (string.IsNullOrEmpty(selectedSubmissionClassName) && Session[Constants.SessionKeys.SubmissionClassName] != null)
            {
                selectedSubmissionClassName = Session[Constants.SessionKeys.SubmissionClassName].ToString();
            }

            var userSubmissionClasses = securityProvider.GetUserSubmissionClasses(SecurityHelper.UserInfo.LogonName);

            if (inputs != null && !string.IsNullOrEmpty(inputs.SubmissionClass))
            {
                selectedSubmissionClassName = inputs.SubmissionClass;
            }

            if (!userSubmissionClasses.Any()
                ||
                (!userSubmissionClasses.Any(sc =>
                string.IsNullOrEmpty(selectedSubmissionClassName) ||
                string.Equals(sc.SubmissionClassName, selectedSubmissionClassName, StringComparison.OrdinalIgnoreCase))
                ))
            {
                SubmissionSecurityContext securityContext = SecurityHelper.GetSubmissionSecurityContext();
                AuditLogger.WriteSecurityAuditEntry(AuditEventClass.UserNotAuthorized, securityContext);
                throw new NoPermissionsException("No Access to Submission Program");
            }

            if (string.IsNullOrEmpty(selectedSubmissionClassName))
            {
                selectedSubmissionClassName = userSubmissionClasses.First().SubmissionClassName;
            }

            vm.SubmissionClasses.AddRange(
                userSubmissionClasses
                    .OrderBy(sc => sc.Version).ThenBy(sc2 => sc2.SubmissionClassId)
                    .Select(sc =>
                   new MyNameValue
                   {
                       Desc = sc.Description,                       
                       Id = sc.SubmissionClassName,
                       Selected = string.Equals(sc.SubmissionClassName, selectedSubmissionClassName, StringComparison.OrdinalIgnoreCase)
                   }
                ));

            Session[Constants.SessionKeys.SubmissionClassName] = selectedSubmissionClassName;
            ViewBag.SelectedSubmissionClass = selectedSubmissionClassName;

            //facility sites
            string selectedSiteMasterNumber = string.Empty;
            var userSites = securityProvider.GetSubmissionClassUserSites(SecurityHelper.UserInfo.LogonName, selectedSubmissionClassName);
            if (!userSites.Any())
            {
                SubmissionSecurityContext securityContext = SecurityHelper.GetSubmissionSecurityContext();
                AuditLogger.WriteSecurityAuditEntry(AuditEventClass.UserNotAuthorized, securityContext);
                throw new NoPermissionsException("No Access to Facility/Site");                
            }

            if (Session[Constants.SessionKeys.SubmissionSiteNumber] != null)
            {
                selectedSiteMasterNumber = Session[Constants.SessionKeys.SubmissionSiteNumber].ToString();
            }

            if (inputs != null && string.IsNullOrEmpty(inputs.FacilitySites))
            {
                selectedSiteMasterNumber = inputs.FacilitySites;
            }

            //previous selected facility may not in current facility list
            if (!userSites.Any(s => s.MasterNumber == selectedSiteMasterNumber))
            {
                selectedSiteMasterNumber = userSites.First().MasterNumber;
            }

            vm.FacilitySites.AddRange(
                userSites.Select(site => new { site, facility = submissionConfiguration.GetSiteFacility(site) })
                    .OrderBy(s => s.site.MasterNumber)
                    .Select(s =>
                    new MyNameValue
                    {
                        Desc = string.Format("{0} - {1} ({2} - {3})", s.site.MasterNumber, s.site.SiteName, s.facility.FacilityNumber, s.facility.FacilityName),
                        Id = s.site.MasterNumber,
                        Selected = string.Equals(s.site.MasterNumber, selectedSiteMasterNumber, StringComparison.OrdinalIgnoreCase)
                    }
                    ).ToArray());

            Session[Constants.SessionKeys.SubmissionSiteNumber] = selectedSiteMasterNumber.ToString();
            ViewBag.SelectedFacilitySites = vm.FacilitySites.First(a => a.Selected).Id;

            //submission period
            if (submissionConfiguration.IsSubmissionScheduleDefined(selectedSubmissionClassName))
            {
                IEnumerable<SubmissionPeriod> submissionPeriod = GetSubmissionPeriods(selectedSubmissionClassName, selectedSiteMasterNumber);
                string selectedPeriodID = string.Empty;
                if (inputs != null && submissionPeriod.Any(s => s.ReportingPeriodId.ToString().Equals(inputs.SubmissionPeriodID.ToString())))
                {
                    selectedPeriodID = inputs.SubmissionPeriodID.ToString();
                }

                if (submissionPeriod.Any())
                {
                    vm.SubmissionPeriods.AddRange(
                        submissionPeriod.Select(s =>
                       new MyNameValue
                       {
                           Desc = s.ReportingPeriodName,
                           Id = s.ReportingPeriodId.ToString(),
                           Selected = string.IsNullOrEmpty(selectedPeriodID) ? (bool)s.IsCurrentPeriod : s.ReportingPeriodId.ToString().Equals(selectedPeriodID)
                       }
                        ));
                }

                ViewBag.SelectedSubmissionPeriod = vm.SubmissionPeriods.First(a => a.Selected).Id;
            }
            else
            {
                vm.SubmissionPeriods = null;
            }

            //no case
            if (selectedSubmissionClassName == "GI_ENDO")
            {
                vm.NoCaseVisible = true;
                if (inputs != null && inputs.NoCase)
                {
                    ViewBag.NoCase = "on";
                }
            }
            else
            {
                vm.NoCaseVisible = false;
            }

            if (vm.NoCaseVisible)
            {
                //no case reason
                var noCaseSubmissionReason = GetNoCaseSubmissionReasonsSource(selectedSubmissionClassName);
                string userSelectedNoCaseReasonsID = "-1";
                if (inputs != null
                    && inputs.NoCaseReaseonID > 0
                    && noCaseSubmissionReason.Any(s => s.NoCaseSubmissionReasonId.ToString().Equals(inputs.NoCaseReaseonID.ToString()))
                    )
                {
                    userSelectedNoCaseReasonsID = inputs.NoCaseReaseonID.ToString();
                }

                vm.NoCaseReasons.Add(new MyNameValue() { Id = "-1", Selected = userSelectedNoCaseReasonsID.Equals("-1") });
                vm.NoCaseReasons.AddRange(
                    noCaseSubmissionReason
                    .OrderBy(a => a.SortOrder)
                    .Select(a =>
                            new MyNameValue
                            {
                                Desc = a.Text,
                                Id = a.NoCaseSubmissionReasonId.ToString(),
                                Selected = userSelectedNoCaseReasonsID.Equals(a.NoCaseSubmissionReasonId.ToString())
                            }
                        )
                    );

                ViewBag.SelectedNoCaseReasons = vm.NoCaseReasons.First(a => a.Selected).Id;
            }
            else
            {
                vm.NoCaseReasons = null;
            }

            vm.ScheduleEditorRole = (securityProvider.HasEditSubmissionPeriodPermission(SecurityHelper.UserInfo.LogonName));           

            return vm;
        }

        private IEnumerable<SubmissionPeriod> GetSubmissionPeriods(string selectedSubmissionClassName, string selectedSiteMasterNumber)
        {
            int numOfPeriodToShow = submissionConfiguration.GetSubmissionShowNumberOfPeriod(selectedSubmissionClassName);
            var submissionPeriod = submissionConfiguration.GetSubmissionPeriodList(this.CurrentDateTime, selectedSubmissionClassName, selectedSiteMasterNumber, numOfPeriodToShow);
            return submissionPeriod;
        }

        private DateTime CurrentDateTime
        {
            get
            {
                if ((Request.QueryString["DateTime"] != null) && (submissionConfiguration.IsAllowedOverrideDateTime))
                    return (DateTime.Parse(Request.QueryString["DateTime"]));
                else
                    return DateTime.Now;
            }

        }

        private bool ValidateSubmissionPeriod(SubmissionUserInput inputs)
        {
            if (submissionConfiguration.IsSubmissionScheduleEnabled(inputs.SubmissionClass))
            {
                //with eanbled schedule, also need submission period being set
                return (GetSelectedSubmissionPeriod(inputs) == null) ? false : true;
            }
            else
            {
                //dont have schedule, or with disabled schedule
                return !submissionConfiguration.IsSubmissionScheduleDefined(inputs.SubmissionClass);
            }
        }

        private bool ValidateNoCaseReason(SubmissionUserInput inputs)
        {
            // no case reason must be selected when no case checkbox checked
            if (inputs.SubmissionClass != "GI_ENDO") return true;
            return
                (!inputs.NoCase && inputs.NoCaseReaseonID == -1)
                ||
                (inputs.NoCase && inputs.NoCaseReaseonID > 0);
        }

        private bool ValidateFile(SubmissionUserInput inputs)
        {
            return inputs.NoCase //no file reqired
                ||
                (!inputs.NoCase && inputs.UploadFile != null);
        }

        private SubmissionPeriod GetSelectedSubmissionPeriod(SubmissionUserInput inputs)
        {
            // If useSubmissionSchedule is enabled:
            //  - result returns as NULL if deadline has passed
            //  - result returns 1 row if within submission period (same one that user selected from dropdown)

            DateTime timeStamp = this.CurrentDateTime;

            var submissionPeriod = GetSubmissionPeriods(inputs.SubmissionClass, inputs.FacilitySites);
            return submissionPeriod.FirstOrDefault(a => (string.Equals(a.ReportingPeriodId.ToString(), inputs.SubmissionPeriodID.ToString(), StringComparison.OrdinalIgnoreCase)) &&
                                                           (a.SubmissionPeriodStartDate <= timeStamp) &&
                                                           (timeStamp <= a.SubmissionPeriodEndDate));

        }      

        private void ProcessSubmission(SubmissionUserInput inputs)
        {
            SubmissionClassInfo submissionClassInfo = submissionConfiguration.GetSubmissionClasses()
                    .First(sc => sc.SubmissionClassName == inputs.SubmissionClass);
            SubmissionMetadata metadata = new SubmissionMetadata
            {
                SubmissionClassName = inputs.SubmissionClass,
                SubmissionSiteNumber = inputs.FacilitySites,
                SubmissionPeriodCode = "",  // Init         
                Version = submissionClassInfo.Version,
                SubmissionClassId = submissionClassInfo.SubmissionClassId,
            };

            if (inputs.NoCase)
            {
                metadata.NoCaseReasonId = inputs.NoCaseReaseonID;
                List<NoCaseSubmissionReasons> noCaseSubmissionReason = GetNoCaseSubmissionReasonsSource(inputs.SubmissionClass);
                metadata.NoCaseReasonDesc = noCaseSubmissionReason
                    .First(s => s.NoCaseSubmissionReasonId == inputs.NoCaseReaseonID)
                    .Text;
            }

            //eClaims doesnot have submission period, so only assign value to "ReportingPeriodId" when there is a submission period
            if (submissionConfiguration.IsSubmissionScheduleDefined(inputs.SubmissionClass))
            {
                metadata.ReportingPeriodId = inputs.SubmissionPeriodID;
            }

            if (submissionConfiguration.IsSubmissionScheduleDefined(inputs.SubmissionClass))      // DB column: SubmissionClass > ReportingPeriodTypeID (Null or Integer) 
            {
                // Any reporting type but regardless of UseSubmissionSchedule is enabled or disabled
                IEnumerable<ReportingPeriod> reportList = submissionConfiguration.GetReportPeriodList(inputs.SubmissionClass);
                if (reportList != null)
                {
                    ReportingPeriod selectedPeriod = reportList.FirstOrDefault(a => a.ReportingPeriodId.ToString() == inputs.SubmissionPeriodID.ToString());
                    if (selectedPeriod != null)
                    {
                        metadata.SubmissionPeriodStart = (DateTime)selectedPeriod.ReportingPeriodStartDate;
                        metadata.SubmissionPeriodEnd = (DateTime)selectedPeriod.ReportingPeriodEndDate;
                        metadata.SubmissionPeriodCode = selectedPeriod.ReportingPeriodCode;  // For Oracle field "SUBMISSION_FISC_QTR"    
                        metadata.ReportingPeriodName = selectedPeriod.ReportingPeriodName;
                        metadata.ReportingPeriodTypeName =
                            selectedPeriod.ReportingPeriodType.ReportingPeriodTypeName;
                    }
                }
            }
            else
            {
                // eClaims will insert NULL into submission_Fisc_Qtr field  (Intended to be blank for future)
            }

            //check if user had checked "No Case", if so then no need to process package as there isn't any package.
            //In this case just update database (Oracle and SQL) with "NOC" status that indicated site does not have any data to report for the specific period
            var errors = (inputs.NoCase) ?
                              submissionProcessor.ProcessNoData(metadata, SecurityHelper.GetSubmissionSecurityContext())
                          :
                              submissionProcessor.ProcessPackage(
                                new UploadedFileProperties { Name = Path.GetFileName(inputs.UploadFile.FileName), Size = inputs.UploadFile.ContentLength, FileSubmissionTime = DateTime.Now },
                                inputs.UploadFile.InputStream,
                                metadata,
                                SecurityHelper.GetSubmissionSecurityContext());

            if (errors.Any())
            {
                ShowErrorMessage(errors);
            }
            else
            {
                ShowSuccessMessage(inputs, metadata);
            }
        }

        private void ShowSuccessMessage(SubmissionUserInput inputs, SubmissionMetadata metadata)
        {
            string successMessage = "Thank you for your submission. Your data is being processed. Please review the status of the submission in the Report Viewer";
            if (inputs.NoCase)
            {
                string reportingPeriodDateStr = (metadata.SubmissionPeriodStart != DateTime.MinValue) ? metadata.SubmissionPeriodStart.ToString("MMMM yyyy") : "";
                successMessage = "No Cases has successfully been reported for [" + reportingPeriodDateStr + "]";
            }

            ViewBag.Message = successMessage;
        }

        private void ShowErrorMessage(ICollection<BusinessLogic.SubmissionValidationError> errors)
        {
            int errorCount = errors.Count(a => a.GetType() == typeof(BusinessLogic.SubmissionValidationError));
            int warningCount = errors.Count(a => a.GetType() == typeof(SubmissionValidationWarning));

            if (errorCount > 0)
            {
                List<string> errs = new List<string>();
                errs.AddRange(
                    errors.Select(e => e.Message)
                    );
                ViewBag.Errors = errs;
            }

            if (warningCount > 0)
            {
                // Space holder for future warning message   
                // ViewBag.Warnings           
            }
        }

        private List<NoCaseSubmissionReasons> GetNoCaseSubmissionReasonsSource(string submissionClassName)
        {
            //TODO: should be cached
            return submissionConfiguration.GetNoCaseSubmissionReasonBySubmissionClass(submissionClassName);
        }

        private bool ValidateInputs(SubmissionUserInput inputs)
        {
            //submission period
            bool valid = ValidateSubmissionPeriod(inputs);
            if (!valid)
            {
                ViewBag.ShowValidateSubmissionPeriodErrorMessage = true;
            }           

            //no case
            if (valid)
            {
                valid = ValidateNoCaseReason(inputs);
                if (!valid)
                {
                    ViewBag.ShowNoCaseReasonErrorMessage = true;
                }
            }

            //file
            if (valid)
            {
                valid = ValidateFile(inputs);
                if (!valid)
                {
                    ViewBag.ShowNoFileErrorMessage = true;
                }
            }

            return valid;
        }
    }
}