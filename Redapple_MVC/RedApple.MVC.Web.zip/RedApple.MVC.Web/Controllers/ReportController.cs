﻿using RedApple.DAL;
using RedApple.MVC.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RedApple.BusinessLogic;

namespace RedApple.MVC.Web.Controllers
{
    [Authorization("Upload")]
    public class ReportController : BaseController
    {
        public ReportController(ISubmissionConfiguration submissionConfiguration, ISecurityProvider securityProvider) : base(submissionConfiguration, securityProvider)
        {
        }

        // GET: Report
        public ActionResult Index()
        {
            //get list of report
            var userReports = securityProvider.GetUserReports(SecurityHelper.UserInfo.LogonName);

            return View(userReports);
        }
        public ActionResult ViewReport(int id)
        {
            Session[Constants.SessionKeys.ReportId] = id;
            return new RedirectResult("~/InternalSite/ReportViewer.aspx", false);        
            
        }
    }
}