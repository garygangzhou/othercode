﻿using RedApple.MVC.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RedApple.BusinessLogic;

namespace RedApple.MVC.Web.Controllers
{
    [Authorization("EditSchedule")]
    public class ScheduleController : BaseController
    {
        public ScheduleController(ISubmissionConfiguration submissionConfiguration, ISecurityProvider securityProvider) : base(submissionConfiguration, securityProvider)
        {
        }

        // GET: Schedule
        public ActionResult Index()
        {
            return View();
        }
    }
}