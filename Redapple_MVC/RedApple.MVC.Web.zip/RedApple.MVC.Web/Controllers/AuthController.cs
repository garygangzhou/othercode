﻿using RedApple.BusinessLogic;
using RedApple.MVC.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RedApple.MVC.Web.Controllers
{
    public class AuthController : BaseController
    {
        public AuthController(ISubmissionConfiguration submissionConfiguration, ISecurityProvider securityProvider) : base(submissionConfiguration, securityProvider)
        {
        }

        // GET: Auth
        public ActionResult UnAuth()
        {
            ViewBag.NoHeaderButtons = true;
            return View();
        }

        public ActionResult Agreement() {
            ViewBag.NoHeaderButtons = true;           

            SubmissionSecurityContext securityContext = SecurityHelper.GetSubmissionSecurityContext();
            if (SecurityHelper.IsValidEULA())
            {
                //already has valid EULA
                return RedirectToOriginal();
            }

            if (!string.IsNullOrEmpty(Request["f"]))
            {
                ViewBag.From = Request["f"];
            }
            return View();
        }

        public ActionResult Accept() {

            securityProvider.SetEulaDate(SecurityHelper.UserInfo);
            SecurityHelper.RefreshUserInfo();
            SubmissionSecurityContext securityContext = SecurityHelper.GetSubmissionSecurityContext();

            if (SecurityHelper.IsValidEULA())
            {
                AuditLogger.WriteSecurityAuditEntry(AuditEventClass.EulaAcceptance, securityContext);
                return RedirectToOriginal();
            }
            else
            {
                AuditLogger.WriteSecurityAuditEntry(AuditEventClass.EulaPresentation, securityContext);
                return RedirectToRoute("EULA");                
            }
        }

        public ActionResult Decline()
        {
            ViewBag.NoHeaderButtons = true;
            SubmissionSecurityContext securityContext = SecurityHelper.GetSubmissionSecurityContext();
            AuditLogger.WriteSecurityAuditEntry(AuditEventClass.EulaDeclension, securityContext);
            ViewBag.Scr = "DisplayDeclineDialogue();";
            return View("Agreement");
        }

        public ActionResult LogOff()
        {
            SecurityHelper.Logout();
            return Redirect(System.Configuration.ConfigurationManager.AppSettings["LogoffUrl"]);
        }

        public ActionResult Error() {
            //now, rely on Global.asax to handle error
            return View();
        }

        private ActionResult RedirectToOriginal()
        {
            //redirect user back to original request
            if (string.IsNullOrEmpty(Request["f"]))
            {
                return RedirectToRoute("Home");
            }
            else
            {
                return new RedirectResult(Request["f"], false);
            }
        }

    }
}
