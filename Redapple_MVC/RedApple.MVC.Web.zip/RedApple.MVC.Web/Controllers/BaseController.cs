﻿using RedApple.BusinessLogic;
using RedApple.MVC.Web.Helpers;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RedApple.MVC.Web.Controllers
{    
    public class BaseController : Controller
    {
        protected ISubmissionConfiguration submissionConfiguration;
        protected ISecurityProvider securityProvider;
        public BaseController(ISubmissionConfiguration submissionConfiguration, ISecurityProvider securityProvider) {
            this.submissionConfiguration = submissionConfiguration;
            this.securityProvider = securityProvider;
        }        
    }
}
