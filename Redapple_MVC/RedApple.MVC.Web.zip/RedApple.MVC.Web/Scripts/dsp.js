﻿//EULA FUNCTIONALITY
function DisplayDeclineDialogue() {
    $.fn.bootstrapBtn = $.fn.button.noConflict();
    $('div.decline-dialog').each(function () {
        $(this).removeClass("collapse");
        var id = $(this).attr("id");
        if ($('div.ui-dialog-content[id="' + id + '"]').length > 0) {

            ////The dialog markup is created every time the dialog is initialized. 
            ////,in case of AJAX calls if an already existing dialog is initiated, 
            //// will get the popup more than once (as many times it was reinitialized). 
            //// To solve this, delete the existing dialog markups before reintializing.
            $('div.ui-dialog-content[id="' + id + '"]').parents('div.ui-dialog:first').html("").remove();
        }
        $(this).dialog({
           // bgiframe: true,
            modal: true, 
            autoOpen: false, 
            closeOnEscape: false,
            draggable: true, 
            position: { my: 'center', at: 'center', of: window },
            resizable: false, 
            width: 500,
            height: 267,
            buttons: {
                'Review EULA': function () {
                    $(this).dialog("close");
                },
                'Log me off': function () {
                    $(this).dialog("close");
                    var Logoffurl = getAbsolutePath() + 'Auth/Logoff';
                    window.location.href = Logoffurl;
                }
            }
        });
        $(this).dialog("open");
    });
}

function getAbsolutePath() {
    var loc = window.location;
    var pathName = loc.pathname.substring(0, loc.pathname.lastIndexOf('/Auth/Decline') + 1);
    return loc.href.substring(0, loc.href.length - ((loc.pathname + loc.search + loc.hash).length - pathName.length));
}

 //CHANGE PASSWORD FUNCTIONALITY
 // Opens initialization URL in hidden iframe for Change Password functionality.
 // Code provied by CCO. 
function initializeChangePassword(ChangePasswordInitUrl) {
        ifrm = document.createElement("IFRAME");    
        ifrm.setAttribute("src", ChangePasswordInitUrl);
        ifrm.style.width = 0 + "px";
        ifrm.style.height = 0 + "px";
        document.body.appendChild(ifrm);
}

function openWindow(ChangePasswordUrl){
    window.open(ChangePasswordUrl, '', 'width=700,height=450');
    return false;
}

function changePassword(ChangePasswordInitUrl, ChangePasswordUrl) {
    initializeChangePassword(ChangePasswordInitUrl);
    openWindow(ChangePasswordUrl);
}

function printwindow()
{
    this.window.print();
}

function NoCaseCheckboxChange(checkbox) {
    ClearMessages();

    var d = $('#selectnocasesreason');
    var f = $('#userSelectedFile');
    if (checkbox && d && f) {
        if (checkbox.checked ) {
            d.removeClass("collapse");
            f.attr("disabled", "disabled");
            $("#userSelectedFile").val("");
        }
        else{
            d.addClass("collapse");
            f.removeAttr("disabled");
        }
    }
}

function ClearMessages() {
    //close all field-validation-error
    $('.field-validation-error').addClass("collapse");
    $('.validation-summary-warnings').addClass("collapse");
    $('.message-success').addClass("collapse");    
    $('.message-error').addClass("collapse");
    $('.message-warning').addClass("collapse");
}

function SubmitButtonEvent(aButton) {
    ClearMessages();

    //validation
    if ($("#chknocasestosubmit").is(':checked')) {
        //no case check box checked, no case reason is required
        if ($("#nocasesreasons").val() == -1) {
            $("#nocasereasonerrormsg").removeClass("collapse");
            return;
        }
    }

    if ( !($("#chknocasestosubmit").is(':checked'))) {
        //file is required
        if ($("#userSelectedFile").val() == "") {
            $("#fileerrormsg").removeClass("collapse");
            return;
        }
    }

    if (!CheckPreviousLoad())
        $('#submissionform').submit(
              function (event) {                  
                  event.stopPropagation();
              }
            )
    else { 
        //append a hidden box to mark this is from submit button
        $("<input>").attr({ 'type': 'hidden', 'id': 'hiddenbox', 'name': 'hiddenbox' }).val("formsubmitting").appendTo($('#submissionform'));
        $('#submissionform').submit();
    }
}

function CheckPreviousLoad() {
    if ($("#submissionclasses").val() != "GI_ENDO")
        return true;

    var hasPrevLoad = true;
    var retVal = true;
    $.ajax({
        type: "POST",
        url: "CheckPreviousLoad",
        data: "{'submissionClassName': '" + $("#submissionclasses").val() + "', 'submissionSiteNumber': '" + $("#facilitysites").val() + "', 'repgPeriodId': '" + $("#submissionperiod").val() + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            //alert(response);
            hasPrevLoad = response;
        },
        error: function (response) {
            hasPrevLoad = false;
            retVal = false;
            alert("System error");
        },
        async: false
    });

    if (hasPrevLoad) {
        if ($("#chknocasestosubmit").is(':checked')) {
            if (!confirm("This no cases submission falls within a time period of Colonoscopy information already uploaded. Click 'OK' to proceed or 'Cancel' to stop.\n\nCaution: By pressing 'OK' you will override the existing Colonoscopy information within this time period.")) {
                retVal = false;
            }
        } else {
            if (!confirm("This file submission falls within a time period of Colonoscopy information already uploaded. Click 'OK' to proceed or 'Cancel' to stop.\n\nCaution: By pressing 'OK' you will override the existing Colonoscopy information within this time period.")) {
                retVal = false;
            }
        }
    }
    return retVal;
}