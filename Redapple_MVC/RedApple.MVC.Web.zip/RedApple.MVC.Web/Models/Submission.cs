﻿using RedApple.MVC.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RedApple.MVC.Web.Models
{
    [ModelBinder(typeof(SubmissioCustomBinder))]
    public class SubmissionViewModel
    {
        public List<MyNameValue> SubmissionClasses { get; set; } = new List<MyNameValue>();
        public List<MyNameValue> FacilitySites { get; set; } = new List<MyNameValue>();
        public List<MyNameValue> SubmissionPeriods { get; set; } = new List<MyNameValue>();
        public bool NoCaseVisible { get; set; } = false;
        public List<MyNameValue> NoCaseReasons { get; set; } = new List<MyNameValue>();
        public bool ScheduleEditorRole { get; set; } = false;
        public SubmissionUserInput Inputs { get; set; } = new SubmissionUserInput();
       
    }

    public class MyNameValue {
        public string Id { get; set; } = string.Empty;
        public string Desc { get; set; } = string.Empty;
        public bool Selected { get; set; } = false;
    }
        
    public class SubmissionUserInput
    {
        public string SubmissionClass { get; set; } = string.Empty;
        public string FacilitySites { get; set; } = string.Empty;
        public int SubmissionPeriodID { get; set; } = -1;
        public bool NoCase { get; set; } = false;
        public int NoCaseReaseonID { get; set; } = -1;
        public HttpPostedFileBase UploadFile { get; set; } = null;
    }
}
