﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RedApple.MVC.Web.Models
{
    public class Document {
        public string DocumentDescription { get; set; } = string.Empty;
        public List<DocumentRecordSet> DocumentRecordSets { get; set; }  = new List<DocumentRecordSet>();
    }

    public class DocumentRecordSet {
        public string DocumentRecordSetDescription { get; set; } = string.Empty;
        public int DocumentRecordSetID { get; set; } = -1;
    }
}