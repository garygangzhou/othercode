﻿using RedApple.BusinessLogic;
using RedApple.Common.Utility;
using RedApple.DAL;
using RedApple.MVC.Web.Helpers;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Practices.Unity;
using System.Web.Mvc;

namespace RedApple.MVC.Web.InternalSite
{
    public partial class ReportViewer : System.Web.UI.Page
    {
        protected void Page_Init(object sender, EventArgs e)
        {
            ReportViewer1.ReportError += new ReportErrorEventHandler(ReportViewer1_ReportError);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //empty           
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                RenderReport(LoadReport());
            }
        }

        private ReportInfo LoadReport()
        {
            litReportName.Text = string.Empty;
            litReportDescription.Text = string.Empty;
            
            int reportId = Convert.ToInt32(Session[Constants.SessionKeys.ReportId]);           

            if (reportId == 0)
            {
                lblMessage.Text = "No report requested";

                return null;
            }

            var submissionConfiguration = DependencyResolver.Current.GetService<ISubmissionConfiguration>();

            var reportDefinition = submissionConfiguration.GetReportById(reportId);

            if (reportDefinition == null)
            {
                lblMessage.Text = "Requested report not found";

                return null;
            }

            litReportName.Text = reportDefinition.ReportName;
            litReportDescription.Text = reportDefinition.ReportDescription;

            return reportDefinition;
        }

        private void RenderReport(ReportInfo reportDefinition)
        {
            if (reportDefinition == null)
            {
                return;
            }


            ReportViewer1.Reset();

            string reportingServcieURL = reportDefinition.ReportingService.ReportServerURL;
            if (reportingServcieURL.EndsWith("/"))
                reportingServcieURL = reportingServcieURL.Substring(0, reportingServcieURL.Length - 1);

            string subfolder = reportDefinition.ReportSubFolder;
            if (!string.IsNullOrWhiteSpace(subfolder))
            {
                if (!subfolder.EndsWith("/"))
                {
                    subfolder = subfolder + "/";
                }
            }

            string reportPath = string.Format("{0}/{1}{2}", reportDefinition.ReportingService.RootFolder, subfolder, reportDefinition.ReportFileName);

            //this.ReportViewerId.ServerReport.ReportServerCredentials = new Model.ReportServerCredentials();
            ReportViewer1.ProcessingMode = ProcessingMode.Remote;


            // S.L: #163766  Print button disable
            ReportViewer1.ShowPrintButton = false;

            ReportViewer1.ShowToolBar = true;
            ReportViewer1.ServerReport.ReportServerUrl = new Uri(reportingServcieURL);
            ReportViewer1.ServerReport.ReportPath = reportPath;
            //ReportViewer1.ServerReport.Timeout = reportServerTimeOut;



            try
            {
                if (reportDefinition.ReportParameters.Any())
                {
                    // load the report parameters
                    IList<ReportParameter> plist = new List<ReportParameter>();
                    foreach (var p in reportDefinition.ReportParameters)
                    {
                        if (!string.IsNullOrWhiteSpace(p.DefaultValueReference))
                        {
                            if ("UserName".Equals(p.DefaultValueReference, StringComparison.OrdinalIgnoreCase))
                            {
                                p.DefaultValue = SecurityHelper.UserInfo.LogonName;
                            }
                            else
                            {
                                p.DefaultValue = (Session[p.DefaultValueReference] != null) ? Session[p.DefaultValueReference].ToString() : string.Empty;
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(p.DefaultValue))
                        {
                            plist.Add(new ReportParameter(p.ParameterName, p.DefaultValue, !p.IsHidden));
                        }
                    }

                    ReportViewer1.ServerReport.SetParameters(plist);
                }
            }
            catch (Exception ex)
            {
                HandleReportException(ex);
            }

        }

        private void ReportViewer1_ReportError(object sender, ReportErrorEventArgs e)
        {
            HandleReportException(e.Exception);

            e.Handled = true;
        }

        private void HandleReportException(Exception ex)
        {
            LogUtility.WriteLog(2, 1, System.Diagnostics.TraceEventType.Error,
                ex.ToString(), new List<LogCategory>() { LogCategory.Error });

            lblMessage.Text = "An error occured while rendering the report. Error details have been logged.";

            ReportViewer1.Visible = false;
        }

    }
}