﻿using RedApple.BusinessLogic;
using RedApple.Common.Utility;
using RedApple.MVC.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace RedApple.MVC.Web
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            UnityConfig.RegisterComponents();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
         
        }

        protected void Application_End(object sender, EventArgs e)
        {           
         
        }
        
        protected void Session_Start()
        {
            //login
            SecurityHelper.Login();
            SubmissionSecurityContext securityContext = SecurityHelper.GetSubmissionSecurityContext();
            
            if (securityContext.UserInfo.UserId == 0)
            {
                //access deny
                AuditLogger.WriteSecurityAuditEntry(AuditEventClass.UserLoginFailed, securityContext);
                
                if (Request.Url.OriginalString.IndexOf("UnAuth", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    Response.Redirect(UrlHelper.GenerateUrl("UnAuth", null, null, null, RouteTable.Routes, HttpContextManager.Current.Request.RequestContext, false));
                }
            }
            else
            {
                //EULA check
                if (!SecurityHelper.IsValidEULA())
                {
                    AuditLogger.WriteSecurityAuditEntry(AuditEventClass.EulaPresentation, securityContext);

                    if (Request.Url.OriginalString.IndexOf("Agreement", StringComparison.OrdinalIgnoreCase) < 0)
                    {
                        Response.Redirect(UrlHelper.GenerateUrl("EULA", null, null, new RouteValueDictionary { { "f", Request.Url.PathAndQuery } }, RouteTable.Routes, HttpContextManager.Current.Request.RequestContext, false));
                    }
                }
                else
                {
                    AuditLogger.WriteSecurityAuditEntry(AuditEventClass.UserLogin, securityContext);                    
                }
            }
        }

        protected void Session_End()
        {
            ApplicationUser userInfo = Session[Constants.SessionKeys.UserInfo] as ApplicationUser;

            var securityContext = new SubmissionSecurityContext
            {
                UserInfo = new ApplicationUser
                {
                    UserId = (userInfo == null) ? 0 : userInfo.UserId,
                    DisplayName = (userInfo == null) ? string.Empty : userInfo.DisplayName,
                    LogonName = (userInfo == null) ? string.Empty : userInfo.LogonName                                      
                },
                SessionId = Session.SessionID              
            };

            AuditLogger.WriteSecurityAuditEntry(AuditEventClass.UserLogout, securityContext);
            
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            if (CustomErrorOn())
            {
                Exception ex = Server.GetLastError();

                if (ex != null)
                {
                    System.Diagnostics.Debug.WriteLine(ex.ToString());
                    if (ex is NoPermissionsException || ex.InnerException is NoPermissionsException)
                    {
                        SubmissionSecurityContext securityContext = SecurityHelper.GetSubmissionSecurityContext();
                        AuditLogger.WriteSecurityAuditEntry(AuditEventClass.UserNotAuthorized, securityContext);
                        if (Request.Url.OriginalString.IndexOf("UnAuth", StringComparison.OrdinalIgnoreCase) < 0)
                        {
                            Response.Redirect(UrlHelper.GenerateUrl("UnAuth", null, null, null, RouteTable.Routes, HttpContextManager.Current.Request.RequestContext, false));
                        }
                    }

                    LogUtility.WriteLog(1, 1, System.Diagnostics.TraceEventType.Error, ex.ToString(), new List<LogCategory>() { LogCategory.Error });

                    //dont clear error, allow customerror tag to handle after logging
                    //Server.ClearError();
                    //Response.Redirect(UrlHelper.GenerateUrl(null, "Error", "Auth", null, RouteTable.Routes, HttpContextManager.Current.Request.RequestContext, false));
                }
            }
        }

        private bool CustomErrorOn() {
            var configuration = WebConfigurationManager.OpenWebConfiguration("/");

            // Get the section.
            CustomErrorsSection customErrors = (CustomErrorsSection)configuration.GetSection("system.web/customErrors");
            
            if( customErrors.Mode == CustomErrorsMode.RemoteOnly )
            {
                return Request.Url.Host.ToLower() != "localhost";
            }

            return customErrors.Mode == CustomErrorsMode.On;
        }
    }
}
