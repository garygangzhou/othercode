﻿using RedApple.MVC.Web.Helpers;
using System.Web;
using System.Web.Mvc;

namespace RedApple.MVC.Web
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            //useless
            //filters.Add(new HandleErrorAttribute());

            //all actions require EULA
            filters.Add(new EulaRequiredAttribute());
        }
    }
}
