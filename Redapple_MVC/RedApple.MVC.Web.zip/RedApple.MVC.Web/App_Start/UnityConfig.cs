using System.Web.Mvc;
using Microsoft.Practices.Unity;
using Unity.Mvc5;
using Microsoft.Practices.Unity.Configuration;
using System.Configuration;
using RedApple.Common.Infrastructure;

namespace RedApple.MVC.Web
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
            //var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // e.g. container.RegisterType<ITestService, TestService>();

            DependencyInjectionHelper.Initialize();
            IUnityContainer container = DependencyInjectionHelper.Container;
            UnityConfigurationSection section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
            section.Configure(container);

            DependencyResolver.SetResolver(new UnityDependencyResolver(container));           
        }
    }
}